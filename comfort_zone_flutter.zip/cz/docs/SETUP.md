# Comfort Zone: setup guide (Step 1)

Do Part A (Supabase) first, then Part B (Flutter). Use a separate *dev* project for testing.

## Part A. Supabase

### A1. Create the project
1. supabase.com → New project. Save the database password.
2. Project Settings → API: copy the **Project URL** and the **anon / publishable key**.
   Never put the `service_role` key in the app.

### A2. Run the migrations (001 → 008)
**Easiest: one paste.**
1. Dashboard → **SQL Editor** → New query.
2. Open `supabase/all_migrations.sql`, copy everything, paste, click **Run**.
3. It must finish with "Success". If it shows an error, read the line it points to, and send it to me.
   The migrations are **not re-runnable**: they use plain `create table`. If a run failed halfway,
   run `verify.sql` to see what exists; on a fresh dev project the cleanest fix is to reset the
   database (Project Settings → Database) and run the whole file again.

**Alternative: file by file.** Run `supabase/migrations/001…` through `008…` one at a time, in this order.
Order matters: 002-003 need 001; 005 needs 001; 006 needs 005; 007 needs 005 + 006; 008 needs 003.

**Alternative: Supabase CLI.** `supabase link --project-ref <ref>` then `supabase db push`.
The CLI expects timestamp-style file names; if it complains about `001_…`, use the SQL editor instead.

### A3. Verify
Paste `supabase/verify.sql` into the SQL Editor and run it. Expect:
- every `ok` = true (16 tables, 22 functions, RLS on for all tables);
- Realtime lists exactly 5 tables: gift_transactions, messages, notifications, room_seats, rooms;
- seed counts: 7 game modes, 6 gifts, 3 app settings, 1+ banner;
- last query: `false, false, true, false`.

### A4. Auth settings
- Authentication → Providers → **Email**: enabled. While developing you may switch off "Confirm email" to sign up faster.
- Authentication → **URL Configuration** → Redirect URLs: add `io.supabase.comfortzone://login-callback/`
- Google sign-in: Providers → Google → enable. In Google Cloud Console create an OAuth client
  (type *Web application*), set its redirect URI to `https://<project-ref>.supabase.co/auth/v1/callback`,
  and paste the client ID and secret into Supabase.

### A5. Voice token function (Agora)
1. console.agora.io → create a project in **Secured mode (App ID + Token)**. Copy App ID and App Certificate.
2. In the project folder:
```
supabase login
supabase link --project-ref <ref>
supabase secrets set AGORA_APP_ID=... AGORA_APP_CERTIFICATE=...
supabase functions deploy agora-token
```

### A6. Make yourself admin (after you have signed up once in the app)
Your ID is shown on the Me screen (`user_12345678`). In the SQL Editor:
```sql
update profiles set is_admin = true where handle = 'user_12345678';
update profiles set coins = 5000 where handle = 'user_12345678';   -- test coins, optional
```

## Part B. Flutter platforms

### B1. Tools
Install Flutter (3.22 or newer), then `flutter doctor` until Android (and Xcode on a Mac) show no red items.

### B2. Generate and configure the platform folders
From the project root:
```
bash tools/setup_platforms.sh              # default id: com.comfortzone.comfort_zone
bash tools/setup_platforms.sh com.yourname # or choose your own organisation id
```
Choose the id **now**: it is your permanent Android/iOS app id.
The script runs `flutter create`, restores your pubspec/README, deletes the sample test, then patches:
- Android: microphone, notification, Bluetooth, vibrate permissions; app name; the Google-login return link;
  desugaring (needed by flutter_local_notifications).
- iOS: microphone text, background audio, the same return link, iOS 13, and the permission_handler switches
  (without them the microphone is silently always "denied").
The iOS `Podfile` only exists after the first iOS build. If the script says it was skipped, run
`cd ios && pod install`, then `python3 tools/patch_platforms.py .` once more.

### B3. Run
```
flutter analyze
flutter test
flutter run \
  --dart-define=SUPABASE_URL=https://<ref>.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=<anon key> \
  --dart-define=AGORA_APP_ID=<agora app id>
```
Without `SUPABASE_URL` the app runs on demo data.
iOS only: open `ios/Runner.xcworkspace` in Xcode → Signing & Capabilities → pick your team.

### B4. Test checklist (two phones or a phone + emulator, two accounts)
1. Sign up / sign in with email; then Google.
2. Create a room, join from the 2nd account, take a seat, speak (needs a real device for the mic).
3. Give test coins (A6), send a gift; balance drops and the gift banner appears.
4. Send a chat message; the unread badge appears on the other phone.
5. Wallet: submit a Bkash request as user B. Admin (user A) gets a notification, approves it in
   Me → Review recharge requests. User B gets "Coins added" and the balance updates.
6. Ludo: play vs computer to the end. The stats card on the Gaming tab shows 1 played.

## Common problems
- **Google login opens the browser but never returns**: the redirect URL in A4 or the link in the manifest/plist is missing or different.
- **"Take a seat first" / no voice**: token function not deployed, or `AGORA_APP_ID` missing in `--dart-define`.
- **Microphone denied on iOS**: the Podfile patch did not run (B2).
- **No notification banner**: notifications work only while the app runs; closed-app push is a later step.
- **Android build error about desugaring / core library**: re-run `python3 tools/patch_platforms.py .`.
