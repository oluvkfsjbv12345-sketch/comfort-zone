# শুধু মোবাইল দিয়ে APK বানানো (কম্পিউটার ছাড়া)

কম্পিউটার লাগবে না। GitHub-এর সার্ভার প্রজেক্টটা কম্পাইল করে APK বানিয়ে দেবে; আপনি শুধু কোড GitHub-এ তুলবেন।
এই ফাইলের `.github/workflows/build_apk.yml` আগে থেকেই এই কাজের জন্য প্রস্তুত করা আছে।

## ধাপ ১: প্রজেক্ট কোড GitHub-এ তোলা
GitHub-এর ওয়েবসাইটে ফোল্ডারসহ আপলোড ঠিকমতো কাজ করে না, তাই **Termux** অ্যাপ দিয়ে করাই সবচেয়ে নির্ভরযোগ্য।

1. **Termux ইনস্টল করুন** — Play Store থেকে না, **F-Droid** (f-droid.org) থেকে (Play Store-এরটা পুরনো, কাজ করে না)।
2. Termux খুলে লিখুন:
   ```
   pkg update && pkg upgrade -y
   pkg install git -y
   termux-setup-storage
   ```
   (শেষেরটা চাপলে একটা পারমিশন চাইবে, "Allow" দিন — এতে Termux আপনার ফোনের ফাইল দেখতে পারবে।)
3. আপনার প্রজেক্ট ফোল্ডারটা ফোনের কোথায় আছে খুঁজে বের করুন (যেমন Downloads বা নির্দিষ্ট একটা ফোল্ডারে)। Termux-এ গিয়ে সেখানে যান:
   ```
   cd storage/downloads/cz          # আপনার আসল পাথ অনুযায়ী বদলান
   ls                                # pubspec.yaml দেখা যাচ্ছে কিনা মিলিয়ে নিন
   ```
4. **GitHub-এ অ্যাকাউন্ট ও খালি রিপো তৈরি করুন** (ফোনের ব্রাউজারে github.com):
   - Sign up / Sign in।
   - উপরে ডানে **+** → **New repository**।
   - নাম দিন `comfort-zone`, **Private** বেছে নিন, README/gitignore কিছু **যোগ করবেন না** (খালি রিপো লাগবে)। **Create repository**।
5. **Personal Access Token বানান** (পাসওয়ার্ডের বদলে এটা লাগবে):
   - GitHub-এ: Settings → Developer settings → Personal access tokens → **Tokens (classic)** → Generate new token।
   - স্কোপে শুধু `repo` টিক দিন। Expiration ৯০ দিন বা যা সুবিধা। **Generate token** চাপুন এবং টোকেনটা কপি/সেভ করে রাখুন (একবারই দেখাবে)।
6. Termux-এ ফিরে এসে (আগের `cd` করা ফোল্ডারেই থেকে):
   ```
   git init
   git add .
   git config user.email "you@example.com"
   git config user.name "Your Name"
   git commit -m "Comfort Zone: full project"
   git branch -M main
   git remote add origin https://github.com/<আপনার-ইউজারনেম>/comfort-zone.git
   git push -u origin main
   ```
   `push` করার সময় username চাইলে আপনার GitHub username দিন, আর password চাইলে **টোকেনটা** পেস্ট করুন (আসল পাসওয়ার্ড না — GitHub পাসওয়ার্ড দিয়ে push নেয় না)।
7. GitHub-এ রিপো রিফ্রেশ করে দেখুন — সব ফাইল (lib, supabase, tools, .github ইত্যাদি) উঠে গেছে কিনা।

## ধাপ ২: Secrets যোগ করা (SUPABASE_URL ইত্যাদি)
কোডে সরাসরি এগুলো না লিখে GitHub-এর "Secrets"-এ রাখা নিরাপদ, আর build ফাইল (`build_apk.yml`) এমনিতেই সেখান থেকে এগুলো নেয়।

রিপোর ভেতরে: **Settings → Secrets and variables → Actions → New repository secret** — তিনবার করুন:
| Name | Value |
|---|---|
| `SUPABASE_URL` | আপনার প্রজেক্টের URL (`https://xxxx.supabase.co`) |
| `SUPABASE_ANON_KEY` | anon / publishable key |
| `AGORA_APP_ID` | Agora App ID |

## ধাপ ৩: বিল্ড চালানো ও APK নামানো
1. উপরের push করলেই বিল্ড **এমনিতেই শুরু হয়ে যায়** (ওপরের ধাপ ১-এর push এটাকে ট্রিগার করে)। রিপোর **Actions** ট্যাবে যান — একটা রান "in progress" দেখাবে।
2. না চললে: Actions ট্যাব → বাঁয়ে **Build Android APK** → ডানে **Run workflow** → **Run workflow** বাটনে চাপুন।
3. প্রায় ৫–১০ মিনিট লাগে। সবুজ টিক ✅ আসলে বিল্ড সফল। লাল ❌ হলে সেই রানে ক্লিক করে লগ দেখুন, কোন ধাপে আটকেছে সেটা আমাকে পাঠান।
4. বিল্ড শেষ হলে সেই রান পেজে নিচে **Artifacts** অংশে `comfort-zone-apk` নামে একটা জিপ থাকবে — ফোনের ব্রাউজার দিয়ে ট্যাপ করলেই ডাউনলোড হবে।
5. ডাউনলোড হওয়া `.zip` ফাইলটা ফোনের **Files** অ্যাপ দিয়ে Extract/Unzip করুন — ভেতরে `app-release.apk` পাবেন।

## ধাপ ৪: ফোনে ইনস্টল করা
1. যে অ্যাপ দিয়ে APK খুলবেন (ব্রাউজার বা Files অ্যাপ), তাকে "Install unknown apps" পারমিশন দিতে হবে: Settings → Apps → (Chrome/Files) → Install unknown apps → Allow।
2. `app-release.apk`-এ ট্যাপ করে **Install**।
3. এই APK **signed নয় production key দিয়ে** (ডিফল্ট debug/test সাইনিং) — নিজের ফোনে টেস্ট করার জন্য এটা যথেষ্ট, কিন্তু Play Store-এ দেওয়ার আগে আলাদাভাবে সাইন করতে হবে (এটা পরের ধাপের কাজ)।

## ধাপ ৫: B4 চেকলিস্টের টেস্ট (একটা ফোনে যা করা সম্ভব)
আসল সমস্যা: ভয়েস রুম আর কিছু টেস্টে **দুইজন একসাথে অনলাইন** লাগে, তাই এক ফোনে পুরোপুরি সম্ভব না। যা করবেন:

- **একা করা যায়:**
  - সাইন আপ/সাইন ইন (ইমেইল + Google) — কাজ করছে কিনা।
  - রুম খোলা, নিজের সিটে বসা (মাইক পারমিশন চাইবে কিনা)।
  - Ludo বট-এর বিরুদ্ধে খেলা, শেষে Gaming ট্যাবে স্ট্যাটস কার্ড আসছে কিনা।
  - Bkash রিচার্জ রিকোয়েস্ট সাবমিট করা (একটা অ্যাকাউন্ট দিয়ে)।
  - এডমিন নিজেকে বানিয়ে (গাইডের A6 ধাপ) সেই রিকোয়েস্ট Approve করা — টাকা যোগ হচ্ছে কিনা।
- **দ্বিতীয় ডিভাইস লাগবে** (দ্বিতীয় ফোন, পুরনো ফোন, বা বন্ধুর ফোনে দ্বিতীয় অ্যাকাউন্ট দিয়ে):
  - দুইজন একই ভয়েস রুমে ঢুকে কথা বলা যাচ্ছে কিনা।
  - একজন গিফট পাঠালে অন্যজনের ব্যালেন্স/নোটিফিকেশন দেখা।
  - চ্যাটে মেসেজ পাঠিয়ে অন্য ফোনে আনরিড ব্যাজ ও ব্যানার আসছে কিনা।
  - এডমিন Approve করার সাথে সাথে অন্য অ্যাকাউন্টে "কয়েন যোগ হয়েছে" নোটিফিকেশন আসছে কিনা।

দ্বিতীয় ডিভাইস না থাকলে আপাতত "একা করা যায়" অংশটুকু আগে সেরে নিন — বাকিটা যেদিন দ্বিতীয় ফোন পাবেন সেদিন করবেন।

## পরে কোড বদলালে
প্রতিবার নতুন কোড বদলাবেন, Termux থেকে আবার:
```
cd storage/downloads/cz
git add .
git commit -m "changes"
git push
```
— push করলেই নতুন APK অটো বিল্ড হবে, আবার Actions ট্যাব থেকে নামাতে হবে।

## সমস্যা হলে
- **`git push` এ permission denied**: টোকেন ভুল/মেয়াদ শেষ, ধাপ ১.৫ আবার করুন।
- **Build লাল (❌) হলে**: Actions-এর রান খুলে লগ কপি করে আমাকে দিন, আমি দেখে ঠিক করে দেব।
- **APK ইনস্টল হচ্ছে না**: "Install unknown apps" পারমিশন চেক করুন; একই প্যাকেজ নামে আগের কোনো ভার্সন থাকলে সেটা uninstall করে আবার চেষ্টা করুন।
