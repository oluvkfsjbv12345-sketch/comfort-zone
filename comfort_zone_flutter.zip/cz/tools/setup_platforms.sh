#!/usr/bin/env bash
# Run from the project root (the folder that contains pubspec.yaml):  bash tools/setup_platforms.sh
set -euo pipefail
ORG="${1:-com.comfortzone}"     # Android applicationId / iOS bundle id = $ORG.comfort_zone. Choose it NOW: changing later is painful.

command -v flutter >/dev/null || { echo "Flutter is not installed or not on PATH."; exit 1; }
[ -f pubspec.yaml ] || { echo "Run this from the project root."; exit 1; }

# `flutter create .` must not touch our own files.
tmp="$(mktemp -d)"; cp pubspec.yaml README.md "$tmp"/ 2>/dev/null || true
flutter create . --org "$ORG" --project-name comfort_zone --platforms android,ios
cp "$tmp"/pubspec.yaml . ; [ -f "$tmp/README.md" ] && cp "$tmp/README.md" .
# The default counter-app test refers to MyApp, which does not exist here.
[ -f test/widget_test.dart ] && grep -q "MyApp" test/widget_test.dart && rm test/widget_test.dart

flutter pub get
python3 tools/patch_platforms.py .
echo
echo "Done. iOS: run 'flutter pub get' + 'cd ios && pod install' on a Mac, then re-run this script's patcher"
echo "(python3 tools/patch_platforms.py .) if ios/Podfile did not exist yet."
