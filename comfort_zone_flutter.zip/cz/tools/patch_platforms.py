#!/usr/bin/env python3
"""Adds Comfort Zone's Android/iOS settings to a project created by `flutter create`.
Safe to run more than once: every change is skipped if it is already there."""
import pathlib, re, sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
SCHEME, HOST = 'io.supabase.comfortzone', 'login-callback'   # must match login_screen.dart + Supabase dashboard
done, skipped = [], []

def edit(path, fn, label):
    if not path.exists():
        skipped.append(f'{label}: {path.relative_to(ROOT)} not found'); return
    old = path.read_text(encoding='utf-8'); new = fn(old)
    if new == old: skipped.append(f'{label}: already set'); return
    path.write_text(new, encoding='utf-8'); done.append(label)

# ---------------- Android manifest ----------------
PERMS = ['INTERNET', 'ACCESS_NETWORK_STATE', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS',
         'BLUETOOTH_CONNECT', 'POST_NOTIFICATIONS', 'VIBRATE']
def manifest(t):
    if 'RECORD_AUDIO' not in t:
        lines = ''.join(f'\n    <uses-permission android:name="android.permission.{p}"/>' for p in PERMS)
        t = re.sub(r'(<manifest[^>]*>)', lambda m: m.group(1) + lines, t, count=1)
    t = t.replace('android:label="comfort_zone"', 'android:label="Comfort Zone"')
    if HOST not in t:
        f = (f'\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW"/>\n'
             f'                <category android:name="android.intent.category.DEFAULT"/>\n'
             f'                <category android:name="android.intent.category.BROWSABLE"/>\n'
             f'                <data android:scheme="{SCHEME}" android:host="{HOST}"/>\n            </intent-filter>')
        t = t.replace('</activity>', f + '\n        </activity>', 1)
    return t
edit(ROOT/'android/app/src/main/AndroidManifest.xml', manifest, 'Android manifest (permissions, name, OAuth link)')

# ---------------- Android Gradle: desugaring for flutter_local_notifications ----------------
def gradle_kts(t):
    if 'isCoreLibraryDesugaringEnabled' not in t:
        t = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', t, count=1)
    if 'desugar_jdk_libs' not in t:
        t += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    return t
def gradle_groovy(t):
    if 'coreLibraryDesugaringEnabled' not in t:
        t = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', t, count=1)
    if 'desugar_jdk_libs' not in t:
        t += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    return t
kts = ROOT/'android/app/build.gradle.kts'
edit(kts if kts.exists() else ROOT/'android/app/build.gradle', gradle_kts if kts.exists() else gradle_groovy, 'Android Gradle (desugaring)')

# ---------------- iOS Info.plist ----------------
def plist(t):
    add = ''
    if 'NSMicrophoneUsageDescription' not in t:
        add += ('\t<key>NSMicrophoneUsageDescription</key>\n'
                '\t<string>Comfort Zone uses the microphone so you can talk in voice rooms.</string>\n')
    if 'UIBackgroundModes' not in t:
        add += '\t<key>UIBackgroundModes</key>\n\t<array>\n\t\t<string>audio</string>\n\t</array>\n'
    if SCHEME not in t:
        add += (f'\t<key>CFBundleURLTypes</key>\n\t<array>\n\t\t<dict>\n\t\t\t<key>CFBundleURLSchemes</key>\n'
                f'\t\t\t<array>\n\t\t\t\t<string>{SCHEME}</string>\n\t\t\t</array>\n\t\t</dict>\n\t</array>\n')
    if add:
        i = t.rfind('</dict>')
        t = t[:i] + add + t[i:]
    return t
edit(ROOT/'ios/Runner/Info.plist', plist, 'iOS Info.plist (microphone, audio, OAuth link)')

# ---------------- iOS Podfile: permission_handler needs these macros or the mic is always "denied" ----------------
def podfile(t):
    t = re.sub(r"^#?\s*platform :ios, '[\d.]+'", "platform :ios, '13.0'", t, count=1, flags=re.M)
    if 'PERMISSION_MICROPHONE' not in t:
        block = ("\n    target.build_configurations.each do |config|\n"
                 "      config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] ||= ['$(inherited)']\n"
                 "      config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] << 'PERMISSION_MICROPHONE=1'\n"
                 "      config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] << 'PERMISSION_NOTIFICATIONS=1'\n    end")
        t = t.replace('flutter_additional_ios_build_settings(target)', 'flutter_additional_ios_build_settings(target)' + block, 1)
    return t
edit(ROOT/'ios/Podfile', podfile, 'iOS Podfile (iOS 13, permission macros)')

print('Changed:'); [print('  +', d) for d in done]
print('Skipped:'); [print('  -', s) for s in skipped]
