// Deploy: supabase functions deploy agora-token
// Secrets: supabase secrets set AGORA_APP_ID=... AGORA_APP_CERTIFICATE=...
import { RtcTokenBuilder, RtcRole } from "npm:agora-token@2";
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return new Response("Unauthorized", { status: 401 });

  const { channel, uid, role } = await req.json();
  const { data: me } = await sb.from("profiles").select("agora_uid").eq("id", user.id).single();
  if (!me || me.agora_uid !== uid) return new Response("Wrong uid", { status: 403 });

  // Speaking rights are only issued to users who really hold a seat in this room.
  if (role === "publisher") {
    const { data: room } = await sb.from("rooms").select("id").eq("agora_channel", channel).single();
    const { data: seat } = await sb.from("room_seats").select("seat_no")
      .eq("room_id", room?.id).eq("user_id", user.id).maybeSingle();
    if (!seat) return new Response("Take a seat first", { status: 403 });
  }

  const expire = Math.floor(Date.now() / 1000) + 3600;
  const token = RtcTokenBuilder.buildTokenWithUid(
    Deno.env.get("AGORA_APP_ID")!, Deno.env.get("AGORA_APP_CERTIFICATE")!, channel, uid,
    role === "publisher" ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER, expire, expire);
  return Response.json({ token });
});
