-- Comfort Zone: ALL migrations 001 -> 008 in order. Run ONCE on a fresh project.
-- (Same content as the files in migrations/. Do not run this on a database that already ran any of them.)

-- ==============================================================
-- 001_users_rooms.sql
-- ==============================================================
-- COMFORT ZONE: users + rooms schema. Run in Supabase SQL editor.
create extension if not exists pgcrypto;

-- ============ PROFILES (one row per auth user) ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  handle text unique not null,            -- public ID, e.g. user_88437282
  display_name text,
  avatar_url text,
  frame_id text,                          -- equipped avatar frame (FK to a store table later)
  country_code char(2),
  coins bigint not null default 0 check (coins >= 0),
  vip_level int not null default 0,
  followers_count int not null default 0,
  following_count int not null default 0,
  gifts_received int not null default 0,
  visitors_count int not null default 0,
  created_at timestamptz not null default now()
);

-- Auto-create a profile on signup with a generated handle
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, handle, display_name)
  values (new.id, 'user_' || lpad(floor(random()*100000000)::int::text, 8, '0'),
          coalesce(new.raw_user_meta_data->>'name', 'Guest'));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============ ROOMS ============
create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 60),
  cover_url text,
  agency_name text,
  country_code char(2),
  category text not null default 'party' check (category in ('party','activity','chat')),
  listener_count int not null default 0 check (listener_count >= 0),
  is_live boolean not null default true,
  agora_channel text unique not null default replace(gen_random_uuid()::text,'-',''),
  created_at timestamptz not null default now()
);
create index rooms_hot_idx on public.rooms (is_live, listener_count desc);
create index rooms_country_idx on public.rooms (country_code, listener_count desc);

create table public.room_members (
  room_id uuid references public.rooms(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  role text not null default 'listener' check (role in ('owner','admin','speaker','listener')),
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null, subtitle text,
  gradient_from text not null default '7B4DFF',   -- hex, no '#'
  gradient_to text not null default 'FF5E8A',
  sort_order int not null default 0,
  active boolean not null default true
);

-- ============ JOIN / LEAVE (keeps listener_count accurate) ============
create function public.join_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into room_members (room_id, user_id) values (p_room_id, auth.uid())
  on conflict do nothing;
  if found then update rooms set listener_count = listener_count + 1 where id = p_room_id; end if;
end $$;

create function public.leave_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from room_members where room_id = p_room_id and user_id = auth.uid();
  if found then update rooms set listener_count = greatest(listener_count - 1, 0) where id = p_room_id; end if;
end $$;

-- ============ ROW LEVEL SECURITY ============
alter table profiles enable row level security;
alter table rooms enable row level security;
alter table room_members enable row level security;
alter table banners enable row level security;

create policy "profiles readable" on profiles for select to authenticated using (true);
create policy "own profile update" on profiles for update to authenticated using (id = auth.uid());
-- Clients may NOT touch coins/vip/counters; those change via server functions only.
revoke update on profiles from authenticated;
grant update (display_name, avatar_url, country_code, frame_id) on profiles to authenticated;

create policy "rooms readable" on rooms for select to authenticated using (true);
create policy "create own room" on rooms for insert to authenticated with check (owner_id = auth.uid());
create policy "owner edits room" on rooms for update to authenticated using (owner_id = auth.uid());
create policy "owner deletes room" on rooms for delete to authenticated using (owner_id = auth.uid());
revoke update on rooms from authenticated;
grant update (title, cover_url, agency_name, category, is_live) on rooms to authenticated;

create policy "members readable" on room_members for select to authenticated using (true);
create policy "banners readable" on banners for select to authenticated using (active);

-- Live listener counts in the app
alter publication supabase_realtime add table public.rooms;

-- Demo banner
insert into banners (title, subtitle) values ('Family Coin Chase', 'Team up, collect coins, win big');


-- ==============================================================
-- 002_voice_room.sql
-- ==============================================================
-- Voice room: seats, gifts, coin-safe gifting. Run after 001.
alter table profiles add column agora_uid int generated always as identity unique;

create table room_seats (
  room_id uuid references rooms(id) on delete cascade,
  seat_no int not null check (seat_no between 1 and 8),
  user_id uuid not null references profiles(id) on delete cascade,
  taken_at timestamptz not null default now(),
  primary key (room_id, seat_no),
  unique (room_id, user_id)             -- one seat per user per room
);

create table gifts (
  id text primary key, name text not null, emoji text not null,
  price int not null check (price > 0), active boolean not null default true
);
insert into gifts (id, name, emoji, price) values
  ('rose','Rose','🌹',10), ('heart','Heart','💖',50), ('cake','Cake','🎂',120),
  ('crown','Crown','👑',500), ('rocket','Rocket','🚀',1000), ('castle','Castle','🏰',5000);

create table gift_transactions (
  id bigint generated always as identity primary key,
  room_id uuid not null references rooms(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  receiver_id uuid not null references profiles(id),
  gift_id text not null references gifts(id),
  qty int not null, total_coins bigint not null,
  sender_name text, receiver_name text, emoji text,   -- denormalized for the live banner
  created_at timestamptz not null default now()
);
create index on gift_transactions (room_id, created_at desc);

alter table room_seats enable row level security;
alter table gifts enable row level security;
alter table gift_transactions enable row level security;
create policy "seats readable" on room_seats for select to authenticated using (true);
create policy "gifts readable" on gifts for select to authenticated using (active);
create policy "gift log readable" on gift_transactions for select to authenticated using (true);
-- No client writes: seats and gifts change only through the functions below.

create function take_seat(p_room_id uuid, p_seat_no int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from room_members where room_id = p_room_id and user_id = auth.uid()) then
    raise exception 'Join the room first';
  end if;
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();  -- lets users switch seats
  insert into room_seats (room_id, seat_no, user_id) values (p_room_id, p_seat_no, auth.uid());
exception when unique_violation then raise exception 'That seat was just taken';
end $$;

create function leave_seat(p_room_id uuid) returns void
language sql security definer set search_path = public as $$
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();
$$;

-- Replaces 001 version: also frees the user's seat
create or replace function leave_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();
  delete from room_members where room_id = p_room_id and user_id = auth.uid();
  if found then update rooms set listener_count = greatest(listener_count - 1, 0) where id = p_room_id; end if;
end $$;

-- Atomic: deduct coins, credit receiver, log. Returns sender's new balance.
create function send_gift(p_room_id uuid, p_receiver_id uuid, p_gift_id text, p_qty int default 1)
returns bigint language plpgsql security definer set search_path = public as $$
declare g gifts%rowtype; total bigint; sender profiles%rowtype;
begin
  if p_qty < 1 or p_qty > 99 then raise exception 'Invalid quantity'; end if;
  if p_receiver_id = auth.uid() then raise exception 'You cannot gift yourself'; end if;
  select * into g from gifts where id = p_gift_id and active;
  if not found then raise exception 'Unknown gift'; end if;
  total := g.price::bigint * p_qty;
  update profiles set coins = coins - total where id = auth.uid() and coins >= total returning * into sender;
  if not found then raise exception 'Not enough coins'; end if;
  update profiles set gifts_received = gifts_received + p_qty where id = p_receiver_id;
  insert into gift_transactions (room_id, sender_id, receiver_id, gift_id, qty, total_coins, sender_name, receiver_name, emoji)
  values (p_room_id, auth.uid(), p_receiver_id, g.id, p_qty, total, sender.display_name,
          (select display_name from profiles where id = p_receiver_id), g.emoji);
  return sender.coins;
end $$;

alter publication supabase_realtime add table room_seats, gift_transactions;
-- For testing, grant yourself coins: update profiles set coins = 5000 where handle = 'user_...';


-- ==============================================================
-- 003_gaming_family.sql
-- ==============================================================
-- Gaming modes + Families. Run after 002.
create table game_modes (
  id text primary key,                                  -- e.g. 'ludo_1v1'
  game text not null check (game in ('ludo','uno','pool')),
  title text not null, subtitle text, emoji text not null,
  entry_fee int not null default 0 check (entry_fee >= 0),
  players int not null default 2,
  is_local boolean not null default false,              -- pass-the-phone play, no matchmaking
  gradient_from text not null default '7B4DFF', gradient_to text not null default 'FF5E8A',
  sort_order int not null default 0, active boolean not null default true
);
insert into game_modes (id, game, title, subtitle, emoji, entry_fee, players, is_local, gradient_from, gradient_to, sort_order) values
 ('ludo_1v1','ludo','1 ON 1','PK battle against one opponent','⚔️',50,2,false,'FF5E8A','FF8A3D',1),
 ('ludo_4p','ludo','4 Players','Race with three friends or randoms','🎲',100,4,false,'7B4DFF','4A7BFF',2),
 ('ludo_local','ludo','Local Ludo','Pass the phone, play together','📱',0,4,true,'1BA8A0','28C76F',3),
 ('uno_1v1','uno','1 ON 1','Head-to-head UNO duel','🃏',50,2,false,'FF3D5A','FF8A3D',1),
 ('uno_4p','uno','4 Players','Classic UNO table','🎴',100,4,false,'4A7BFF','7B4DFF',2),
 ('pool_1v1','pool','1 ON 1','Ranked 8-Ball match','🎱',100,2,false,'1BA8A0','4A7BFF',1),
 ('pool_practice','pool','Practice','Warm up, no entry fee','🎯',0,1,true,'28C76F','1BA8A0',2);

create sequence family_code_seq start 10000;
create table families (
  id uuid primary key default gen_random_uuid(),
  code text unique not null default ('F' || nextval('family_code_seq')::text),  -- public ID
  name text not null check (char_length(name) between 2 and 24),
  logo_url text,
  owner_id uuid not null references profiles(id),
  member_count int not null default 0,
  capacity int not null default 300,
  created_at timestamptz not null default now()
);
create index on families (member_count desc);

create table family_members (
  family_id uuid not null references families(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  primary key (family_id, user_id),
  unique (user_id)                                       -- one family per user
);

alter table game_modes enable row level security;
alter table families enable row level security;
alter table family_members enable row level security;
create policy "modes readable" on game_modes for select to authenticated using (active);
create policy "families readable" on families for select to authenticated using (true);
create policy "family members readable" on family_members for select to authenticated using (true);
-- Writes only through the functions below.

create function create_family(p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'Leave your current family first'; end if;
  insert into families (name, owner_id, member_count) values (trim(p_name), auth.uid(), 1) returning id into fid;
  insert into family_members (family_id, user_id, role) values (fid, auth.uid(), 'owner');
  return fid;
end $$;

create function join_family(p_family_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare f families%rowtype;
begin
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'Leave your current family first'; end if;
  select * into f from families where id = p_family_id for update;
  if not found then raise exception 'Family not found'; end if;
  if f.member_count >= f.capacity then raise exception 'This family is full'; end if;
  insert into family_members (family_id, user_id) values (p_family_id, auth.uid());
  update families set member_count = member_count + 1 where id = p_family_id;
end $$;

create function leave_family() returns void
language plpgsql security definer set search_path = public as $$
declare m family_members%rowtype;
begin
  select * into m from family_members where user_id = auth.uid();
  if not found then return; end if;
  if m.role = 'owner' then
    if (select member_count from families where id = m.family_id) > 1 then
      raise exception 'Transfer ownership before leaving'; end if;
    delete from families where id = m.family_id;         -- last member: family dissolves
  else
    delete from family_members where user_id = auth.uid();
    update families set member_count = greatest(member_count - 1, 0) where id = m.family_id;
  end if;
end $$;


-- ==============================================================
-- 004_messages.sql
-- ==============================================================
-- Direct messages. Run after 003.
create table messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references profiles(id) on delete cascade,
  receiver_id uuid not null references profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (sender_id <> receiver_id)
);
create index on messages (receiver_id, read_at);
create index on messages (sender_id, receiver_id, created_at desc);

alter table messages enable row level security;
create policy "read own messages" on messages for select to authenticated
  using (sender_id = auth.uid() or receiver_id = auth.uid());
create policy "send as self" on messages for insert to authenticated
  with check (sender_id = auth.uid());
-- No update/delete policies: read state changes only via the functions below.

create function mark_read(p_peer uuid) returns void
language sql security definer set search_path = public as $$
  update messages set read_at = now()
  where receiver_id = auth.uid() and sender_id = p_peer and read_at is null;
$$;

create function mark_all_read() returns void
language sql security definer set search_path = public as $$
  update messages set read_at = now() where receiver_id = auth.uid() and read_at is null;
$$;

-- One row per conversation: latest message + unread count. RLS applies (security invoker).
create function get_conversations()
returns table (peer_id uuid, display_name text, avatar_url text, last_body text, last_at timestamptz, unread_count bigint)
language sql stable security invoker set search_path = public as $$
  with m as (
    select case when sender_id = auth.uid() then receiver_id else sender_id end as peer,
           body, created_at, (receiver_id = auth.uid() and read_at is null) as is_unread
    from messages where sender_id = auth.uid() or receiver_id = auth.uid()),
  latest as (select distinct on (peer) peer, body, created_at from m order by peer, created_at desc),
  counts as (select peer, count(*) filter (where is_unread) as n from m group by peer)
  select p.id, p.display_name, p.avatar_url, l.body, l.created_at, c.n
  from latest l join counts c using (peer) join profiles p on p.id = l.peer
  order by l.created_at desc;
$$;

alter publication supabase_realtime add table messages;


-- ==============================================================
-- 005_wallet.sql
-- ==============================================================
-- Wallet + manual Bkash recharge. Run after 004.
create table app_settings (key text primary key, value text not null);
insert into app_settings values
  ('bkash_number', '01316153526'),   -- Bkash Personal number shown to users
  ('coins_per_bdt', '10'),           -- 1 BDT = 10 coins (change anytime)
  ('min_recharge_bdt', '20');
alter table app_settings enable row level security;
create policy "settings readable" on app_settings for select to authenticated using (true);

-- Ledger of every coin movement (recharges now; gifts and game fees can log here later)
create table wallet_tx (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  delta bigint not null, reason text not null, ref text,
  created_at timestamptz not null default now()
);
create index on wallet_tx (user_id, created_at desc);
alter table wallet_tx enable row level security;
create policy "own ledger" on wallet_tx for select to authenticated using (user_id = auth.uid());

create table recharge_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  method text not null default 'bkash' check (method in ('bkash')),
  amount_bdt numeric(10,2) not null check (amount_bdt > 0),
  trx_id text not null,                   -- Bkash transaction ID, stored uppercase
  sender_number text,                     -- optional: the Bkash number the money came from
  coins int not null,                     -- coins granted if approved (rate locked at request time)
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
-- A TrxID can be claimed once (rejected requests free it up so typos can be resubmitted).
create unique index recharge_trx_unique on recharge_requests (upper(trx_id)) where status <> 'rejected';
create index on recharge_requests (user_id, created_at desc);
alter table recharge_requests enable row level security;
create policy "own requests" on recharge_requests for select to authenticated using (user_id = auth.uid());

create function submit_recharge(p_amount numeric, p_trx_id text, p_sender text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare trx text := upper(trim(p_trx_id)); rate int; minimum int; rid uuid;
begin
  select value::int into rate from app_settings where key = 'coins_per_bdt';
  select value::int into minimum from app_settings where key = 'min_recharge_bdt';
  if trx !~ '^[A-Z0-9]{8,12}$' then raise exception 'Enter a valid Bkash TrxID (8 to 12 letters and numbers)'; end if;
  if p_amount is null or p_amount < minimum then raise exception 'Minimum recharge is % BDT', minimum; end if;
  if p_amount > 50000 then raise exception 'Maximum per request is 50,000 BDT'; end if;
  if (select count(*) from recharge_requests where user_id = auth.uid() and status = 'pending') >= 5 then
    raise exception 'You have 5 requests waiting. Please wait for them to be reviewed.'; end if;
  insert into recharge_requests (user_id, amount_bdt, trx_id, sender_number, coins)
  values (auth.uid(), p_amount, trx, nullif(trim(p_sender), ''), floor(p_amount * rate)::int)
  returning id into rid;
  return rid;
exception when unique_violation then raise exception 'This TrxID has already been submitted';
end $$;

-- ADMIN ONLY: run from the Supabase SQL editor after checking the payment in your Bkash app.
--   select approve_recharge('<request id>');
--   select reject_recharge('<request id>', 'TrxID not found');
create function approve_recharge(p_request_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r recharge_requests%rowtype;
begin
  select * into r from recharge_requests where id = p_request_id and status = 'pending' for update;
  if not found then raise exception 'Request not found or already reviewed'; end if;
  update recharge_requests set status = 'approved', reviewed_at = now() where id = r.id;
  update profiles set coins = coins + r.coins where id = r.user_id;
  insert into wallet_tx (user_id, delta, reason, ref) values (r.user_id, r.coins, 'bkash_recharge', r.trx_id);
end $$;

create function reject_recharge(p_request_id uuid, p_note text default null) returns void
language sql security definer set search_path = public as $$
  update recharge_requests set status = 'rejected', admin_note = p_note, reviewed_at = now()
  where id = p_request_id and status = 'pending';
$$;

-- Users must never be able to approve their own payments.
revoke execute on function approve_recharge(uuid) from public, anon, authenticated;
revoke execute on function reject_recharge(uuid, text) from public, anon, authenticated;


-- ==============================================================
-- 006_admin.sql
-- ==============================================================
-- Admin review of Bkash recharge requests from inside the app. Run after 005.
alter table profiles add column is_admin boolean not null default false;
-- Clients cannot change is_admin (only display_name/avatar/country/frame are grantable, see 001).
-- Make yourself admin from the SQL editor:
--   update profiles set is_admin = true where handle = 'user_XXXXXXXX';

alter table recharge_requests add column reviewed_by uuid references profiles(id);

create function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false);
$$;

-- Requests with the requester's identity. Pending = oldest first, others = newest first.
create function admin_list_recharges(p_status text default 'pending')
returns table (id uuid, user_id uuid, handle text, display_name text, amount_bdt numeric, trx_id text,
               sender_number text, coins int, status text, admin_note text, created_at timestamptz, reviewed_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  return query
    select r.id, r.user_id, p.handle, p.display_name, r.amount_bdt, r.trx_id, r.sender_number, r.coins,
           r.status, r.admin_note, r.created_at, r.reviewed_at
    from recharge_requests r join profiles p on p.id = r.user_id
    where r.status = p_status
    order by case when p_status = 'pending' then extract(epoch from r.created_at) else -extract(epoch from r.created_at) end
    limit 100;
end $$;

-- These wrap the locked functions from 005 and record who reviewed.
create function admin_approve_recharge(p_request_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  perform approve_recharge(p_request_id);          -- credits coins + writes the wallet ledger
  update recharge_requests set reviewed_by = auth.uid() where id = p_request_id;
end $$;

create function admin_reject_recharge(p_request_id uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  perform reject_recharge(p_request_id, nullif(trim(p_note), ''));
  update recharge_requests set reviewed_by = auth.uid() where id = p_request_id;
end $$;

-- Non-admins calling these get "Admins only"; anonymous callers cannot execute them at all.
revoke execute on function admin_list_recharges(text) from public, anon;
revoke execute on function admin_approve_recharge(uuid) from public, anon;
revoke execute on function admin_reject_recharge(uuid, text) from public, anon;


-- ==============================================================
-- 007_notifications.sql
-- ==============================================================
-- In-app notifications: admins on new recharge requests, users when coins land. Run after 006.
create table notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,                       -- recharge_request | recharge_approved | recharge_rejected
  title text not null, body text,
  data jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index on notifications (user_id, created_at desc);
create index on notifications (user_id) where read_at is null;
alter table notifications enable row level security;
create policy "own notifications" on notifications for select to authenticated using (user_id = auth.uid());
-- No client inserts/updates: rows are created by triggers, read state via the functions below.

create function mark_notification_read(p_id bigint) returns void
language sql security definer set search_path = public as $$
  update notifications set read_at = now() where id = p_id and user_id = auth.uid() and read_at is null;
$$;
create function mark_all_notifications_read() returns void
language sql security definer set search_path = public as $$
  update notifications set read_at = now() where user_id = auth.uid() and read_at is null;
$$;

-- New request -> notify every admin
create function trg_recharge_created() returns trigger
language plpgsql security definer set search_path = public as $$
declare who text;
begin
  select coalesce(display_name, 'A user') into who from profiles where id = new.user_id;
  insert into notifications (user_id, type, title, body, data)
  select id, 'recharge_request', 'New recharge request',
         '৳' || new.amount_bdt::float8::text || ' from ' || who || ' · TrxID ' || new.trx_id,
         jsonb_build_object('request_id', new.id)
  from profiles where is_admin;
  return new;
end $$;
create trigger recharge_created after insert on recharge_requests
  for each row execute function trg_recharge_created();

-- Approved / rejected -> notify the requester
create function trg_recharge_reviewed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'approved' then
    insert into notifications (user_id, type, title, body, data) values (new.user_id, 'recharge_approved',
      'Coins added 🪙', to_char(new.coins, 'FM999,999,999') || ' coins from your ৳' || new.amount_bdt::float8::text
      || ' Bkash recharge are now in your wallet.', jsonb_build_object('request_id', new.id));
  else
    insert into notifications (user_id, type, title, body, data) values (new.user_id, 'recharge_rejected',
      'Recharge not approved', coalesce(new.admin_note, 'We could not verify this payment.')
      || ' (TrxID ' || new.trx_id || ')', jsonb_build_object('request_id', new.id));
  end if;
  return new;
end $$;
create trigger recharge_reviewed after update of status on recharge_requests
  for each row when (old.status = 'pending' and new.status in ('approved', 'rejected'))
  execute function trg_recharge_reviewed();

alter publication supabase_realtime add table notifications;


-- ==============================================================
-- 008_ludo.sql
-- ==============================================================
-- Ludo match history + stats. Run after 007.
-- Games against the computer run on the phone, so results are STATS ONLY: no coins are ever
-- granted from them (a client could fake a win). Coin stakes come with server-run online matches.

create table ludo_matches (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  mode_id text references game_modes(id) on delete set null,
  player_count int not null check (player_count between 2 and 4),
  difficulty text not null check (difficulty in ('easy', 'medium', 'hard')),
  won boolean not null,
  captures int not null default 0 check (captures between 0 and 200),
  tokens_home int not null default 0 check (tokens_home between 0 and 4),
  created_at timestamptz not null default now(),
  check (not won or tokens_home = 4)             -- a win means all four tokens got home
);
create index on ludo_matches (user_id, created_at desc);

alter table ludo_matches enable row level security;
create policy "own ludo matches" on ludo_matches for select to authenticated using (user_id = auth.uid());
-- No client inserts/updates/deletes: rows are written by record_ludo_match() only.

create function record_ludo_match(
  p_mode_id text, p_players int, p_difficulty text, p_won boolean, p_captures int, p_tokens_home int
) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  -- A real game takes far longer than this; it blocks scripted spam.
  if exists (select 1 from ludo_matches where user_id = auth.uid() and created_at > now() - interval '30 seconds') then
    raise exception 'Too many results, slow down';
  end if;
  insert into ludo_matches (user_id, mode_id, player_count, difficulty, won, captures, tokens_home)
  values (
    auth.uid(),
    (select id from game_modes where id = p_mode_id and game = 'ludo'),   -- unknown mode -> null
    p_players, p_difficulty, p_won,
    greatest(coalesce(p_captures, 0), 0), greatest(coalesce(p_tokens_home, 0), 0)
  );
end $$;

create function my_ludo_stats()
returns table (played bigint, wins bigint, captures bigint)
language sql stable security definer set search_path = public as $$
  select count(*), count(*) filter (where won), coalesce(sum(captures), 0)::bigint
  from ludo_matches where user_id = auth.uid();
$$;

revoke execute on function record_ludo_match(text, int, text, boolean, int, int) from public, anon;
revoke execute on function my_ludo_stats() from public, anon;
grant execute on function record_ludo_match(text, int, text, boolean, int, int) to authenticated;
grant execute on function my_ludo_stats() to authenticated;

