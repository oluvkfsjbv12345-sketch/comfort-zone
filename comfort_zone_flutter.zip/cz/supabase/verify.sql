-- Run AFTER the migrations. Every row should say ok = true unless noted.

-- 1. Tables
select t as item, to_regclass('public.' || t) is not null as ok
from unnest(array['profiles','rooms','room_members','banners','room_seats','gifts','gift_transactions',
  'game_modes','families','family_members','messages','app_settings','wallet_tx','recharge_requests',
  'notifications','ludo_matches']) t;

-- 2. Functions
select f as item, to_regprocedure('public.' || f) is not null as ok
from unnest(array['join_room(uuid)','leave_room(uuid)','take_seat(uuid,integer)','leave_seat(uuid)',
  'send_gift(uuid,uuid,text,integer)','create_family(text)','join_family(uuid)','leave_family()',
  'mark_read(uuid)','mark_all_read()','get_conversations()','submit_recharge(numeric,text,text)',
  'approve_recharge(uuid)','reject_recharge(uuid,text)','is_admin()','admin_list_recharges(text)',
  'admin_approve_recharge(uuid)','admin_reject_recharge(uuid,text)','mark_notification_read(bigint)',
  'mark_all_notifications_read()','record_ludo_match(text,integer,text,boolean,integer,integer)',
  'my_ludo_stats()']) f;

-- 3. Row level security must be ON for every public table (all rows should be true)
select relname as item, relrowsecurity as ok
from pg_class where relnamespace = 'public'::regnamespace and relkind = 'r' order by relname;

-- 4. Realtime: expect exactly these 5 tables: gift_transactions, messages, notifications, room_seats, rooms
select tablename as item from pg_publication_tables where pubname = 'supabase_realtime' order by 1;

-- 5. Seed data: expect game_modes = 7, gifts = 6, app_settings = 3, banners >= 1
select (select count(*) from game_modes) as game_modes, (select count(*) from gifts) as gifts,
       (select count(*) from app_settings) as app_settings, (select count(*) from banners) as banners;

-- 6. Security: users must NOT approve their own payments (expect false, false, true, false)
select has_function_privilege('authenticated', 'public.approve_recharge(uuid)', 'execute')       as user_can_approve_direct,
       has_function_privilege('anon', 'public.admin_approve_recharge(uuid)', 'execute')          as anon_can_call_admin_fn,
       has_function_privilege('authenticated', 'public.admin_approve_recharge(uuid)', 'execute') as user_can_call_admin_fn_but_gets_Admins_only,
       has_function_privilege('anon', 'public.record_ludo_match(text,integer,text,boolean,integer,integer)', 'execute') as anon_can_record_ludo;
