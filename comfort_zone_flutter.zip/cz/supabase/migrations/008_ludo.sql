-- Ludo match history + stats. Run after 007.
-- Games against the computer run on the phone, so results are STATS ONLY: no coins are ever
-- granted from them (a client could fake a win). Coin stakes come with server-run online matches.

create table ludo_matches (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  mode_id text references game_modes(id) on delete set null,
  player_count int not null check (player_count between 2 and 4),
  difficulty text not null check (difficulty in ('easy', 'medium', 'hard')),
  won boolean not null,
  captures int not null default 0 check (captures between 0 and 200),
  tokens_home int not null default 0 check (tokens_home between 0 and 4),
  created_at timestamptz not null default now(),
  check (not won or tokens_home = 4)             -- a win means all four tokens got home
);
create index on ludo_matches (user_id, created_at desc);

alter table ludo_matches enable row level security;
create policy "own ludo matches" on ludo_matches for select to authenticated using (user_id = auth.uid());
-- No client inserts/updates/deletes: rows are written by record_ludo_match() only.

create function record_ludo_match(
  p_mode_id text, p_players int, p_difficulty text, p_won boolean, p_captures int, p_tokens_home int
) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  -- A real game takes far longer than this; it blocks scripted spam.
  if exists (select 1 from ludo_matches where user_id = auth.uid() and created_at > now() - interval '30 seconds') then
    raise exception 'Too many results, slow down';
  end if;
  insert into ludo_matches (user_id, mode_id, player_count, difficulty, won, captures, tokens_home)
  values (
    auth.uid(),
    (select id from game_modes where id = p_mode_id and game = 'ludo'),   -- unknown mode -> null
    p_players, p_difficulty, p_won,
    greatest(coalesce(p_captures, 0), 0), greatest(coalesce(p_tokens_home, 0), 0)
  );
end $$;

create function my_ludo_stats()
returns table (played bigint, wins bigint, captures bigint)
language sql stable security definer set search_path = public as $$
  select count(*), count(*) filter (where won), coalesce(sum(captures), 0)::bigint
  from ludo_matches where user_id = auth.uid();
$$;

revoke execute on function record_ludo_match(text, int, text, boolean, int, int) from public, anon;
revoke execute on function my_ludo_stats() from public, anon;
grant execute on function record_ludo_match(text, int, text, boolean, int, int) to authenticated;
grant execute on function my_ludo_stats() to authenticated;
