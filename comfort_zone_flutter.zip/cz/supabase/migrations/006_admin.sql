-- Admin review of Bkash recharge requests from inside the app. Run after 005.
alter table profiles add column is_admin boolean not null default false;
-- Clients cannot change is_admin (only display_name/avatar/country/frame are grantable, see 001).
-- Make yourself admin from the SQL editor:
--   update profiles set is_admin = true where handle = 'user_XXXXXXXX';

alter table recharge_requests add column reviewed_by uuid references profiles(id);

create function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false);
$$;

-- Requests with the requester's identity. Pending = oldest first, others = newest first.
create function admin_list_recharges(p_status text default 'pending')
returns table (id uuid, user_id uuid, handle text, display_name text, amount_bdt numeric, trx_id text,
               sender_number text, coins int, status text, admin_note text, created_at timestamptz, reviewed_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  return query
    select r.id, r.user_id, p.handle, p.display_name, r.amount_bdt, r.trx_id, r.sender_number, r.coins,
           r.status, r.admin_note, r.created_at, r.reviewed_at
    from recharge_requests r join profiles p on p.id = r.user_id
    where r.status = p_status
    order by case when p_status = 'pending' then extract(epoch from r.created_at) else -extract(epoch from r.created_at) end
    limit 100;
end $$;

-- These wrap the locked functions from 005 and record who reviewed.
create function admin_approve_recharge(p_request_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  perform approve_recharge(p_request_id);          -- credits coins + writes the wallet ledger
  update recharge_requests set reviewed_by = auth.uid() where id = p_request_id;
end $$;

create function admin_reject_recharge(p_request_id uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  perform reject_recharge(p_request_id, nullif(trim(p_note), ''));
  update recharge_requests set reviewed_by = auth.uid() where id = p_request_id;
end $$;

-- Non-admins calling these get "Admins only"; anonymous callers cannot execute them at all.
revoke execute on function admin_list_recharges(text) from public, anon;
revoke execute on function admin_approve_recharge(uuid) from public, anon;
revoke execute on function admin_reject_recharge(uuid, text) from public, anon;
