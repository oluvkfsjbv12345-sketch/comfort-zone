-- In-app notifications: admins on new recharge requests, users when coins land. Run after 006.
create table notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,                       -- recharge_request | recharge_approved | recharge_rejected
  title text not null, body text,
  data jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index on notifications (user_id, created_at desc);
create index on notifications (user_id) where read_at is null;
alter table notifications enable row level security;
create policy "own notifications" on notifications for select to authenticated using (user_id = auth.uid());
-- No client inserts/updates: rows are created by triggers, read state via the functions below.

create function mark_notification_read(p_id bigint) returns void
language sql security definer set search_path = public as $$
  update notifications set read_at = now() where id = p_id and user_id = auth.uid() and read_at is null;
$$;
create function mark_all_notifications_read() returns void
language sql security definer set search_path = public as $$
  update notifications set read_at = now() where user_id = auth.uid() and read_at is null;
$$;

-- New request -> notify every admin
create function trg_recharge_created() returns trigger
language plpgsql security definer set search_path = public as $$
declare who text;
begin
  select coalesce(display_name, 'A user') into who from profiles where id = new.user_id;
  insert into notifications (user_id, type, title, body, data)
  select id, 'recharge_request', 'New recharge request',
         '৳' || new.amount_bdt::float8::text || ' from ' || who || ' · TrxID ' || new.trx_id,
         jsonb_build_object('request_id', new.id)
  from profiles where is_admin;
  return new;
end $$;
create trigger recharge_created after insert on recharge_requests
  for each row execute function trg_recharge_created();

-- Approved / rejected -> notify the requester
create function trg_recharge_reviewed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'approved' then
    insert into notifications (user_id, type, title, body, data) values (new.user_id, 'recharge_approved',
      'Coins added 🪙', to_char(new.coins, 'FM999,999,999') || ' coins from your ৳' || new.amount_bdt::float8::text
      || ' Bkash recharge are now in your wallet.', jsonb_build_object('request_id', new.id));
  else
    insert into notifications (user_id, type, title, body, data) values (new.user_id, 'recharge_rejected',
      'Recharge not approved', coalesce(new.admin_note, 'We could not verify this payment.')
      || ' (TrxID ' || new.trx_id || ')', jsonb_build_object('request_id', new.id));
  end if;
  return new;
end $$;
create trigger recharge_reviewed after update of status on recharge_requests
  for each row when (old.status = 'pending' and new.status in ('approved', 'rejected'))
  execute function trg_recharge_reviewed();

alter publication supabase_realtime add table notifications;
