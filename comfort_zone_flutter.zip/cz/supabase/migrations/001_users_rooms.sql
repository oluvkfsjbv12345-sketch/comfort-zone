-- COMFORT ZONE: users + rooms schema. Run in Supabase SQL editor.
create extension if not exists pgcrypto;

-- ============ PROFILES (one row per auth user) ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  handle text unique not null,            -- public ID, e.g. user_88437282
  display_name text,
  avatar_url text,
  frame_id text,                          -- equipped avatar frame (FK to a store table later)
  country_code char(2),
  coins bigint not null default 0 check (coins >= 0),
  vip_level int not null default 0,
  followers_count int not null default 0,
  following_count int not null default 0,
  gifts_received int not null default 0,
  visitors_count int not null default 0,
  created_at timestamptz not null default now()
);

-- Auto-create a profile on signup with a generated handle
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, handle, display_name)
  values (new.id, 'user_' || lpad(floor(random()*100000000)::int::text, 8, '0'),
          coalesce(new.raw_user_meta_data->>'name', 'Guest'));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============ ROOMS ============
create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 60),
  cover_url text,
  agency_name text,
  country_code char(2),
  category text not null default 'party' check (category in ('party','activity','chat')),
  listener_count int not null default 0 check (listener_count >= 0),
  is_live boolean not null default true,
  agora_channel text unique not null default replace(gen_random_uuid()::text,'-',''),
  created_at timestamptz not null default now()
);
create index rooms_hot_idx on public.rooms (is_live, listener_count desc);
create index rooms_country_idx on public.rooms (country_code, listener_count desc);

create table public.room_members (
  room_id uuid references public.rooms(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  role text not null default 'listener' check (role in ('owner','admin','speaker','listener')),
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null, subtitle text,
  gradient_from text not null default '7B4DFF',   -- hex, no '#'
  gradient_to text not null default 'FF5E8A',
  sort_order int not null default 0,
  active boolean not null default true
);

-- ============ JOIN / LEAVE (keeps listener_count accurate) ============
create function public.join_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into room_members (room_id, user_id) values (p_room_id, auth.uid())
  on conflict do nothing;
  if found then update rooms set listener_count = listener_count + 1 where id = p_room_id; end if;
end $$;

create function public.leave_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from room_members where room_id = p_room_id and user_id = auth.uid();
  if found then update rooms set listener_count = greatest(listener_count - 1, 0) where id = p_room_id; end if;
end $$;

-- ============ ROW LEVEL SECURITY ============
alter table profiles enable row level security;
alter table rooms enable row level security;
alter table room_members enable row level security;
alter table banners enable row level security;

create policy "profiles readable" on profiles for select to authenticated using (true);
create policy "own profile update" on profiles for update to authenticated using (id = auth.uid());
-- Clients may NOT touch coins/vip/counters; those change via server functions only.
revoke update on profiles from authenticated;
grant update (display_name, avatar_url, country_code, frame_id) on profiles to authenticated;

create policy "rooms readable" on rooms for select to authenticated using (true);
create policy "create own room" on rooms for insert to authenticated with check (owner_id = auth.uid());
create policy "owner edits room" on rooms for update to authenticated using (owner_id = auth.uid());
create policy "owner deletes room" on rooms for delete to authenticated using (owner_id = auth.uid());
revoke update on rooms from authenticated;
grant update (title, cover_url, agency_name, category, is_live) on rooms to authenticated;

create policy "members readable" on room_members for select to authenticated using (true);
create policy "banners readable" on banners for select to authenticated using (active);

-- Live listener counts in the app
alter publication supabase_realtime add table public.rooms;

-- Demo banner
insert into banners (title, subtitle) values ('Family Coin Chase', 'Team up, collect coins, win big');
