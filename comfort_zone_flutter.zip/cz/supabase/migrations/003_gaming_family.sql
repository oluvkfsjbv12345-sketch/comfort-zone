-- Gaming modes + Families. Run after 002.
create table game_modes (
  id text primary key,                                  -- e.g. 'ludo_1v1'
  game text not null check (game in ('ludo','uno','pool')),
  title text not null, subtitle text, emoji text not null,
  entry_fee int not null default 0 check (entry_fee >= 0),
  players int not null default 2,
  is_local boolean not null default false,              -- pass-the-phone play, no matchmaking
  gradient_from text not null default '7B4DFF', gradient_to text not null default 'FF5E8A',
  sort_order int not null default 0, active boolean not null default true
);
insert into game_modes (id, game, title, subtitle, emoji, entry_fee, players, is_local, gradient_from, gradient_to, sort_order) values
 ('ludo_1v1','ludo','1 ON 1','PK battle against one opponent','⚔️',50,2,false,'FF5E8A','FF8A3D',1),
 ('ludo_4p','ludo','4 Players','Race with three friends or randoms','🎲',100,4,false,'7B4DFF','4A7BFF',2),
 ('ludo_local','ludo','Local Ludo','Pass the phone, play together','📱',0,4,true,'1BA8A0','28C76F',3),
 ('uno_1v1','uno','1 ON 1','Head-to-head UNO duel','🃏',50,2,false,'FF3D5A','FF8A3D',1),
 ('uno_4p','uno','4 Players','Classic UNO table','🎴',100,4,false,'4A7BFF','7B4DFF',2),
 ('pool_1v1','pool','1 ON 1','Ranked 8-Ball match','🎱',100,2,false,'1BA8A0','4A7BFF',1),
 ('pool_practice','pool','Practice','Warm up, no entry fee','🎯',0,1,true,'28C76F','1BA8A0',2);

create sequence family_code_seq start 10000;
create table families (
  id uuid primary key default gen_random_uuid(),
  code text unique not null default ('F' || nextval('family_code_seq')::text),  -- public ID
  name text not null check (char_length(name) between 2 and 24),
  logo_url text,
  owner_id uuid not null references profiles(id),
  member_count int not null default 0,
  capacity int not null default 300,
  created_at timestamptz not null default now()
);
create index on families (member_count desc);

create table family_members (
  family_id uuid not null references families(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  primary key (family_id, user_id),
  unique (user_id)                                       -- one family per user
);

alter table game_modes enable row level security;
alter table families enable row level security;
alter table family_members enable row level security;
create policy "modes readable" on game_modes for select to authenticated using (active);
create policy "families readable" on families for select to authenticated using (true);
create policy "family members readable" on family_members for select to authenticated using (true);
-- Writes only through the functions below.

create function create_family(p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'Leave your current family first'; end if;
  insert into families (name, owner_id, member_count) values (trim(p_name), auth.uid(), 1) returning id into fid;
  insert into family_members (family_id, user_id, role) values (fid, auth.uid(), 'owner');
  return fid;
end $$;

create function join_family(p_family_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare f families%rowtype;
begin
  if exists (select 1 from family_members where user_id = auth.uid()) then
    raise exception 'Leave your current family first'; end if;
  select * into f from families where id = p_family_id for update;
  if not found then raise exception 'Family not found'; end if;
  if f.member_count >= f.capacity then raise exception 'This family is full'; end if;
  insert into family_members (family_id, user_id) values (p_family_id, auth.uid());
  update families set member_count = member_count + 1 where id = p_family_id;
end $$;

create function leave_family() returns void
language plpgsql security definer set search_path = public as $$
declare m family_members%rowtype;
begin
  select * into m from family_members where user_id = auth.uid();
  if not found then return; end if;
  if m.role = 'owner' then
    if (select member_count from families where id = m.family_id) > 1 then
      raise exception 'Transfer ownership before leaving'; end if;
    delete from families where id = m.family_id;         -- last member: family dissolves
  else
    delete from family_members where user_id = auth.uid();
    update families set member_count = greatest(member_count - 1, 0) where id = m.family_id;
  end if;
end $$;
