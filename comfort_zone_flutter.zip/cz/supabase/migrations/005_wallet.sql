-- Wallet + manual Bkash recharge. Run after 004.
create table app_settings (key text primary key, value text not null);
insert into app_settings values
  ('bkash_number', '01316153526'),   -- Bkash Personal number shown to users
  ('coins_per_bdt', '10'),           -- 1 BDT = 10 coins (change anytime)
  ('min_recharge_bdt', '20');
alter table app_settings enable row level security;
create policy "settings readable" on app_settings for select to authenticated using (true);

-- Ledger of every coin movement (recharges now; gifts and game fees can log here later)
create table wallet_tx (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  delta bigint not null, reason text not null, ref text,
  created_at timestamptz not null default now()
);
create index on wallet_tx (user_id, created_at desc);
alter table wallet_tx enable row level security;
create policy "own ledger" on wallet_tx for select to authenticated using (user_id = auth.uid());

create table recharge_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  method text not null default 'bkash' check (method in ('bkash')),
  amount_bdt numeric(10,2) not null check (amount_bdt > 0),
  trx_id text not null,                   -- Bkash transaction ID, stored uppercase
  sender_number text,                     -- optional: the Bkash number the money came from
  coins int not null,                     -- coins granted if approved (rate locked at request time)
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
-- A TrxID can be claimed once (rejected requests free it up so typos can be resubmitted).
create unique index recharge_trx_unique on recharge_requests (upper(trx_id)) where status <> 'rejected';
create index on recharge_requests (user_id, created_at desc);
alter table recharge_requests enable row level security;
create policy "own requests" on recharge_requests for select to authenticated using (user_id = auth.uid());

create function submit_recharge(p_amount numeric, p_trx_id text, p_sender text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare trx text := upper(trim(p_trx_id)); rate int; minimum int; rid uuid;
begin
  select value::int into rate from app_settings where key = 'coins_per_bdt';
  select value::int into minimum from app_settings where key = 'min_recharge_bdt';
  if trx !~ '^[A-Z0-9]{8,12}$' then raise exception 'Enter a valid Bkash TrxID (8 to 12 letters and numbers)'; end if;
  if p_amount is null or p_amount < minimum then raise exception 'Minimum recharge is % BDT', minimum; end if;
  if p_amount > 50000 then raise exception 'Maximum per request is 50,000 BDT'; end if;
  if (select count(*) from recharge_requests where user_id = auth.uid() and status = 'pending') >= 5 then
    raise exception 'You have 5 requests waiting. Please wait for them to be reviewed.'; end if;
  insert into recharge_requests (user_id, amount_bdt, trx_id, sender_number, coins)
  values (auth.uid(), p_amount, trx, nullif(trim(p_sender), ''), floor(p_amount * rate)::int)
  returning id into rid;
  return rid;
exception when unique_violation then raise exception 'This TrxID has already been submitted';
end $$;

-- ADMIN ONLY: run from the Supabase SQL editor after checking the payment in your Bkash app.
--   select approve_recharge('<request id>');
--   select reject_recharge('<request id>', 'TrxID not found');
create function approve_recharge(p_request_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r recharge_requests%rowtype;
begin
  select * into r from recharge_requests where id = p_request_id and status = 'pending' for update;
  if not found then raise exception 'Request not found or already reviewed'; end if;
  update recharge_requests set status = 'approved', reviewed_at = now() where id = r.id;
  update profiles set coins = coins + r.coins where id = r.user_id;
  insert into wallet_tx (user_id, delta, reason, ref) values (r.user_id, r.coins, 'bkash_recharge', r.trx_id);
end $$;

create function reject_recharge(p_request_id uuid, p_note text default null) returns void
language sql security definer set search_path = public as $$
  update recharge_requests set status = 'rejected', admin_note = p_note, reviewed_at = now()
  where id = p_request_id and status = 'pending';
$$;

-- Users must never be able to approve their own payments.
revoke execute on function approve_recharge(uuid) from public, anon, authenticated;
revoke execute on function reject_recharge(uuid, text) from public, anon, authenticated;
