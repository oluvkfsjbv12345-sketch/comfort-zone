-- Direct messages. Run after 003.
create table messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references profiles(id) on delete cascade,
  receiver_id uuid not null references profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (sender_id <> receiver_id)
);
create index on messages (receiver_id, read_at);
create index on messages (sender_id, receiver_id, created_at desc);

alter table messages enable row level security;
create policy "read own messages" on messages for select to authenticated
  using (sender_id = auth.uid() or receiver_id = auth.uid());
create policy "send as self" on messages for insert to authenticated
  with check (sender_id = auth.uid());
-- No update/delete policies: read state changes only via the functions below.

create function mark_read(p_peer uuid) returns void
language sql security definer set search_path = public as $$
  update messages set read_at = now()
  where receiver_id = auth.uid() and sender_id = p_peer and read_at is null;
$$;

create function mark_all_read() returns void
language sql security definer set search_path = public as $$
  update messages set read_at = now() where receiver_id = auth.uid() and read_at is null;
$$;

-- One row per conversation: latest message + unread count. RLS applies (security invoker).
create function get_conversations()
returns table (peer_id uuid, display_name text, avatar_url text, last_body text, last_at timestamptz, unread_count bigint)
language sql stable security invoker set search_path = public as $$
  with m as (
    select case when sender_id = auth.uid() then receiver_id else sender_id end as peer,
           body, created_at, (receiver_id = auth.uid() and read_at is null) as is_unread
    from messages where sender_id = auth.uid() or receiver_id = auth.uid()),
  latest as (select distinct on (peer) peer, body, created_at from m order by peer, created_at desc),
  counts as (select peer, count(*) filter (where is_unread) as n from m group by peer)
  select p.id, p.display_name, p.avatar_url, l.body, l.created_at, c.n
  from latest l join counts c using (peer) join profiles p on p.id = l.peer
  order by l.created_at desc;
$$;

alter publication supabase_realtime add table messages;
