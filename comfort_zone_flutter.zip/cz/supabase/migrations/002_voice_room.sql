-- Voice room: seats, gifts, coin-safe gifting. Run after 001.
alter table profiles add column agora_uid int generated always as identity unique;

create table room_seats (
  room_id uuid references rooms(id) on delete cascade,
  seat_no int not null check (seat_no between 1 and 8),
  user_id uuid not null references profiles(id) on delete cascade,
  taken_at timestamptz not null default now(),
  primary key (room_id, seat_no),
  unique (room_id, user_id)             -- one seat per user per room
);

create table gifts (
  id text primary key, name text not null, emoji text not null,
  price int not null check (price > 0), active boolean not null default true
);
insert into gifts (id, name, emoji, price) values
  ('rose','Rose','🌹',10), ('heart','Heart','💖',50), ('cake','Cake','🎂',120),
  ('crown','Crown','👑',500), ('rocket','Rocket','🚀',1000), ('castle','Castle','🏰',5000);

create table gift_transactions (
  id bigint generated always as identity primary key,
  room_id uuid not null references rooms(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  receiver_id uuid not null references profiles(id),
  gift_id text not null references gifts(id),
  qty int not null, total_coins bigint not null,
  sender_name text, receiver_name text, emoji text,   -- denormalized for the live banner
  created_at timestamptz not null default now()
);
create index on gift_transactions (room_id, created_at desc);

alter table room_seats enable row level security;
alter table gifts enable row level security;
alter table gift_transactions enable row level security;
create policy "seats readable" on room_seats for select to authenticated using (true);
create policy "gifts readable" on gifts for select to authenticated using (active);
create policy "gift log readable" on gift_transactions for select to authenticated using (true);
-- No client writes: seats and gifts change only through the functions below.

create function take_seat(p_room_id uuid, p_seat_no int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from room_members where room_id = p_room_id and user_id = auth.uid()) then
    raise exception 'Join the room first';
  end if;
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();  -- lets users switch seats
  insert into room_seats (room_id, seat_no, user_id) values (p_room_id, p_seat_no, auth.uid());
exception when unique_violation then raise exception 'That seat was just taken';
end $$;

create function leave_seat(p_room_id uuid) returns void
language sql security definer set search_path = public as $$
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();
$$;

-- Replaces 001 version: also frees the user's seat
create or replace function leave_room(p_room_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from room_seats where room_id = p_room_id and user_id = auth.uid();
  delete from room_members where room_id = p_room_id and user_id = auth.uid();
  if found then update rooms set listener_count = greatest(listener_count - 1, 0) where id = p_room_id; end if;
end $$;

-- Atomic: deduct coins, credit receiver, log. Returns sender's new balance.
create function send_gift(p_room_id uuid, p_receiver_id uuid, p_gift_id text, p_qty int default 1)
returns bigint language plpgsql security definer set search_path = public as $$
declare g gifts%rowtype; total bigint; sender profiles%rowtype;
begin
  if p_qty < 1 or p_qty > 99 then raise exception 'Invalid quantity'; end if;
  if p_receiver_id = auth.uid() then raise exception 'You cannot gift yourself'; end if;
  select * into g from gifts where id = p_gift_id and active;
  if not found then raise exception 'Unknown gift'; end if;
  total := g.price::bigint * p_qty;
  update profiles set coins = coins - total where id = auth.uid() and coins >= total returning * into sender;
  if not found then raise exception 'Not enough coins'; end if;
  update profiles set gifts_received = gifts_received + p_qty where id = p_receiver_id;
  insert into gift_transactions (room_id, sender_id, receiver_id, gift_id, qty, total_coins, sender_name, receiver_name, emoji)
  values (p_room_id, auth.uid(), p_receiver_id, g.id, p_qty, total, sender.display_name,
          (select display_name from profiles where id = p_receiver_id), g.emoji);
  return sender.coins;
end $$;

alter publication supabase_realtime add table room_seats, gift_transactions;
-- For testing, grant yourself coins: update profiles set coins = 5000 where handle = 'user_...';
