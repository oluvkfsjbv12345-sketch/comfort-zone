# Comfort Zone

Flutter app + Supabase backend.

**First-time setup: see `docs/SETUP.md`** (কম্পিউটার নেই? দেখুন `docs/APK_FROM_MOBILE.md`) (Supabase migrations, Android/iOS config, run and test checklist).

## Backend setup
Run the migrations in `supabase/migrations/` in order (001 -> 008) in the Supabase SQL editor.
`008_ludo.sql` adds Ludo match history: `record_ludo_match()` and `my_ludo_stats()`.
The app still works if 008 is not applied yet; Ludo just won't save stats.

Deploy the token function: `supabase functions deploy agora-token`.

## Run
```
flutter pub get
flutter run \
  --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=... \
  --dart-define=AGORA_APP_ID=...
```
Without `SUPABASE_URL` the app runs in mock mode (demo data, no backend).

## Ludo
- `lib/games/ludo/`: engine (rules), bot (Easy/Medium/Hard), board painter, game screen.
- Local Ludo = pass the phone. 1v1 / 4-player modes = play vs computer until online matchmaking exists.
- Results vs computer are saved as stats only. They never grant coins.

## Tests
`flutter test`
