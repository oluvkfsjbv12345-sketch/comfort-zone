import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/room.dart';

/// All room data access lives here so screens never touch Supabase directly.
class RoomRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;

  /// [category]: 'all' | 'party' | 'activity'. [countryCode] filters by region.
  Future<List<Room>> fetchRooms({String category = 'all', String? countryCode}) async {
    if (_db == null) {
      return _demoRooms.where((r) =>
          (category == 'all' || r.category == category) &&
          (countryCode == null || r.countryCode == countryCode)).toList();
    }
    var q = _db.from('rooms').select().eq('is_live', true);
    if (category != 'all') q = q.eq('category', category);
    if (countryCode != null) q = q.eq('country_code', countryCode);
    final rows = await q.order('listener_count', ascending: false).limit(50);
    return rows.map(Room.fromMap).toList();
  }

  Future<List<PromoBanner>> fetchBanners() async {
    if (_db == null) return _demoBanners;
    final rows = await _db.from('banners').select().eq('active', true).order('sort_order');
    return rows.map(PromoBanner.fromMap).toList();
  }

  /// Server-side RPC keeps listener_count consistent. Agora join happens after this.
  Future<void> joinRoom(String roomId) async {
    if (_db == null) return;
    await _db.rpc('join_room', params: {'p_room_id': roomId});
  }
}

const _demoBanners = [
  PromoBanner('Family Coin Chase', 'Team up, collect coins, win big', Brand.violet, Brand.coral),
  PromoBanner('Weekend Party Night', 'Double gifts in every room', Color(0xFFFF8A3D), Color(0xFFFF3D81)),
];

const _demoRooms = [
  Room(id: '1', title: 'P.A. OFFICIAL ADARSH AGENCY', agencyName: 'Official', countryCode: 'IN', listenerCount: 1284),
  Room(id: '2', title: 'Midnight Lounge', agencyName: 'Star Agency', countryCode: 'PK', listenerCount: 842),
  Room(id: '3', title: 'Karaoke Kings', agencyName: 'Melody', countryCode: 'BD', listenerCount: 611, category: 'activity'),
  Room(id: '4', title: 'Friends & Chill', agencyName: 'Open', countryCode: 'IN', listenerCount: 397),
];
