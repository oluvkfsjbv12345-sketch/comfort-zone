import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/game.dart';

class GameRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;

  Future<int> coins() async {
    if (_db == null) return 1200;
    final r = await _db.from('profiles').select('coins').eq('id', _db.auth.currentUser!.id).single();
    return (r['coins'] as num).toInt();
  }

  Future<List<GameMode>> modes() async {
    if (_db == null) return _demo;
    final rows = await _db.from('game_modes').select().eq('active', true).order('sort_order');
    return rows.map(GameMode.fromMap).toList();
  }
}

const _demo = [
  GameMode(id: 'ludo_1v1', game: 'ludo', title: '1 ON 1', subtitle: 'PK battle against one opponent', emoji: '⚔️', entryFee: 50, from: Color(0xFFFF5E8A), to: Color(0xFFFF8A3D)),
  GameMode(id: 'ludo_4p', game: 'ludo', title: '4 Players', subtitle: 'Race with three friends or randoms', emoji: '🎲', entryFee: 100, players: 4),
  GameMode(id: 'ludo_local', game: 'ludo', title: 'Local Ludo', subtitle: 'Pass the phone, play together', emoji: '📱', players: 4, isLocal: true, from: Color(0xFF1BA8A0), to: Color(0xFF28C76F)),
  GameMode(id: 'uno_1v1', game: 'uno', title: '1 ON 1', subtitle: 'Head-to-head UNO duel', emoji: '🃏', entryFee: 50, from: Color(0xFFFF3D5A), to: Color(0xFFFF8A3D)),
  GameMode(id: 'uno_4p', game: 'uno', title: '4 Players', subtitle: 'Classic UNO table', emoji: '🎴', entryFee: 100, players: 4, from: Color(0xFF4A7BFF), to: Color(0xFF7B4DFF)),
  GameMode(id: 'pool_1v1', game: 'pool', title: '1 ON 1', subtitle: 'Ranked 8-Ball match', emoji: '🎱', entryFee: 100, from: Color(0xFF1BA8A0), to: Color(0xFF4A7BFF)),
  GameMode(id: 'pool_practice', game: 'pool', title: 'Practice', subtitle: 'Warm up, no entry fee', emoji: '🎯', players: 1, isLocal: true, from: Color(0xFF28C76F), to: Color(0xFF1BA8A0)),
];
