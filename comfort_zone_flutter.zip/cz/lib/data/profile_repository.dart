import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/social.dart';

class ProfileRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;
  static UserProfile _demo = const UserProfile(id: 'me', handle: 'user_88437282', name: 'You', coins: 1200);

  Future<UserProfile> me() async {
    if (_db == null) return _demo;
    final r = await _db.from('profiles')
        .select('id, handle, display_name, avatar_url, country_code, coins, followers_count, following_count, gifts_received, visitors_count')
        .eq('id', _db.auth.currentUser!.id).single();
    return UserProfile.fromMap(r);
  }

  /// Only display_name / country_code are editable by the client (see column grants in 001).
  Future<void> update({required String name, String? country}) async {
    if (_db == null) {
      _demo = UserProfile(id: _demo.id, handle: _demo.handle, name: name, countryCode: country, coins: _demo.coins);
      return;
    }
    await _db.from('profiles').update({'display_name': name, 'country_code': country}).eq('id', _db.auth.currentUser!.id);
  }

  Future<void> signOut() async => _db?.auth.signOut();
}
