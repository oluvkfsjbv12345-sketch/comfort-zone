import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/wallet.dart';

class WalletRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;
  static final List<RechargeRequest> _demo = [];

  Future<WalletConfig> config() async {
    if (_db == null) return WalletConfig.fallback;
    try { return WalletConfig.fromRows(await _db.from('app_settings').select()); }
    catch (_) { return WalletConfig.fallback; }
  }

  Future<List<RechargeRequest>> requests() async {
    if (_db == null) return List.of(_demo.reversed);
    final rows = await _db.from('recharge_requests').select().order('created_at', ascending: false).limit(20);
    return rows.map(RechargeRequest.fromMap).toList();
  }

  /// Creates a pending request. An admin approves it after checking the Bkash payment.
  Future<void> submit({required num amount, required String trxId, String? sender}) async {
    if (_db == null) {
      _demo.add(RechargeRequest(id: '${_demo.length}', trxId: trxId.toUpperCase(), status: 'pending',
          amountBdt: amount, coins: (amount * WalletConfig.fallback.coinsPerBdt).floor(), createdAt: DateTime.now()));
      return;
    }
    await _db.rpc('submit_recharge', params: {'p_amount': amount, 'p_trx_id': trxId, 'p_sender': sender});
  }
}
