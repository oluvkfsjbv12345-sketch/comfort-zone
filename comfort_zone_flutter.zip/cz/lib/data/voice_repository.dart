import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/voice.dart';

/// Seats, gifts and Agora tokens. Falls back to in-memory demo data without a backend.
class VoiceRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;

  // ---- demo state (mock mode only) ----
  static final List<Seat> _mockSeats = [
    const Seat(no: 1, userId: 'host', agoraUid: 1, name: 'Adarsh'),
    const Seat(no: 3, userId: 'u2', agoraUid: 2, name: 'Sana'),
  ];
  static int _mockCoins = 1200;

  Future<MyProfile> me() async {
    if (_db == null) return MyProfile('me', 99, 'You', _mockCoins);
    final r = await _db.from('profiles').select('id, agora_uid, display_name, coins')
        .eq('id', _db.auth.currentUser!.id).single();
    return MyProfile(r['id'], r['agora_uid'], r['display_name'] ?? 'Guest', (r['coins'] as num).toInt());
  }

  Future<void> joinRoom(String id) async => _db?.rpc('join_room', params: {'p_room_id': id});
  Future<void> leaveRoom(String id) async => _db?.rpc('leave_room', params: {'p_room_id': id});

  Future<List<Seat>> seats(String roomId) async {
    if (_db == null) return List.of(_mockSeats);
    final rows = await _db.from('room_seats')
        .select('seat_no, user_id, profiles(display_name, avatar_url, agora_uid)').eq('room_id', roomId);
    return rows.map(Seat.fromMap).toList();
  }

  Future<void> takeSeat(String roomId, int no) async {
    if (_db == null) {
      _mockSeats.removeWhere((s) => s.userId == 'me');
      _mockSeats.add(Seat(no: no, userId: 'me', agoraUid: 99, name: 'You'));
      return;
    }
    await _db.rpc('take_seat', params: {'p_room_id': roomId, 'p_seat_no': no});
  }

  Future<void> leaveSeat(String roomId) async {
    if (_db == null) { _mockSeats.removeWhere((s) => s.userId == 'me'); return; }
    await _db.rpc('leave_seat', params: {'p_room_id': roomId});
  }

  /// Subscribers get a listen-only token; publishers only if the server sees them in a seat.
  Future<String> agoraToken(String channel, int uid, {required bool publisher}) async {
    final res = await _db!.functions.invoke('agora-token',
        body: {'channel': channel, 'uid': uid, 'role': publisher ? 'publisher' : 'subscriber'});
    return res.data['token'] as String;
  }

  Future<List<Gift>> gifts() async {
    if (_db == null) {
      return const [Gift('rose', 'Rose', '🌹', 10), Gift('heart', 'Heart', '💖', 50),
        Gift('crown', 'Crown', '👑', 500), Gift('rocket', 'Rocket', '🚀', 1000)];
    }
    final rows = await _db.from('gifts').select().eq('active', true).order('price');
    return rows.map(Gift.fromMap).toList();
  }

  /// Returns the sender's new coin balance.
  Future<int> sendGift(String roomId, String receiverId, Gift g, int qty) async {
    if (_db == null) {
      if (_mockCoins < g.price * qty) throw 'Not enough coins';
      return _mockCoins -= g.price * qty;
    }
    final r = await _db.rpc('send_gift',
        params: {'p_room_id': roomId, 'p_receiver_id': receiverId, 'p_gift_id': g.id, 'p_qty': qty});
    return (r as num).toInt();
  }

  /// Realtime: seat changes trigger [onSeats]; new gifts trigger [onGift].
  RealtimeChannel? watch(String roomId, {required VoidCallback onSeats, required void Function(GiftEvent) onGift}) {
    if (_db == null) return null;
    final f = PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'room_id', value: roomId);
    return _db.channel('room:$roomId')
        .onPostgresChanges(event: PostgresChangeEvent.all, schema: 'public', table: 'room_seats',
            filter: f, callback: (_) => onSeats())
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'gift_transactions',
            filter: f, callback: (p) => onGift(GiftEvent.fromMap(p.newRecord)))
        .subscribe();
  }

  Future<void> unwatch(RealtimeChannel? c) async { if (c != null) await _db?.removeChannel(c); }
}
