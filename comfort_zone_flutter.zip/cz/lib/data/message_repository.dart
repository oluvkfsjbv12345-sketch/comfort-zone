import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/social.dart';

class MessageRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;
  String get myId => _db?.auth.currentUser?.id ?? 'me';

  // ---- demo state (mock mode only) ----
  static final List<Conversation> _demoConvs = [
    Conversation(peerId: 'a', name: 'Aarav', lastBody: 'Are you joining the room tonight?', lastAt: DateTime.now().subtract(const Duration(minutes: 2)), unread: 3),
    Conversation(peerId: 'b', name: 'Sana', lastBody: 'Sent you a gift 🎁', lastAt: DateTime.now().subtract(const Duration(minutes: 14)), unread: 1),
    Conversation(peerId: 'c', name: 'Rohan', lastBody: 'GG! Rematch on Ludo?', lastAt: DateTime.now().subtract(const Duration(hours: 1))),
  ];
  static final Map<String, List<ChatMessage>> _demoChats = {};

  Future<List<Conversation>> conversations() async {
    if (_db == null) return List.of(_demoConvs);
    final rows = await _db.rpc('get_conversations') as List;
    return rows.map((r) => Conversation.fromMap(r as Map<String, dynamic>)).toList();
  }

  Future<int> unreadTotal() async => (await conversations()).fold<int>(0, (a, c) => a + c.unread);

  Future<List<ChatMessage>> thread(String peer) async {
    if (_db == null) return List.of(_demoChats[peer] ?? []);
    final rows = await _db.from('messages').select()
        .or('and(sender_id.eq.$myId,receiver_id.eq.$peer),and(sender_id.eq.$peer,receiver_id.eq.$myId)')
        .order('created_at').limit(200);
    return rows.map(ChatMessage.fromMap).toList();
  }

  Future<ChatMessage> send(String peer, String body) async {
    if (_db == null) {
      final m = ChatMessage(id: '${DateTime.now().microsecondsSinceEpoch}', senderId: 'me', body: body, at: DateTime.now());
      (_demoChats[peer] ??= []).add(m);
      return m;
    }
    final r = await _db.from('messages').insert({'sender_id': myId, 'receiver_id': peer, 'body': body}).select().single();
    return ChatMessage.fromMap(r);
  }

  Future<void> markRead(String peer) async {
    if (_db == null) {
      final i = _demoConvs.indexWhere((c) => c.peerId == peer);
      if (i >= 0) { final c = _demoConvs[i]; _demoConvs[i] = Conversation(peerId: c.peerId, name: c.name, lastBody: c.lastBody, lastAt: c.lastAt); }
      return;
    }
    await _db.rpc('mark_read', params: {'p_peer': peer});
  }

  Future<void> markAllRead() async {
    if (_db == null) {
      for (var i = 0; i < _demoConvs.length; i++) {
        final c = _demoConvs[i];
        _demoConvs[i] = Conversation(peerId: c.peerId, name: c.name, lastBody: c.lastBody, lastAt: c.lastAt);
      }
      return;
    }
    await _db.rpc('mark_all_read');
  }

  /// Look a user up by their public ID (e.g. user_88437282) to start a chat.
  Future<Conversation?> findByHandle(String handle) async {
    if (_db == null) return Conversation(peerId: 'x', name: handle, lastAt: DateTime.now());
    final r = await _db.from('profiles').select('id, display_name, avatar_url').eq('handle', handle.trim()).maybeSingle();
    if (r == null || r['id'] == myId) return null;
    return Conversation(peerId: r['id'], name: (r['display_name'] ?? 'Guest') as String, avatarUrl: r['avatar_url'], lastAt: DateTime.now());
  }

  /// New messages sent to me. Use a distinct [name] per subscriber.
  RealtimeChannel? watchIncoming(void Function(ChatMessage) onNew, {String name = 'inbox'}) {
    if (_db == null) return null;
    return _db.channel('$name:$myId')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'messages',
            filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'receiver_id', value: myId),
            callback: (p) => onNew(ChatMessage.fromMap(p.newRecord)))
        .subscribe();
  }

  Future<void> unwatch(RealtimeChannel? c) async { if (c != null) await _db?.removeChannel(c); }
}
