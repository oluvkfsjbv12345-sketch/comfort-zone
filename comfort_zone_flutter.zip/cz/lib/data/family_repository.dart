import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/game.dart';

class FamilyRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;

  // ---- demo state (mock mode only) ----
  static final List<Family> _demo = [
    const Family(id: '1', code: 'F10293', name: 'Royal Wolves', memberCount: 167),
    const Family(id: '2', code: 'F88412', name: 'Sunset Squad', memberCount: 212),
    const Family(id: '3', code: 'F55120', name: 'Night Owls', memberCount: 300),
  ];
  static Family? _demoMine;

  Future<List<Family>> recommended() async {
    if (_db == null) return List.of(_demo);
    final rows = await _db.from('families').select().order('member_count', ascending: false).limit(30);
    return rows.map(Family.fromMap).toList();
  }

  Future<Family?> mine() async {
    if (_db == null) return _demoMine;
    final r = await _db.from('family_members').select('families(*)').eq('user_id', _db.auth.currentUser!.id).maybeSingle();
    final f = r?['families'];
    return f == null ? null : Family.fromMap(f as Map<String, dynamic>);
  }

  Future<void> create(String name) async {
    if (_db == null) {
      _demoMine = Family(id: 'mine', code: 'F10001', name: name, memberCount: 1);
      return;
    }
    await _db.rpc('create_family', params: {'p_name': name});
  }

  Future<void> join(Family f) async {
    if (_db == null) {
      if (_demoMine != null) throw 'Leave your current family first';
      _demoMine = Family(id: f.id, code: f.code, name: f.name, memberCount: f.memberCount + 1);
      return;
    }
    await _db.rpc('join_family', params: {'p_family_id': f.id});
  }

  Future<void> leave() async {
    if (_db == null) { _demoMine = null; return; }
    await _db.rpc('leave_family');
  }
}
