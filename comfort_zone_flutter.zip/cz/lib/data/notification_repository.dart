import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/notification.dart';

class NotificationRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;
  String get _me => _db!.auth.currentUser!.id;

  Future<List<AppNotification>> list() async {
    if (_db == null) {
      return [AppNotification(id: 1, type: 'recharge_approved', title: 'Coins added 🪙',
          body: '5,000 coins from your ৳500 Bkash recharge are now in your wallet.', createdAt: DateTime.now().subtract(const Duration(minutes: 5)))];
    }
    final rows = await _db.from('notifications').select().order('created_at', ascending: false).limit(50);
    return rows.map(AppNotification.fromMap).toList();
  }

  Future<int> unreadCount() async {
    if (_db == null) return 0;
    final rows = await _db.from('notifications').select('id').eq('user_id', _me).isFilter('read_at', null);
    return rows.length;
  }

  Future<void> markRead(int id) async => _db?.rpc('mark_notification_read', params: {'p_id': id});
  Future<void> markAllRead() async => _db?.rpc('mark_all_notifications_read');

  RealtimeChannel? watch(void Function(AppNotification) onNew) {
    if (_db == null) return null;
    return _db.channel('notif:$_me')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'notifications',
            filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'user_id', value: _me),
            callback: (p) => onNew(AppNotification.fromMap(p.newRecord)))
        .subscribe();
  }

  Future<void> unwatch(RealtimeChannel? c) async { if (c != null) await _db?.removeChannel(c); }
}
