import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/ludo_stats.dart';

/// Ludo results are stats only. They never grant coins (see 008_ludo.sql).
class LudoRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;
  static LudoStats _demo = const LudoStats();

  Future<LudoStats> stats() async {
    if (_db == null) return _demo;
    final rows = await _db.rpc('my_ludo_stats');
    final list = rows as List;
    return list.isEmpty ? const LudoStats() : LudoStats.fromMap(Map<String, dynamic>.from(list.first as Map));
  }

  Future<void> recordMatch({
    required String? modeId,
    required int players,
    required String difficulty,
    required bool won,
    required int captures,
    required int tokensHome,
  }) async {
    if (_db == null) {
      _demo = LudoStats(played: _demo.played + 1, wins: _demo.wins + (won ? 1 : 0), captures: _demo.captures + captures);
      return;
    }
    await _db.rpc('record_ludo_match', params: {
      'p_mode_id': modeId,
      'p_players': players,
      'p_difficulty': difficulty,
      'p_won': won,
      'p_captures': captures,
      'p_tokens_home': tokensHome,
    });
  }
}
