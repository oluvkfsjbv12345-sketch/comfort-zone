import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/theme.dart';
import '../models/wallet.dart';

/// Admin-only calls. The server re-checks is_admin() on every one, so hiding the
/// screen in the app is a convenience, not the security boundary.
class AdminRepository {
  final SupabaseClient? _db = AppConfig.useMock ? null : Supabase.instance.client;

  static List<AdminRecharge> _demo = [
    AdminRecharge(id: '1', handle: 'user_88437282', name: 'Sana', trxId: '8N7A6D5EE1', status: 'pending',
        senderNumber: '01712345678', amountBdt: 500, coins: 5000, createdAt: DateTime.now().subtract(const Duration(minutes: 12))),
    AdminRecharge(id: '2', handle: 'user_10293847', name: 'Rohan', trxId: '9K3B2C1FF4', status: 'pending',
        amountBdt: 100, coins: 1000, createdAt: DateTime.now().subtract(const Duration(hours: 2))),
  ];

  Future<bool> isAdmin() async {
    if (_db == null) return true;
    try {
      final r = await _db.from('profiles').select('is_admin').eq('id', _db.auth.currentUser!.id).single();
      return r['is_admin'] == true;
    } catch (_) { return false; }
  }

  Future<List<AdminRecharge>> list(String status) async {
    if (_db == null) return _demo.where((r) => r.status == status).toList();
    final rows = await _db.rpc('admin_list_recharges', params: {'p_status': status}) as List;
    return rows.map((r) => AdminRecharge.fromMap(r as Map<String, dynamic>)).toList();
  }

  Future<void> approve(String id) async {
    if (_db == null) { _demo = [for (final r in _demo) r.id == id ? r.withStatus('approved') : r]; return; }
    await _db.rpc('admin_approve_recharge', params: {'p_request_id': id});
  }

  Future<void> reject(String id, String? note) async {
    if (_db == null) { _demo = [for (final r in _demo) r.id == id ? r.withStatus('rejected', note) : r]; return; }
    await _db.rpc('admin_reject_recharge', params: {'p_request_id': id, 'p_note': note});
  }
}
