import 'package:flutter/material.dart';
import '../core/theme.dart';

String formatCoins(int n) => n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',');

/// Coin balance with a Recharge action. Reused on the Gaming and Me tabs.
class BalanceCard extends StatelessWidget {
  final int? coins;               // null while loading
  final VoidCallback onRecharge;
  const BalanceCard({super.key, required this.coins, required this.onRecharge});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(colors: [Color(0xFF231A3A), Color(0xFF4A2D9C)]),
        ),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Your balance', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 4),
            Text(coins == null ? '🪙 …' : '🪙 ${formatCoins(coins!)}',
                style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
          ])),
          GestureDetector(
            onTap: onRecharge,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(99)),
              child: const Text('Recharge', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
      );
}
