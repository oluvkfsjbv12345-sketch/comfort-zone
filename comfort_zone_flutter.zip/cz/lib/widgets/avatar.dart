import 'package:flutter/material.dart';
import '../core/theme.dart';

class Avatar extends StatelessWidget {
  final String name;
  final String? url;
  final double size;
  const Avatar({super.key, required this.name, this.url, this.size = 48});

  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: size / 2, backgroundColor: Brand.violet,
        backgroundImage: url != null ? NetworkImage(url!) : null,
        child: url == null
            ? Text(name.isEmpty ? '?' : name[0].toUpperCase(),
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: size * .4))
            : null,
      );
}
