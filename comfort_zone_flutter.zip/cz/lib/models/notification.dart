/// Maps to public.notifications
class AppNotification {
  final int id;
  final String type, title, body;
  final Map<String, dynamic> data;
  final DateTime createdAt;
  final bool read;
  const AppNotification({required this.id, required this.type, required this.title, this.body = '',
      this.data = const {}, required this.createdAt, this.read = false});

  factory AppNotification.fromMap(Map<String, dynamic> m) => AppNotification(
        id: m['id'] as int, type: m['type'], title: m['title'], body: (m['body'] ?? '') as String,
        data: Map<String, dynamic>.from(m['data'] ?? {}), createdAt: DateTime.parse(m['created_at']).toLocal(),
        read: m['read_at'] != null);
}
