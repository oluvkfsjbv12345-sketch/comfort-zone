/// Maps to public.profiles
class UserProfile {
  final String id, handle, name;
  final String? avatarUrl, countryCode;
  final int coins, followers, following, gifts, visitors;
  const UserProfile({required this.id, required this.handle, required this.name, this.avatarUrl,
      this.countryCode, this.coins = 0, this.followers = 0, this.following = 0, this.gifts = 0, this.visitors = 0});

  factory UserProfile.fromMap(Map<String, dynamic> m) => UserProfile(
        id: m['id'], handle: m['handle'], name: (m['display_name'] ?? 'Guest') as String,
        avatarUrl: m['avatar_url'], countryCode: (m['country_code'] as String?)?.trim(),
        coins: (m['coins'] as num).toInt(), followers: m['followers_count'], following: m['following_count'],
        gifts: m['gifts_received'], visitors: m['visitors_count']);
}

/// One row of get_conversations()
class Conversation {
  final String peerId, name, lastBody;
  final String? avatarUrl;
  final DateTime lastAt;
  final int unread;
  const Conversation({required this.peerId, required this.name, this.avatarUrl, this.lastBody = '',
      required this.lastAt, this.unread = 0});

  factory Conversation.fromMap(Map<String, dynamic> m) => Conversation(
        peerId: m['peer_id'], name: (m['display_name'] ?? 'Guest') as String, avatarUrl: m['avatar_url'],
        lastBody: (m['last_body'] ?? '') as String, lastAt: DateTime.parse(m['last_at']).toLocal(),
        unread: (m['unread_count'] as num).toInt());
}

/// Maps to public.messages
class ChatMessage {
  final String id, senderId, body;
  final DateTime at;
  const ChatMessage({required this.id, required this.senderId, required this.body, required this.at});
  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
      id: '${m['id']}', senderId: m['sender_id'], body: m['body'], at: DateTime.parse(m['created_at']).toLocal());
}
