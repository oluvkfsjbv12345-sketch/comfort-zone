import 'package:flutter/material.dart';

Color _hex(String h) => Color(int.parse('FF$h', radix: 16));

/// Maps to public.game_modes. Style comes from the database, so new modes need no app update.
class GameMode {
  final String id, game, title, subtitle, emoji;
  final int entryFee, players;
  final bool isLocal;
  final Color from, to;
  const GameMode({required this.id, required this.game, required this.title, required this.subtitle,
      required this.emoji, this.entryFee = 0, this.players = 2, this.isLocal = false,
      this.from = const Color(0xFF7B4DFF), this.to = const Color(0xFFFF5E8A)});

  factory GameMode.fromMap(Map<String, dynamic> m) => GameMode(
        id: m['id'], game: m['game'], title: m['title'], subtitle: (m['subtitle'] ?? '') as String,
        emoji: m['emoji'], entryFee: m['entry_fee'], players: m['players'], isLocal: m['is_local'],
        from: _hex(m['gradient_from']), to: _hex(m['gradient_to']));
}

/// Maps to public.families
class Family {
  final String id, code, name;
  final String? logoUrl;
  final int memberCount, capacity;
  const Family({required this.id, required this.code, required this.name, this.logoUrl,
      required this.memberCount, this.capacity = 300});
  bool get isFull => memberCount >= capacity;

  factory Family.fromMap(Map<String, dynamic> m) => Family(
        id: m['id'], code: m['code'], name: m['name'], logoUrl: m['logo_url'],
        memberCount: m['member_count'], capacity: m['capacity']);
}
