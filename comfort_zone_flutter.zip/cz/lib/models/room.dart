import 'package:flutter/material.dart';

/// Maps to public.rooms
class Room {
  final String id, title, agencyName, countryCode, category, agoraChannel;
  final String ownerId;
  final String? coverUrl;
  final int listenerCount;
  final bool isLive;

  const Room({
    required this.id, required this.title, this.agencyName = '', this.countryCode = '',
    this.category = 'party', this.agoraChannel = '', this.ownerId = '', this.coverUrl, this.listenerCount = 0, this.isLive = true,
  });

  factory Room.fromMap(Map<String, dynamic> m) => Room(
        id: m['id'] as String,
        title: m['title'] as String,
        agencyName: (m['agency_name'] ?? '') as String,
        countryCode: (m['country_code'] ?? '') as String,
        category: (m['category'] ?? 'party') as String,
        agoraChannel: (m['agora_channel'] ?? '') as String,
        ownerId: (m['owner_id'] ?? '') as String,
        coverUrl: m['cover_url'] as String?,
        listenerCount: (m['listener_count'] ?? 0) as int,
        isLive: (m['is_live'] ?? true) as bool,
      );

  /// Country code -> flag emoji ("IN" -> 🇮🇳)
  String get flag => countryCode.length != 2
      ? ''
      : String.fromCharCodes(countryCode.toUpperCase().codeUnits.map((c) => 0x1F1E6 + c - 65));
}

/// Maps to public.banners
class PromoBanner {
  final String title, subtitle;
  final Color from, to;
  const PromoBanner(this.title, this.subtitle, this.from, this.to);

  static Color _hex(String h) => Color(int.parse('FF$h', radix: 16));

  factory PromoBanner.fromMap(Map<String, dynamic> m) => PromoBanner(
      m['title'] as String, (m['subtitle'] ?? '') as String,
      _hex(m['gradient_from'] as String), _hex(m['gradient_to'] as String));
}
