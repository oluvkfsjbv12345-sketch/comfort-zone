/// Maps to public.my_ludo_stats() (games played against the computer).
class LudoStats {
  final int played, wins, captures;
  const LudoStats({this.played = 0, this.wins = 0, this.captures = 0});

  int get winRate => played == 0 ? 0 : (wins * 100 / played).round();

  factory LudoStats.fromMap(Map<String, dynamic> m) => LudoStats(
        played: (m['played'] as num).toInt(),
        wins: (m['wins'] as num).toInt(),
        captures: (m['captures'] as num).toInt(),
      );
}
