/// Payment settings from public.app_settings (falls back to these defaults).
class WalletConfig {
  final String bkashNumber;
  final int coinsPerBdt, minAmount;
  const WalletConfig(this.bkashNumber, this.coinsPerBdt, this.minAmount);
  static const fallback = WalletConfig('01316153526', 10, 20);

  factory WalletConfig.fromRows(List<Map<String, dynamic>> rows) {
    final m = {for (final r in rows) r['key'] as String: r['value'] as String};
    return WalletConfig(m['bkash_number'] ?? fallback.bkashNumber,
        int.tryParse(m['coins_per_bdt'] ?? '') ?? fallback.coinsPerBdt,
        int.tryParse(m['min_recharge_bdt'] ?? '') ?? fallback.minAmount);
  }
}

/// Maps to public.recharge_requests
class RechargeRequest {
  final String id, trxId, status;   // status: pending | approved | rejected
  final num amountBdt;
  final int coins;
  final DateTime createdAt;
  const RechargeRequest({required this.id, required this.trxId, required this.status,
      required this.amountBdt, required this.coins, required this.createdAt});

  factory RechargeRequest.fromMap(Map<String, dynamic> m) => RechargeRequest(
        id: m['id'], trxId: m['trx_id'], status: m['status'], amountBdt: m['amount_bdt'] as num,
        coins: m['coins'], createdAt: DateTime.parse(m['created_at']).toLocal());
}

/// A recharge request as seen by an admin (includes who asked).
class AdminRecharge {
  final String id, handle, name, trxId, status;
  final String? senderNumber, adminNote;
  final num amountBdt;
  final int coins;
  final DateTime createdAt;
  const AdminRecharge({required this.id, required this.handle, required this.name, required this.trxId,
      required this.status, this.senderNumber, this.adminNote, required this.amountBdt, required this.coins,
      required this.createdAt});

  factory AdminRecharge.fromMap(Map<String, dynamic> m) => AdminRecharge(
        id: m['id'], handle: m['handle'], name: (m['display_name'] ?? 'Guest') as String, trxId: m['trx_id'],
        status: m['status'], senderNumber: m['sender_number'], adminNote: m['admin_note'],
        amountBdt: m['amount_bdt'] as num, coins: m['coins'], createdAt: DateTime.parse(m['created_at']).toLocal());

  AdminRecharge withStatus(String s, [String? note]) => AdminRecharge(id: id, handle: handle, name: name, trxId: trxId,
      status: s, senderNumber: senderNumber, adminNote: note, amountBdt: amountBdt, coins: coins, createdAt: createdAt);
}
