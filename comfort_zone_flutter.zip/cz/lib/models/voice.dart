/// A user sitting on a mic seat. Built from room_seats + joined profiles.
class Seat {
  final int no, agoraUid;
  final String userId, name;
  final String? avatarUrl;
  const Seat({required this.no, required this.userId, required this.agoraUid, required this.name, this.avatarUrl});

  factory Seat.fromMap(Map<String, dynamic> m) {
    final p = (m['profiles'] ?? {}) as Map<String, dynamic>;
    return Seat(
      no: m['seat_no'] as int, userId: m['user_id'] as String,
      agoraUid: (p['agora_uid'] ?? 0) as int,
      name: (p['display_name'] ?? 'Guest') as String, avatarUrl: p['avatar_url'] as String?);
  }
}

class Gift {
  final String id, name, emoji;
  final int price;
  const Gift(this.id, this.name, this.emoji, this.price);
  factory Gift.fromMap(Map<String, dynamic> m) =>
      Gift(m['id'] as String, m['name'] as String, m['emoji'] as String, m['price'] as int);
}

/// Realtime gift broadcast shown as a banner to everyone in the room.
class GiftEvent {
  final String senderName, receiverName, emoji;
  final int qty;
  const GiftEvent(this.senderName, this.receiverName, this.emoji, this.qty);
  factory GiftEvent.fromMap(Map<String, dynamic> m) => GiftEvent(
      (m['sender_name'] ?? 'Someone') as String, (m['receiver_name'] ?? 'someone') as String,
      (m['emoji'] ?? '🎁') as String, (m['qty'] ?? 1) as int);
}

class MyProfile {
  final String id, name;
  final int agoraUid;
  final int coins;
  const MyProfile(this.id, this.agoraUid, this.name, this.coins);
}
