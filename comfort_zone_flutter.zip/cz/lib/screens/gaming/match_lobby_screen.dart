import 'package:flutter/material.dart';
import '../../games/ludo/ludo_bot_logic.dart';
import '../../games/ludo/ludo_game_screen.dart';
import '../../models/game.dart';

/// Online matchmaking isn't live yet, so Ludo offers a game against the computer meanwhile.
class MatchLobbyScreen extends StatefulWidget {
  final GameMode mode;
  const MatchLobbyScreen({super.key, required this.mode});
  @override
  State<MatchLobbyScreen> createState() => _MatchLobbyScreenState();
}

class _MatchLobbyScreenState extends State<MatchLobbyScreen> with SingleTickerProviderStateMixin {
  late final _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  LudoDifficulty _level = LudoDifficulty.medium;
  @override
  void dispose() { _pulse.dispose(); super.dispose(); }

  /// Opens the game on top of the lobby, then returns to the Gaming tab when it ends
  /// (so the tab can refresh stats). pushReplacement would refresh too early.
  Future<void> _playBot(GameMode m) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => LudoGameScreen(
        playerCount: m.players.clamp(2, 4), vsComputer: true, difficulty: _level, modeId: m.id)));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.mode, ludo = m.game == 'ludo';
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: LinearGradient(colors: [m.from, m.to], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: SafeArea(
          child: Column(children: [
            Align(alignment: Alignment.centerLeft,
                child: IconButton(icon: const Icon(Icons.close, color: Colors.white), tooltip: 'Cancel', onPressed: () => Navigator.pop(context))),
            const Spacer(),
            ScaleTransition(scale: Tween(begin: .9, end: 1.1).animate(_pulse), child: Text(m.emoji, style: const TextStyle(fontSize: 80))),
            const SizedBox(height: 20),
            Text(m.isLocal ? 'Get ready' : 'Online matches are coming', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(ludo ? 'Matchmaking with real players is not live yet. No coins were charged.\nPlay against the computer meanwhile.'
                  : 'The ${m.title} board is not built yet. No coins were charged.',
                  textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
            const SizedBox(height: 20),
            if (ludo) ...[
              Wrap(spacing: 8, children: [
                for (final l in LudoDifficulty.values)
                  ChoiceChip(
                    label: Text(l.label), selected: _level == l,
                    onSelected: (_) => setState(() => _level = l),
                    selectedColor: Colors.white, backgroundColor: Colors.white24,
                    labelStyle: TextStyle(fontWeight: FontWeight.w700, color: _level == l ? Colors.black87 : Colors.white),
                    showCheckmark: false, side: BorderSide.none),
              ]),
              const SizedBox(height: 16),
            ],
            if (ludo)
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black87, padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14)),
                onPressed: () => _playBot(m),
                child: const Text('Play vs computer', style: TextStyle(fontWeight: FontWeight.w800))),
            const Spacer(),
          ]),
        ),
      ),
    );
  }
}
