import 'package:flutter/material.dart';
import '../../models/game.dart';

class ModeCard extends StatelessWidget {
  final GameMode mode;
  final VoidCallback onTap;
  const ModeCard({super.key, required this.mode, required this.onTap});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true, label: '${mode.title}, ${mode.subtitle}',
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [mode.from, mode.to], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(22)),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(mode.title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(mode.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 10),
                Row(children: [
                  _pill(mode.entryFee == 0 ? 'Free' : '🪙 ${mode.entryFee}'),
                  const SizedBox(width: 6),
                  _pill(mode.isLocal ? 'Same phone' : '${mode.players} players'),
                ]),
              ])),
              Text(mode.emoji, style: const TextStyle(fontSize: 46)),
            ]),
          ),
        ),
      );

  Widget _pill(String t) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(99)),
      child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)));
}
