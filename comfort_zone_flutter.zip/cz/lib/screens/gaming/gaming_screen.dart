import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';
import '../../data/game_repository.dart';
import '../../data/ludo_repository.dart';
import '../../models/game.dart';
import '../../models/ludo_stats.dart';
import '../../games/ludo/ludo_game_screen.dart';
import '../../services/notification_service.dart';
import '../../widgets/balance_card.dart';
import 'match_lobby_screen.dart';
import 'mode_card.dart';

class GamingScreen extends StatefulWidget {
  const GamingScreen({super.key});
  @override
  State<GamingScreen> createState() => _GamingScreenState();
}

class _GamingScreenState extends State<GamingScreen> {
  final _repo = GameRepository();
  final _ludo = LudoRepository();
  static const _games = [('ludo', 'Ludo', '🎲'), ('uno', 'UNO', '🃏'), ('pool', '8-Ball Pool', '🎱')];

  int _game = 0;
  int? _coins;
  LudoStats _stats = const LudoStats();
  List<GameMode> _modes = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); NotificationService.instance.walletVersion.addListener(_load); }

  @override
  void dispose() { NotificationService.instance.walletVersion.removeListener(_load); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = _modes.isEmpty; _error = null; });
    try {
      final r = await Future.wait([_repo.coins(), _repo.modes()]);
      // Stats are a nice-to-have: if 008_ludo.sql isn't applied yet, the games still load.
      final stats = await _ludo.stats().catchError((_) => _stats);
      if (mounted) setState(() { _coins = r[0] as int; _modes = r[1] as List<GameMode>; _stats = stats; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = friendly(e); _loading = false; });
    }
  }

  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<int?> _pickPlayers() => showModalBottomSheet<int>(
        context: context, backgroundColor: Colors.transparent,
        builder: (_) => Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('How many players?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('Everyone plays on this phone. Pass it on after each turn.', style: TextStyle(color: Brand.mute)),
            const SizedBox(height: 14),
            Row(children: [
              for (final n in [2, 3, 4])
                Expanded(child: Padding(padding: EdgeInsets.only(right: n < 4 ? 8 : 0),
                    child: FilledButton(onPressed: () => Navigator.pop(context, n), child: Text('$n players')))),
            ]),
          ]),
        ));

  Future<void> _play(GameMode m) async {
    if (m.game == 'ludo' && m.isLocal) {
      final n = await _pickPlayers();
      if (n != null && mounted) {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => LudoGameScreen(playerCount: n, vsComputer: false, modeId: m.id)));
      }
      return;
    }
    if (m.entryFee > 0) {
      final ok = await showModalBottomSheet<bool>(
        context: context, backgroundColor: Colors.transparent,
        builder: (_) => _ConfirmSheet(mode: m, coins: _coins ?? 0));
      if (ok != true || !mounted) return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => MatchLobbyScreen(mode: m)));
    if (mounted) _load();   // balance may have changed
  }

  @override
  Widget build(BuildContext context) {
    final modes = _modes.where((m) => m.game == _games[_game].$1).toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 20), children: [
        const Padding(padding: EdgeInsets.fromLTRB(2, 0, 2, 12),
            child: Text('Gaming', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
        Row(children: [
          for (var i = 0; i < _games.length; i++) ...[
            if (i > 0) const SizedBox(width: 8),
            Expanded(child: _selector(i)),
          ],
        ]),
        const SizedBox(height: 12),
        BalanceCard(coins: _coins, onRecharge: () => _toast('Recharge opens with the payments screen.')),
        const SizedBox(height: 14),
        if (_games[_game].$1 == 'ludo' && _stats.played > 0) ...[_statsCard(), const SizedBox(height: 14)],
        if (_loading) const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()))
        else if (_error != null) _note('Could not load games. Pull down to try again.')
        else if (modes.isEmpty) _note('No modes for this game yet.')
        else for (final m in modes) Padding(padding: const EdgeInsets.only(bottom: 12),
            child: ModeCard(mode: m, onTap: () => _play(m))),
      ]),
    );
  }

  Widget _statsCard() => Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          for (final s in [('Played', '${_stats.played}'), ('Wins', '${_stats.wins}'), ('Win rate', '${_stats.winRate}%'), ('Captures', '${_stats.captures}')])
            Column(children: [
              Text(s.$2, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              Text(s.$1, style: const TextStyle(fontSize: 11, color: Brand.mute)),
            ]),
        ]),
      );

  Widget _note(String t) => Padding(padding: const EdgeInsets.all(32),
      child: Center(child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute))));

  Widget _selector(int i) {
    final on = i == _game;
    return Semantics(
      button: true, selected: on, label: _games[i].$2,
      child: GestureDetector(
        onTap: () => setState(() => _game = i),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: on ? Brand.gradient : null, color: on ? null : Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Brand.violet.withOpacity(.08), blurRadius: 12, offset: const Offset(0, 3))]),
          child: Column(children: [
            Text(_games[i].$3, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 2),
            Text(_games[i].$2, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: on ? Colors.white : Brand.ink)),
          ]),
        ),
      ),
    );
  }
}

/// Entry-fee confirmation. Coins are only charged once the match engine starts a game.
class _ConfirmSheet extends StatelessWidget {
  final GameMode mode;
  final int coins;
  const _ConfirmSheet({required this.mode, required this.coins});

  @override
  Widget build(BuildContext context) {
    final short = mode.entryFee - coins;
    return Container(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(context).viewPadding.bottom),
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${mode.emoji}  ${mode.title}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(mode.subtitle, style: const TextStyle(color: Brand.mute)),
        const SizedBox(height: 16),
        _row('Entry fee', '🪙 ${formatCoins(mode.entryFee)}'),
        _row('Your balance', '🪙 ${formatCoins(coins)}'),
        if (short > 0)
          Padding(padding: const EdgeInsets.only(top: 8),
              child: Text('You need ${formatCoins(short)} more coins to play.', style: const TextStyle(color: Color(0xFFD62F4B)))),
        const SizedBox(height: 16),
        GestureDetector(
          onTap: short > 0 ? null : () => Navigator.pop(context, true),
          child: Opacity(
            opacity: short > 0 ? .4 : 1,
            child: Container(height: 50, alignment: Alignment.center,
                decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(16)),
                child: const Text('Find a match', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
          ),
        ),
      ]),
    );
  }

  Widget _row(String a, String b) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(a, style: const TextStyle(color: Brand.mute)), Text(b, style: const TextStyle(fontWeight: FontWeight.w700))]));
}
