import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/theme.dart';
import '../../data/notification_repository.dart';
import '../../models/notification.dart';
import '../../services/notification_service.dart';
import '../admin/admin_recharge_screen.dart';
import '../me/wallet_screen.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});
  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final _repo = NotificationRepository();
  List<AppNotification> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    NotificationService.instance.unread.addListener(_load);   // new one arrived while open
  }

  @override
  void dispose() { NotificationService.instance.unread.removeListener(_load); super.dispose(); }

  Future<void> _load() async {
    try {
      final i = await _repo.list();
      if (mounted) setState(() { _items = i; _loading = false; _error = null; });
    } catch (e) { if (mounted) setState(() { _error = friendly(e); _loading = false; }); }
  }

  Future<void> _markAll() async {
    await _repo.markAllRead();
    await NotificationService.instance.refresh();
    await _load();
  }

  Future<void> _open(AppNotification n) async {
    if (!n.read) { await _repo.markRead(n.id); NotificationService.instance.refresh(); }
    if (!mounted) return;
    final page = n.type == 'recharge_request' ? const AdminRechargeScreen()
        : n.type.startsWith('recharge_') ? const WalletScreen() : null;
    if (page != null) await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [TextButton(onPressed: _items.any((n) => !n.read) ? _markAll : null, child: const Text('Mark all read'))]),
        body: RefreshIndicator(
          onRefresh: _load,
          child: _loading
              ? ListView(children: const [SizedBox(height: 120), Center(child: CircularProgressIndicator())])
              : _error != null
                  ? _msg('Could not load notifications. Pull down to try again.')
                  : _items.isEmpty ? _msg('You are all caught up.')
                  : ListView.separated(
                      padding: const EdgeInsets.all(14), itemCount: _items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) => _tile(_items[i])),
        ),
      );

  Widget _msg(String t) => ListView(children: [Padding(padding: const EdgeInsets.all(40),
      child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute)))]);

  Widget _tile(AppNotification n) {
    final (icon, color) = switch (n.type) {
      'recharge_approved' => (Icons.monetization_on, const Color(0xFF1B8F55)),
      'recharge_rejected' => (Icons.error_outline, const Color(0xFFD62F4B)),
      _ => (Icons.payments_outlined, Brand.violet),
    };
    return InkWell(
      borderRadius: BorderRadius.circular(16), onTap: () => _open(n),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: n.read ? Colors.white : const Color(0xFFF1EBFF), borderRadius: BorderRadius.circular(16)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(n.title, style: TextStyle(fontWeight: n.read ? FontWeight.w600 : FontWeight.w800)),
            if (n.body.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(n.body, style: const TextStyle(fontSize: 13, color: Brand.mute))),
          ])),
          const SizedBox(width: 8),
          Text(timeAgo(n.createdAt), style: const TextStyle(fontSize: 11, color: Brand.mute)),
        ]),
      ),
    );
  }
}
