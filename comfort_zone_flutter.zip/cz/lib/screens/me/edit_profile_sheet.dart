import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';
import '../../models/social.dart';

class EditProfileSheet extends StatefulWidget {
  final UserProfile profile;
  final Future<void> Function(String name, String? country) onSave;
  const EditProfileSheet({super.key, required this.profile, required this.onSave});
  @override
  State<EditProfileSheet> createState() => _EditProfileSheetState();
}

class _EditProfileSheetState extends State<EditProfileSheet> {
  late final _name = TextEditingController(text: widget.profile.name);
  late final _country = TextEditingController(text: widget.profile.countryCode ?? '');
  bool _busy = false;
  String? _err;

  @override
  void dispose() { _name.dispose(); _country.dispose(); super.dispose(); }

  Future<void> _save() async {
    final n = _name.text.trim(), c = _country.text.trim().toUpperCase();
    if (n.length < 2) { setState(() => _err = 'Display name needs at least 2 characters.'); return; }
    if (c.isNotEmpty && c.length != 2) { setState(() => _err = 'Country is a 2-letter code, like BD or IN.'); return; }
    setState(() { _busy = true; _err = null; });
    try { await widget.onSave(n, c.isEmpty ? null : c); if (mounted) Navigator.pop(context); }
    catch (e) { if (mounted) setState(() { _err = friendly(e); _busy = false; }); }
  }

  InputDecoration _dec(String l) => InputDecoration(labelText: l, filled: true, fillColor: Brand.bg,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none));

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Edit profile', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            TextField(controller: _name, maxLength: 30, decoration: _dec('Display name')),
            const SizedBox(height: 4),
            TextField(controller: _country, maxLength: 2, textCapitalization: TextCapitalization.characters, decoration: _dec('Country code (optional)')),
            if (_err != null) Text(_err!, style: const TextStyle(color: Color(0xFFD62F4B), fontSize: 13)),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: _busy ? null : _save,
              child: Container(height: 50, alignment: Alignment.center,
                  decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(16)),
                  child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Text('Save changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
            ),
          ]),
        ),
      );
}
