import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/theme.dart';
import '../../data/profile_repository.dart';
import '../../data/wallet_repository.dart';
import '../../models/social.dart';
import '../../models/wallet.dart';
import '../../widgets/balance_card.dart';

const _bkashPink = Color(0xFFE2136E);

/// Manual Bkash recharge: user sends money, then submits the TrxID + amount for approval.
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final _wallet = WalletRepository();
  final _amount = TextEditingController(), _trx = TextEditingController(), _sender = TextEditingController();
  WalletConfig _cfg = WalletConfig.fallback;
  List<RechargeRequest> _requests = [];
  int? _coins;
  bool _busy = false;
  String? _err;

  @override
  void initState() { super.initState(); _load(); _amount.addListener(() => setState(() {})); }

  @override
  void dispose() { _amount.dispose(); _trx.dispose(); _sender.dispose(); super.dispose(); }

  Future<void> _load() async {
    try {
      final r = await Future.wait([_wallet.config(), _wallet.requests(), ProfileRepository().me()]);
      if (mounted) setState(() { _cfg = r[0] as WalletConfig; _requests = r[1] as List<RechargeRequest>; _coins = (r[2] as UserProfile).coins; });
    } catch (e) { if (mounted) setState(() => _err = friendly(e)); }
  }

  num? get _amt => num.tryParse(_amount.text.trim());
  int get _estCoins => ((_amt ?? 0) * _cfg.coinsPerBdt).floor();

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: _cfg.bkashNumber));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bkash number copied')));
  }

  Future<void> _submit() async {
    final a = _amt, trx = _trx.text.trim().toUpperCase();
    if (a == null || a < _cfg.minAmount) { setState(() => _err = 'Enter an amount of at least ${_cfg.minAmount} BDT.'); return; }
    if (!RegExp(r'^[A-Z0-9]{8,12}$').hasMatch(trx)) { setState(() => _err = 'Enter the Bkash TrxID from your payment SMS (8 to 12 letters and numbers).'); return; }
    setState(() { _busy = true; _err = null; });
    try {
      await _wallet.submit(amount: a, trxId: trx, sender: _sender.text.trim());
      _amount.clear(); _trx.clear(); _sender.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Request sent. Coins are added after we verify your payment.')));
      await _load();
    } catch (e) { _err = friendly(e); }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Wallet', style: TextStyle(fontWeight: FontWeight.w800))),
        body: ListView(padding: const EdgeInsets.fromLTRB(14, 4, 14, 24), children: [
          BalanceCard(coins: _coins, onRecharge: () {}),
          const SizedBox(height: 14),
          _bkashCard(),
          const SizedBox(height: 14),
          _form(),
          const SizedBox(height: 18),
          const Text('Recharge requests', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          if (_requests.isEmpty)
            const Padding(padding: EdgeInsets.all(16), child: Text('No requests yet.', style: TextStyle(color: Brand.mute)))
          else for (final r in _requests) _requestTile(r),
        ]),
      );

  Widget _bkashCard() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: _bkashPink, borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Pay with Bkash', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Bkash Personal Number', style: TextStyle(fontSize: 11, color: Brand.mute)),
                Text(_cfg.bkashNumber, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: _bkashPink, letterSpacing: 1)),
              ])),
              IconButton(icon: const Icon(Icons.copy, color: _bkashPink), tooltip: 'Copy number', onPressed: _copy),
            ]),
          ),
          const SizedBox(height: 12),
          for (final s in const [
            'Open the bKash app and choose Send Money.',
            'Send your amount to the number above.',
            'Copy the TrxID from the confirmation, then enter it below.',
          ]) Padding(padding: const EdgeInsets.only(bottom: 3),
              child: Text('•  $s', style: const TextStyle(color: Colors.white, fontSize: 13))),
        ]),
      );

  Widget _form() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Request coins', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, children: [
            for (final v in const [50, 100, 200, 500, 1000])
              ActionChip(label: Text('৳$v'), onPressed: () => _amount.text = '$v'),
          ]),
          const SizedBox(height: 10),
          _field(_amount, 'Amount sent (BDT)', keyboard: TextInputType.number, formatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))]),
          if (_estCoins > 0)
            Padding(padding: const EdgeInsets.only(top: 6),
                child: Text('You will receive ${formatCoins(_estCoins)} coins (${_cfg.coinsPerBdt} coins per ৳1)',
                    style: const TextStyle(color: Brand.violet, fontWeight: FontWeight.w700, fontSize: 13))),
          const SizedBox(height: 12),
          _field(_trx, 'Bkash TrxID', caps: true, formatters: [FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9]')), LengthLimitingTextInputFormatter(12)]),
          const SizedBox(height: 12),
          _field(_sender, 'Your Bkash number (optional)', keyboard: TextInputType.phone),
          if (_err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err!, style: const TextStyle(color: Color(0xFFD62F4B), fontSize: 13))),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _busy ? null : _submit,
            child: Container(height: 50, alignment: Alignment.center,
                decoration: BoxDecoration(color: _bkashPink, borderRadius: BorderRadius.circular(16)),
                child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : const Text('Submit request', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
          ),
          const SizedBox(height: 8),
          const Text('Coins are added after we check the payment. Wrong or reused TrxIDs are rejected.',
              style: TextStyle(fontSize: 11, color: Brand.mute)),
        ]),
      );

  Widget _field(TextEditingController c, String label, {TextInputType? keyboard, bool caps = false, List<TextInputFormatter>? formatters}) =>
      TextField(controller: c, keyboardType: keyboard, inputFormatters: formatters, autocorrect: false,
          textCapitalization: caps ? TextCapitalization.characters : TextCapitalization.none,
          decoration: InputDecoration(labelText: label, filled: true, fillColor: Brand.bg,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)));

  Widget _requestTile(RechargeRequest r) {
    final (color, label) = switch (r.status) {
      'approved' => (const Color(0xFF1B8F55), 'Approved'),
      'rejected' => (const Color(0xFFD62F4B), 'Rejected'),
      _ => (const Color(0xFFB7791F), 'Pending'),
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('৳${r.amountBdt} · ${formatCoins(r.coins)} coins', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('${r.trxId} · ${timeAgo(r.createdAt)}', style: const TextStyle(fontSize: 12, color: Brand.mute)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(99)),
          child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12))),
      ]),
    );
  }
}
