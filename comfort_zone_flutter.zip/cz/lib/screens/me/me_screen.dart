import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';
import '../../data/admin_repository.dart';
import '../../data/profile_repository.dart';
import '../../models/social.dart';
import '../../services/notification_service.dart';
import '../../widgets/avatar.dart';
import '../../widgets/balance_card.dart';
import '../admin/admin_recharge_screen.dart';
import 'edit_profile_sheet.dart';
import 'settings_screen.dart';
import 'wallet_screen.dart';

class MeScreen extends StatefulWidget {
  const MeScreen({super.key});
  @override
  State<MeScreen> createState() => _MeScreenState();
}

class _MeScreenState extends State<MeScreen> {
  final _repo = ProfileRepository();
  UserProfile? _p;
  bool _admin = false;   // shows the recharge review entry; the server re-checks every call
  String? _error;

  @override
  void initState() { super.initState(); _load(); NotificationService.instance.walletVersion.addListener(_load); }

  @override
  void dispose() { NotificationService.instance.walletVersion.removeListener(_load); super.dispose(); }

  Future<void> _load() async {
    try {
      final p = await _repo.me();
      final admin = await AdminRepository().isAdmin();
      if (mounted) setState(() { _p = p; _admin = admin; _error = null; });
    } catch (e) {
      if (mounted) setState(() => _error = friendly(e));
    }
  }

  void _soon(String what) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$what is coming soon')));

  Future<void> _go(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();   // coins or name may have changed
  }

  Future<void> _edit() async {
    await showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => EditProfileSheet(profile: _p!, onSave: (n, c) => _repo.update(name: n, country: c)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    if (p == null) {
      return Center(child: _error == null
          ? const CircularProgressIndicator()
          : Padding(padding: const EdgeInsets.all(32), child: Text('Could not load your profile. $_error', textAlign: TextAlign.center)));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 20), children: [
        Align(alignment: Alignment.centerRight,
            child: IconButton(icon: const Icon(Icons.settings_outlined), tooltip: 'Settings', onPressed: () => _go(const SettingsScreen()))),
        _profileHeader(p),
        const SizedBox(height: 14),
        _stats(p),
        const SizedBox(height: 14),
        BalanceCard(coins: p.coins, onRecharge: () => _go(const WalletScreen())),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _member('👑  VIP / SVIP', 'Golden perks', const [Color(0xFFB8860B), Color(0xFFF5B942)], () => _soon('VIP plans'))),
          const SizedBox(width: 10),
          Expanded(child: _member('🛡  Noble', 'Activate now', const [Color(0xFF3B5B8F), Color(0xFF8FA8C9)], () => _soon('Noble'))),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          for (final f in const [(Icons.task_alt, 'Task'), (Icons.favorite, 'Couple'), (Icons.home_filled, 'Family')]) ...[
            Expanded(child: GestureDetector(
              onTap: () => _soon(f.$2),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: Column(children: [Icon(f.$1, color: Brand.violet), const SizedBox(height: 4),
                  Text(f.$2, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))]),
              ))),
            if (f.$2 != 'Family') const SizedBox(width: 8),
          ],
        ]),
        const SizedBox(height: 12),
        if (_admin) ...[_adminTile(), const SizedBox(height: 12)],
        _menu(),
      ]),
    );
  }

  Widget _profileHeader(UserProfile p) => Row(children: [
        Container(
          width: 84, height: 84, padding: const EdgeInsets.all(4),
          decoration: const BoxDecoration(shape: BoxShape.circle,
              gradient: SweepGradient(colors: [Brand.gold, Brand.coral, Brand.violet, Brand.gold])),
          child: Container(
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Brand.bg), padding: const EdgeInsets.all(2),
              child: Avatar(name: p.name, url: p.avatarUrl, size: 72)),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Text(p.handle, style: const TextStyle(color: Brand.mute, fontSize: 13)),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: _edit,
              style: OutlinedButton.styleFrom(foregroundColor: Brand.violet, side: const BorderSide(color: Brand.violet, width: 1.5),
                  shape: const StadiumBorder(), visualDensity: VisualDensity.compact),
              child: const Text('View & Edit Profile')),
        ])),
      ]);

  Widget _stats(UserProfile p) => Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        for (final s in [('Followers', p.followers), ('Following', p.following), ('Gifts', p.gifts), ('Visitors', p.visitors)])
          Column(children: [
            Text(formatCoins(s.$2), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            Text(s.$1, style: const TextStyle(fontSize: 11, color: Brand.mute)),
          ]),
      ]);

  Widget _member(String t, String sub, List<Color> c, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(gradient: LinearGradient(colors: c), borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 3),
            Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ]),
        ),
      );

  Widget _adminTile() => GestureDetector(
        onTap: () => _go(const AdminRechargeScreen()),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: const Color(0xFF231A3A), borderRadius: BorderRadius.circular(18)),
          child: const Row(children: [
            Icon(Icons.admin_panel_settings, color: Brand.gold),
            SizedBox(width: 12),
            Expanded(child: Text('Review recharge requests', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
            Icon(Icons.chevron_right, color: Colors.white54),
          ]),
        ),
      );

  Widget _menu() {
    const items = [
      (Icons.verified_user_outlined, 'Verification Center'), (Icons.storefront_outlined, 'Store'),
      (Icons.military_tech_outlined, 'Badge & Title Center'), (Icons.trending_up, 'Tools & Level'),
      (Icons.confirmation_number_outlined, 'Coupon'), (Icons.help_outline, 'Help'),
      (Icons.event_outlined, 'Activity'), (Icons.settings_outlined, 'Settings'),
    ];
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(children: [
        for (var i = 0; i < items.length; i++) ...[
          ListTile(
            leading: Icon(items[i].$1, color: Brand.violet), title: Text(items[i].$2, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            trailing: const Icon(Icons.chevron_right, color: Brand.mute),
            onTap: () => items[i].$2 == 'Settings' ? _go(const SettingsScreen()) : _soon(items[i].$2)),
          if (i < items.length - 1) const Divider(height: 1, indent: 56),
        ],
      ]),
    );
  }
}
