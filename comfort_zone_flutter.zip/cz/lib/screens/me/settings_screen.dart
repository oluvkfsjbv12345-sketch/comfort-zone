import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../data/profile_repository.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _signOut(BuildContext context) async {
    if (AppConfig.useMock) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo mode has no account to sign out of.')));
      return;
    }
    final nav = Navigator.of(context);
    await ProfileRepository().signOut();
    nav.popUntil((r) => r.isFirst);   // AuthGate swaps the root to the login screen
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
        body: ListView(padding: const EdgeInsets.all(14), children: [
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
            child: Column(children: [
              ListTile(leading: const Icon(Icons.info_outline, color: Brand.violet), title: const Text('About Comfort Zone'), subtitle: const Text('Version 0.1.0')),
              const Divider(height: 1, indent: 56),
              ListTile(
                leading: const Icon(Icons.logout, color: Color(0xFFD62F4B)),
                title: const Text('Sign out', style: TextStyle(color: Color(0xFFD62F4B), fontWeight: FontWeight.w700)),
                onTap: () => _signOut(context)),
            ]),
          ),
        ]),
      );
}
