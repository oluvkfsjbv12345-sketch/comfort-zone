import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';
import '../../data/message_repository.dart';
import '../../models/social.dart';
import '../../widgets/avatar.dart';

class ChatScreen extends StatefulWidget {
  final Conversation peer;
  const ChatScreen({super.key, required this.peer});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _repo = MessageRepository();
  final _input = TextEditingController();
  List<ChatMessage> _msgs = [];           // oldest first
  bool _loading = true, _sending = false;
  RealtimeChannel? _channel;

  String get _peerId => widget.peer.peerId;

  @override
  void initState() {
    super.initState();
    _load();
    _channel = _repo.watchIncoming((m) {
      if (m.senderId != _peerId || !mounted) return;   // only this conversation
      setState(() => _msgs = [..._msgs, m]);
      _repo.markRead(_peerId);
    }, name: 'chat');
  }

  Future<void> _load() async {
    try {
      final t = await _repo.thread(_peerId);
      await _repo.markRead(_peerId);
      if (mounted) setState(() { _msgs = t; _loading = false; });
    } catch (e) {
      if (mounted) { setState(() => _loading = false); _toast(friendly(e)); }
    }
  }

  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final m = await _repo.send(_peerId, text);
      _input.clear();
      if (mounted) setState(() => _msgs = [..._msgs, m]);
    } catch (e) { _toast(friendly(e)); }
    if (mounted) setState(() => _sending = false);
  }

  @override
  void dispose() { _repo.unwatch(_channel); _input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white, elevation: 1, titleSpacing: 0,
          title: Row(children: [Avatar(name: widget.peer.name, url: widget.peer.avatarUrl, size: 34), const SizedBox(width: 10),
            Expanded(child: Text(widget.peer.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))]),
        ),
        body: Column(children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _msgs.isEmpty
                    ? const Center(child: Text('Say hi 👋', style: TextStyle(color: Brand.mute)))
                    : ListView.builder(
                        reverse: true, padding: const EdgeInsets.all(14), itemCount: _msgs.length,
                        itemBuilder: (_, i) => _bubble(_msgs[_msgs.length - 1 - i])),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: Row(children: [
                Expanded(child: TextField(
                  controller: _input, maxLength: 1000, minLines: 1, maxLines: 4, textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(hintText: 'Message', counterText: '', filled: true, fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                  onSubmitted: (_) => _send())),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _send,
                  child: Container(width: 44, height: 44,
                      decoration: const BoxDecoration(gradient: Brand.gradient, shape: BoxShape.circle),
                      child: _sending
                          ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.send, color: Colors.white, size: 20)),
                ),
              ]),
            ),
          ),
        ]),
      );

  Widget _bubble(ChatMessage m) {
    final mine = m.senderId == _repo.myId;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
        decoration: BoxDecoration(
          gradient: mine ? Brand.gradient : null, color: mine ? null : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18))),
        child: Text(m.body, style: TextStyle(color: mine ? Colors.white : Brand.ink, fontSize: 14)),
      ),
    );
  }
}
