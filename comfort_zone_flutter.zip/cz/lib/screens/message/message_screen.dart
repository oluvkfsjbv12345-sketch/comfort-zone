import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/theme.dart';
import '../../data/message_repository.dart';
import '../../models/social.dart';
import '../../services/notification_service.dart';
import '../../services/unread_service.dart';
import '../../widgets/avatar.dart';
import '../me/settings_screen.dart';
import '../notifications/notification_screen.dart';
import 'chat_screen.dart';

class MessageScreen extends StatefulWidget {
  const MessageScreen({super.key});
  @override
  State<MessageScreen> createState() => _MessageScreenState();
}

class _MessageScreenState extends State<MessageScreen> {
  final _repo = MessageRepository();
  List<Conversation> _convs = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    UnreadService.count.addListener(_onUnreadChanged);   // new message arrived -> reload list
  }

  @override
  void dispose() { UnreadService.count.removeListener(_onUnreadChanged); super.dispose(); }
  void _onUnreadChanged() { if (mounted) _load(); }

  Future<void> _load() async {
    try {
      final c = await _repo.conversations();
      if (mounted) setState(() { _convs = c; _loading = false; _error = null; });
    } catch (e) {
      if (mounted) setState(() { _error = friendly(e); _loading = false; });
    }
  }

  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _open(Conversation c) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(peer: c)));
    await UnreadService.refresh();
    if (mounted) _load();
  }

  Future<void> _clean() async {
    try { await _repo.markAllRead(); await UnreadService.refresh(); await _load(); _toast('All messages marked as read'); }
    catch (e) { _toast(friendly(e)); }
  }

  Future<void> _addFriend() async {
    final ctrl = TextEditingController();
    final id = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Start a chat'),
        content: TextField(controller: ctrl, autofocus: true, autocorrect: false,
            decoration: const InputDecoration(hintText: 'Enter a user ID, e.g. user_88437282')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('Find')),
        ]));
    ctrl.dispose();
    if (id == null || id.trim().isEmpty) return;
    try {
      final peer = await _repo.findByHandle(id);
      if (peer == null) { _toast('No user found with that ID.'); return; }
      if (mounted) _open(peer);
    } catch (e) { _toast(friendly(e)); }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 20), children: [
          _header(),
          const SizedBox(height: 8),
          _circles(),
          const SizedBox(height: 8),
          _official('Activity Center', 'Weekend events are live', const Color(0xFFF5B942), Icons.emoji_events),
          _official('Activity Assistant', 'Your tasks reset at midnight', const Color(0xFF4A7BFF), Icons.support_agent),
          const Divider(height: 24),
          if (_loading) const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
          else if (_error != null) _note('Could not load messages. Pull down to try again.')
          else if (_convs.isEmpty) _note('No conversations yet. Tap the add friend icon and enter a user ID to say hi.')
          else for (final c in _convs) _tile(c),
        ]),
      );

  Widget _header() => Row(children: [
        const Expanded(child: Text('Messages', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
        _icon(Icons.cleaning_services_outlined, 'Mark all as read', _clean),
        const SizedBox(width: 8),
        _icon(Icons.person_add_alt, 'Add friend', _addFriend),
        const SizedBox(width: 8),
        _icon(Icons.settings_outlined, 'Settings',
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      ]);

  Widget _icon(IconData i, String tip, VoidCallback onTap) => Material(
      color: Colors.white, elevation: 1, borderRadius: BorderRadius.circular(12),
      child: InkWell(borderRadius: BorderRadius.circular(12), onTap: onTap,
          child: Tooltip(message: tip, child: SizedBox(width: 38, height: 38, child: Icon(i, size: 20)))));

  Widget _circles() {
    const items = [
      (Icons.people, 'Followers', Color(0xFF7B4DFF)), (Icons.photo_camera, 'Moment', Color(0xFFFF8A3D)),
      (Icons.notifications, 'Notification', Color(0xFFFF5E8A)), (Icons.celebration, 'Comfort Party', Color(0xFF1BA8A0)),
    ];
    return Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
      for (final it in items)
        GestureDetector(
          onTap: () => it.$2 == 'Notification'
              ? Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationScreen()))
              : _toast('${it.$2} is coming soon'),
          child: Column(children: [
            _circle(it),
            const SizedBox(height: 5),
            Text(it.$2, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        ),
    ]);
  }

  Widget _circle((IconData, String, Color) it) {
    final avatar = CircleAvatar(radius: 26, backgroundColor: it.$3, child: Icon(it.$1, color: Colors.white));
    if (it.$2 != 'Notification') return avatar;
    return ValueListenableBuilder<int>(
      valueListenable: NotificationService.instance.unread,
      builder: (_, n, __) => Badge(isLabelVisible: n > 0, label: Text('$n'), child: avatar));
  }

  Widget _official(String title, String sub, Color c, IconData icon) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: Colors.white)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(width: 4),
              const Icon(Icons.verified, size: 15, color: Color(0xFF2D8CFF)),
            ]),
            Text(sub, style: const TextStyle(fontSize: 12, color: Brand.mute)),
          ])),
        ]),
      );

  Widget _tile(Conversation c) => InkWell(
        onTap: () => _open(c),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            Avatar(name: c.name, url: c.avatarUrl),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(height: 2),
              Text(c.lastBody, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, color: c.unread > 0 ? Brand.ink : Brand.mute)),
            ])),
            const SizedBox(width: 8),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(timeAgo(c.lastAt), style: const TextStyle(fontSize: 11, color: Brand.mute)),
              const SizedBox(height: 5),
              if (c.unread > 0)
                Container(
                  constraints: const BoxConstraints(minWidth: 19), height: 19, padding: const EdgeInsets.symmetric(horizontal: 5),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: Brand.coral, borderRadius: BorderRadius.circular(99)),
                  child: Text('${c.unread}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800))),
            ]),
          ]),
        ),
      );

  Widget _note(String t) => Padding(padding: const EdgeInsets.all(28),
      child: Center(child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute))));
}
