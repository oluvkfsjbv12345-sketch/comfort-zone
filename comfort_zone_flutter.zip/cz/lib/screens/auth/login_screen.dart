import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/theme.dart';

/// Email + password sign in / sign up, Google OAuth, and password reset.
/// On success AuthGate swaps to MainShell, so there is no manual navigation here.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _name = TextEditingController(), _email = TextEditingController(), _pass = TextEditingController();
  bool _signUp = false, _busy = false, _hide = true, _isError = true;
  String? _msg;

  SupabaseClient get _db => Supabase.instance.client;

  void _say(String m, {bool error = true}) => setState(() { _msg = m; _isError = error; _busy = false; });

  Future<void> _submit() async {
    final email = _email.text.trim(), pass = _pass.text;
    if (!email.contains('@')) return _say('Enter a valid email address.');
    if (pass.length < 6) return _say('Password needs at least 6 characters.');
    if (_signUp && _name.text.trim().isEmpty) return _say('Enter a display name.');
    setState(() { _busy = true; _msg = null; });
    try {
      if (_signUp) {
        final res = await _db.auth.signUp(email: email, password: pass, data: {'name': _name.text.trim()});
        if (res.session == null) _say('Check your inbox to confirm your email, then sign in.', error: false);
      } else {
        await _db.auth.signInWithPassword(email: email, password: pass);
      }
    } on AuthException catch (e) {
      _say(e.message);
    } catch (_) {
      _say('Could not connect. Check your internet and try again.');
    }
  }

  Future<void> _google() async {
    try {
      // Needs the deep link below registered in AndroidManifest / Info.plist and in Supabase Auth > URL Configuration.
      await _db.auth.signInWithOAuth(OAuthProvider.google, redirectTo: 'io.supabase.comfortzone://login-callback/');
    } on AuthException catch (e) { _say(e.message); }
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (!email.contains('@')) return _say('Enter your email above, then tap Forgot password.');
    try {
      await _db.auth.resetPasswordForEmail(email);
      _say('Password reset link sent to $email.', error: false);
    } on AuthException catch (e) { _say(e.message); }
  }

  @override
  void dispose() { _name.dispose(); _email.dispose(); _pass.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: Brand.gradient),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Comfort Zone', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  const Text('Voice rooms, games and friends', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(_signUp ? 'Create your account' : 'Welcome back',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 16),
                      if (_signUp) ...[_field(_name, 'Display name', Icons.person_outline), const SizedBox(height: 12)],
                      _field(_email, 'Email', Icons.mail_outline, type: TextInputType.emailAddress),
                      const SizedBox(height: 12),
                      _field(_pass, 'Password', Icons.lock_outline, obscure: _hide,
                          suffix: IconButton(icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
                              tooltip: _hide ? 'Show password' : 'Hide password',
                              onPressed: () => setState(() => _hide = !_hide))),
                      if (!_signUp)
                        Align(alignment: Alignment.centerRight,
                            child: TextButton(onPressed: _forgot, child: const Text('Forgot password?'))),
                      if (_msg != null)
                        Padding(padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Text(_msg!, style: TextStyle(fontSize: 13, color: _isError ? const Color(0xFFD62F4B) : const Color(0xFF1B8F55)))),
                      const SizedBox(height: 6),
                      GestureDetector(
                        onTap: _busy ? null : _submit,
                        child: Container(
                          height: 50, alignment: Alignment.center,
                          decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(16)),
                          child: _busy
                              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                              : Text(_signUp ? 'Create account' : 'Sign in',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                        ),
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(onPressed: _busy ? null : _google, icon: const Icon(Icons.g_mobiledata, size: 28),
                          label: const Text('Continue with Google'),
                          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)))),
                    ]),
                  ),
                  TextButton(
                    onPressed: () => setState(() { _signUp = !_signUp; _msg = null; }),
                    child: Text(_signUp ? 'Already have an account? Sign in' : 'New here? Create an account',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  ),
                ]),
              ),
            ),
          ),
        ),
      );

  Widget _field(TextEditingController c, String label, IconData icon,
          {bool obscure = false, TextInputType? type, Widget? suffix}) =>
      TextField(
        controller: c, obscureText: obscure, keyboardType: type, autocorrect: false,
        decoration: InputDecoration(
          labelText: label, prefixIcon: Icon(icon), suffixIcon: suffix,
          filled: true, fillColor: Brand.bg,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
      );
}
