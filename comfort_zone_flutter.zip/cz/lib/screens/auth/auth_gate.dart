import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/theme.dart';
import '../main_shell.dart';
import 'login_screen.dart';

/// Shows the app when signed in, the login screen otherwise. Reacts to sign in/out automatically.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    if (AppConfig.useMock) return const MainShell();   // demo mode has no auth
    final auth = Supabase.instance.client.auth;
    return StreamBuilder<AuthState>(
      stream: auth.onAuthStateChange,
      builder: (_, snap) {
        final session = snap.data?.session ?? auth.currentSession;
        return session == null ? const LoginScreen() : const MainShell();
      },
    );
  }
}
