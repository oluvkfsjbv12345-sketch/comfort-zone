import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/theme.dart';
import '../../data/admin_repository.dart';
import '../../models/wallet.dart';
import '../../widgets/balance_card.dart';

/// Review Bkash recharge requests: check the payment in your bKash app, then approve or reject.
class AdminRechargeScreen extends StatefulWidget {
  const AdminRechargeScreen({super.key});
  @override
  State<AdminRechargeScreen> createState() => _AdminRechargeScreenState();
}

class _AdminRechargeScreenState extends State<AdminRechargeScreen> {
  final _repo = AdminRepository();
  static const _tabs = [('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')];
  int _tab = 0;
  List<AdminRecharge> _items = [];
  int _pendingCount = 0;
  bool _loading = true;
  String? _error, _actingOn;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = _items.isEmpty; _error = null; });
    try {
      final items = await _repo.list(_tabs[_tab].$1);
      final pending = _tab == 0 ? items.length : (await _repo.list('pending')).length;
      if (mounted) setState(() { _items = items; _pendingCount = pending; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = friendly(e); _loading = false; });
    }
  }

  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _approve(AdminRecharge r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Approve ৳${r.amountBdt}?'),
        content: Text('Open your bKash app first. Approve only if TrxID ${r.trxId} shows ৳${r.amountBdt} received.\n\n'
            '${r.name} will get ${formatCoins(r.coins)} coins.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Approve and add coins')),
        ]));
    if (ok == true) _act(r, () => _repo.approve(r.id), 'Approved. ${formatCoins(r.coins)} coins added to ${r.name}.');
  }

  Future<void> _reject(AdminRecharge r) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Reject this request?'),
        content: TextField(controller: note, maxLength: 120, decoration: const InputDecoration(hintText: 'Reason (optional), e.g. TrxID not found')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD62F4B)),
              onPressed: () => Navigator.pop(c, true), child: const Text('Reject')),
        ]));
    final reason = note.text;
    note.dispose();
    if (ok == true) _act(r, () => _repo.reject(r.id, reason), 'Request rejected.');
  }

  Future<void> _act(AdminRecharge r, Future<void> Function() run, String done) async {
    setState(() => _actingOn = r.id);
    try { await run(); _toast(done); await _load(); }
    catch (e) { _toast(friendly(e)); await _load(); }   // e.g. already reviewed elsewhere
    if (mounted) setState(() => _actingOn = null);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Recharge requests', style: TextStyle(fontWeight: FontWeight.w800))),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
            child: Row(children: [
              for (var i = 0; i < _tabs.length; i++) ...[
                if (i > 0) const SizedBox(width: 8),
                _chip(i),
              ],
            ]),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _load,
              child: _loading
                  ? ListView(children: const [SizedBox(height: 120), Center(child: CircularProgressIndicator())])
                  : _error != null
                      ? _msg('Could not load requests. $_error')
                      : _items.isEmpty
                          ? _msg(_tab == 0 ? 'No requests waiting. New Bkash requests appear here.' : 'Nothing here yet.')
                          : ListView.separated(
                              padding: const EdgeInsets.fromLTRB(14, 4, 14, 20), itemCount: _items.length,
                              separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) => _card(_items[i])),
            ),
          ),
        ]),
      );

  Widget _msg(String t) => ListView(children: [
        Padding(padding: const EdgeInsets.all(40), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute))),
      ]);

  Widget _chip(int i) {
    final on = i == _tab;
    final label = i == 0 && _pendingCount > 0 ? 'Pending ($_pendingCount)' : _tabs[i].$2;
    return GestureDetector(
      onTap: () { setState(() { _tab = i; _items = []; }); _load(); },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(gradient: on ? Brand.gradient : null, color: on ? null : Colors.white, borderRadius: BorderRadius.circular(99)),
        child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: on ? Colors.white : Brand.ink)),
      ),
    );
  }

  Widget _card(AdminRecharge r) {
    final pending = r.status == 'pending';
    final busy = _actingOn == r.id;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Brand.violet.withOpacity(.08), blurRadius: 16, offset: const Offset(0, 4))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('৳${r.amountBdt}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(width: 8),
          Text('→ ${formatCoins(r.coins)} coins', style: const TextStyle(color: Brand.violet, fontWeight: FontWeight.w700)),
          const Spacer(),
          Text(timeAgo(r.createdAt), style: const TextStyle(fontSize: 12, color: Brand.mute)),
        ]),
        const SizedBox(height: 8),
        Text('${r.name}  ·  ${r.handle}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        const SizedBox(height: 8),
        _copyRow('TrxID', r.trxId),
        if (r.senderNumber != null) _copyRow('Sent from', r.senderNumber!),
        if (!pending) ...[
          const SizedBox(height: 6),
          Text(r.status == 'approved' ? 'Approved' : 'Rejected${r.adminNote != null ? ': ${r.adminNote}' : ''}',
              style: TextStyle(fontWeight: FontWeight.w700, color: r.status == 'approved' ? const Color(0xFF1B8F55) : const Color(0xFFD62F4B))),
        ],
        if (pending) ...[
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: busy ? null : () => _reject(r),
              style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFD62F4B), side: const BorderSide(color: Color(0xFFD62F4B)),
                  minimumSize: const Size.fromHeight(44), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: const Text('Reject'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton(
              onPressed: busy ? null : () => _approve(r),
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1B8F55), minimumSize: const Size.fromHeight(44),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Approve'))),
          ]),
        ],
      ]),
    );
  }

  Widget _copyRow(String label, String value) => Padding(
        padding: const EdgeInsets.only(top: 2),
        child: Row(children: [
          SizedBox(width: 70, child: Text(label, style: const TextStyle(fontSize: 12, color: Brand.mute))),
          Expanded(child: SelectableText(value, style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: .5))),
          InkWell(
            onTap: () async { await Clipboard.setData(ClipboardData(text: value)); _toast('$label copied'); },
            child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.copy, size: 16, color: Brand.violet))),
        ]),
      );
}
