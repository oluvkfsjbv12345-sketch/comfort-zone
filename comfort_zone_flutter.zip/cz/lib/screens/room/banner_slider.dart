import 'package:flutter/material.dart';
import '../../models/room.dart';

/// Swipeable promo banners with page dots.
class BannerSlider extends StatefulWidget {
  final List<PromoBanner> banners;
  const BannerSlider({super.key, required this.banners});
  @override
  State<BannerSlider> createState() => _BannerSliderState();
}

class _BannerSliderState extends State<BannerSlider> {
  final _ctrl = PageController(viewportFraction: .92);
  int _page = 0;

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Column(children: [
        SizedBox(
          height: 108,
          child: PageView.builder(
            controller: _ctrl,
            itemCount: widget.banners.length,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (_, i) {
              final b = widget.banners[i];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 5),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [b.from, b.to]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b.title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(b.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                ]),
              );
            },
          ),
        ),
        if (widget.banners.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 0; i < widget.banners.length; i++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == _page ? 16 : 6, height: 6,
                  decoration: BoxDecoration(
                    color: i == _page ? const Color(0xFF7B4DFF) : const Color(0xFFD6CDEA),
                    borderRadius: BorderRadius.circular(3)),
                ),
            ]),
          ),
      ]);
}
