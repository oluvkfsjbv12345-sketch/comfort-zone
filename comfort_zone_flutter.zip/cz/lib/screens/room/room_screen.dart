import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../data/room_repository.dart';
import '../../models/room.dart';
import 'banner_slider.dart';
import 'room_card.dart';
import 'voice_room_screen.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key});
  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  final _repo = RoomRepository();
  static const _cats = ['Related', 'Party', 'Activity', 'Ranking'];
  static const _catKey = {'Related': 'all', 'Party': 'party', 'Activity': 'activity', 'Ranking': 'all'};

  int _cat = 0;
  bool _hot = true;                 // Hot vs Country/Region
  String _country = 'IN';           // TODO: read from profiles.country_code
  List<Room> _rooms = [];
  List<PromoBanner> _banners = [];
  bool _loading = true;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        _repo.fetchRooms(category: _catKey[_cats[_cat]]!, countryCode: _hot ? null : _country),
        _repo.fetchBanners(),
      ]);
      if (!mounted) return;
      setState(() {
        _rooms = results[0] as List<Room>;
        _banners = results[1] as List<PromoBanner>;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _error = e; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: _load,
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: _header()),
          SliverToBoxAdapter(child: _categoryTabs()),
          if (_banners.isNotEmpty) SliverToBoxAdapter(child: BannerSlider(banners: _banners)),
          SliverToBoxAdapter(child: _filters()),
          if (_loading)
            const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator()))
          else if (_error != null)
            SliverFillRemaining(hasScrollBody: false, child: _message('Could not load rooms. Pull down to try again.'))
          else if (_rooms.isEmpty)
            SliverFillRemaining(hasScrollBody: false, child: _message('No live rooms here yet. Start one and invite friends.'))
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
              sliver: SliverList.separated(
                itemCount: _rooms.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) => RoomCard(
                  room: _rooms[i],
                  onJoin: () => _join(_rooms[i]),
                ),
              ),
            ),
        ]),
      );

  Future<void> _join(Room r) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => VoiceRoomScreen(room: r)));
    if (mounted) _load(); // refresh listener counts after leaving
  }

  Widget _message(String t) => Center(
      child: Padding(padding: const EdgeInsets.all(32),
          child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute))));

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Row(children: [
          ShaderMask(
            shaderCallback: (r) => Brand.gradient.createShader(r),
            child: const Text('Comfort Zone',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white)),
          ),
          const Spacer(),
          _iconBtn(Icons.search, 'Search rooms', () {}),
          const SizedBox(width: 8),
          _iconBtn(Icons.add, 'Create room', () {}),
        ]),
      );

  Widget _iconBtn(IconData i, String tip, VoidCallback onTap) => Material(
        color: Colors.white, elevation: 1, borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12), onTap: onTap,
          child: Tooltip(message: tip, child: SizedBox(width: 38, height: 38, child: Icon(i, size: 20))),
        ),
      );

  Widget _categoryTabs() => SizedBox(
        height: 44,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _cats.length,
          separatorBuilder: (_, __) => const SizedBox(width: 20),
          itemBuilder: (_, i) {
            final on = i == _cat;
            return GestureDetector(
              onTap: () { setState(() => _cat = i); _load(); },
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(_cats[i], style: TextStyle(
                    fontSize: on ? 17 : 15, fontWeight: on ? FontWeight.w800 : FontWeight.w600,
                    color: on ? Brand.ink : Brand.mute)),
                const SizedBox(height: 4),
                AnimatedContainer(duration: const Duration(milliseconds: 200), height: 3, width: on ? 22 : 0,
                    decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(2))),
              ]),
            );
          },
        ),
      );

  Widget _filters() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Row(children: [
          _chip('Hot', _hot, () { setState(() => _hot = true); _load(); }),
          const SizedBox(width: 8),
          _chip('Country / Region', !_hot, () { setState(() => _hot = false); _load(); }),
        ]),
      );

  Widget _chip(String label, bool on, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            gradient: on ? Brand.gradient : null, color: on ? null : Colors.white,
            borderRadius: BorderRadius.circular(99),
          ),
          child: Text(label, style: TextStyle(
              fontSize: 13, fontWeight: FontWeight.w600, color: on ? Colors.white : Brand.ink)),
        ),
      );
}
