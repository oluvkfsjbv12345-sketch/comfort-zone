import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../models/voice.dart';

/// 8 mic seats in a 4x2 grid. Empty seat = tap to sit; taken seat = tap to send a gift.
class SeatGrid extends StatelessWidget {
  final List<Seat> seats;
  final ValueListenable<Set<int>> speaking;
  final String hostId, myId;
  final bool myMuted;
  final void Function(int seatNo, Seat? occupant) onTap;
  const SeatGrid({super.key, required this.seats, required this.speaking, required this.hostId,
      required this.myId, required this.myMuted, required this.onTap});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Set<int>>(
        valueListenable: speaking,
        builder: (_, talking, __) => GridView.count(
          crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 14, crossAxisSpacing: 6, childAspectRatio: .8,
          children: List.generate(8, (i) {
            final no = i + 1;
            final s = seats.where((x) => x.no == no).firstOrNull;
            return _SeatTile(no: no, seat: s, talking: s != null && talking.contains(s.agoraUid),
                isHost: s?.userId == hostId, muted: s?.userId == myId && myMuted, onTap: () => onTap(no, s));
          }),
        ),
      );
}

class _SeatTile extends StatelessWidget {
  final int no;
  final Seat? seat;
  final bool talking, isHost, muted;
  final VoidCallback onTap;
  const _SeatTile({required this.no, required this.seat, required this.talking,
      required this.isHost, required this.muted, required this.onTap});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true, label: seat == null ? 'Empty seat $no, tap to sit' : '${seat!.name}, seat $no',
        child: GestureDetector(
          onTap: onTap,
          child: Column(children: [
            Stack(clipBehavior: Clip.none, children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 200), width: 62, height: 62, padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(shape: BoxShape.circle,
                    gradient: talking ? Brand.gradient : null, color: talking ? null : Colors.white24),
                child: seat == null
                    ? const CircleAvatar(backgroundColor: Color(0x22FFFFFF), child: Icon(Icons.add, color: Colors.white70))
                    : CircleAvatar(
                        backgroundColor: Brand.violet,
                        backgroundImage: seat!.avatarUrl != null ? NetworkImage(seat!.avatarUrl!) : null,
                        child: seat!.avatarUrl == null
                            ? Text(seat!.name.isEmpty ? '?' : seat!.name[0].toUpperCase(),
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20))
                            : null),
              ),
              if (isHost) const Positioned(top: -8, right: -2, child: Text('👑', style: TextStyle(fontSize: 16))),
              if (muted)
                const Positioned(bottom: 0, right: 0, child: CircleAvatar(radius: 9,
                    backgroundColor: Brand.coral, child: Icon(Icons.mic_off, size: 11, color: Colors.white))),
            ]),
            const SizedBox(height: 6),
            Text(seat?.name ?? 'Seat $no', maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 11, color: seat == null ? Colors.white38 : Colors.white)),
          ]),
        ),
      );
}
