import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../models/room.dart';

class RoomCard extends StatelessWidget {
  final Room room;
  final VoidCallback onJoin;
  const RoomCard({super.key, required this.room, required this.onJoin});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Brand.violet.withOpacity(.08), blurRadius: 16, offset: const Offset(0, 4))],
        ),
        child: Row(children: [
          _cover(),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(room.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 5),
            Row(children: [
              if (room.agencyName.isNotEmpty) _agencyBadge(),
              if (room.flag.isNotEmpty) Padding(padding: const EdgeInsets.only(left: 6), child: Text(room.flag)),
            ]),
            const SizedBox(height: 5),
            Row(children: [
              if (room.isLive) const _LiveDot(),
              const SizedBox(width: 6),
              Text('${room.listenerCount} listening', style: const TextStyle(fontSize: 12, color: Brand.mute)),
            ]),
          ])),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: onJoin,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
              decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(99)),
              child: Text(room.listenerCount > 800 ? 'Join Room' : 'Chat',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
            ),
          ),
        ]),
      );

  Widget _cover() => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(
          width: 56, height: 56,
          child: room.coverUrl != null
              ? Image.network(room.coverUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback())
              : _fallback(),
        ),
      );

  Widget _fallback() => Container(
        decoration: const BoxDecoration(gradient: Brand.gradient),
        alignment: Alignment.center,
        child: Text(room.title[0], style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
      );

  Widget _agencyBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(color: const Color(0xFFFFE9B8), borderRadius: BorderRadius.circular(99)),
        child: Text(room.agencyName,
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF8A5A00))),
      );
}

/// Pulsing green "live" indicator.
class _LiveDot extends StatefulWidget {
  const _LiveDot();
  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot> with SingleTickerProviderStateMixin {
  late final _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
      opacity: Tween(begin: .35, end: 1.0).animate(_c),
      child: Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF28C76F), shape: BoxShape.circle)));
}
