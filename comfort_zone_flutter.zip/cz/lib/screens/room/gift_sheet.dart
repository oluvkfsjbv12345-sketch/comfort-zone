import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../models/voice.dart';

/// Bottom sheet: pick a receiver, a gift and a quantity, then send.
class GiftSheet extends StatefulWidget {
  final List<Gift> gifts;
  final List<Seat> receivers;
  final Seat? initial;
  final int coins;
  final Future<int> Function(Gift gift, Seat to, int qty) onSend; // returns new balance
  const GiftSheet({super.key, required this.gifts, required this.receivers, required this.coins,
      required this.onSend, this.initial});
  @override
  State<GiftSheet> createState() => _GiftSheetState();
}

class _GiftSheetState extends State<GiftSheet> {
  Gift? _gift;
  Seat? _to;
  int _qty = 1;
  late int _coins = widget.coins;
  bool _sending = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _to = widget.initial ?? (widget.receivers.isNotEmpty ? widget.receivers.first : null);
  }

  Future<void> _send() async {
    setState(() { _sending = true; _err = null; });
    try {
      _coins = await widget.onSend(_gift!, _to!, _qty);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) setState(() { _err = '$e'.replaceFirst('PostgrestException(message: ', '').split(',').first; _sending = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = (_gift?.price ?? 0) * _qty;
    final ready = _gift != null && _to != null && !_sending;
    return Container(
      padding: EdgeInsets.fromLTRB(16, 14, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
      decoration: const BoxDecoration(color: Color(0xFF241A3F),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (widget.receivers.isEmpty)
          const Padding(padding: EdgeInsets.all(24),
              child: Center(child: Text('Nobody is on a seat yet. Gifts go to people on the mic.',
                  style: TextStyle(color: Colors.white60), textAlign: TextAlign.center)))
        else ...[
          const Text('Send to', style: TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, children: [
            for (final s in widget.receivers)
              ChoiceChip(label: Text(s.name), selected: _to?.userId == s.userId,
                  selectedColor: Brand.violet, labelStyle: const TextStyle(color: Colors.white),
                  backgroundColor: Colors.white12, side: BorderSide.none,
                  onSelected: (_) => setState(() => _to = s)),
          ]),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .85,
            children: [for (final g in widget.gifts) _giftTile(g)],
          ),
          const SizedBox(height: 14),
          Row(children: [
            Text('🪙 $_coins', style: const TextStyle(color: Brand.gold, fontWeight: FontWeight.w800)),
            const Spacer(),
            IconButton(onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                icon: const Icon(Icons.remove_circle_outline), color: Colors.white),
            Text('$_qty', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            IconButton(onPressed: _qty < 99 ? () => setState(() => _qty++) : null,
                icon: const Icon(Icons.add_circle_outline), color: Colors.white),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: ready ? _send : null,
              child: Opacity(
                opacity: ready ? 1 : .4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 11),
                  decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(99)),
                  child: _sending
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Text(total > 0 ? 'Send · $total' : 'Send',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                ),
              ),
            ),
          ]),
          if (_err != null)
            Padding(padding: const EdgeInsets.only(top: 8),
                child: Text(_err!, style: const TextStyle(color: Brand.coral, fontSize: 12))),
        ],
      ]),
    );
  }

  Widget _giftTile(Gift g) {
    final on = _gift?.id == g.id;
    return GestureDetector(
      onTap: () => setState(() => _gift = g),
      child: Container(
        decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: on ? Brand.coral : Colors.transparent, width: 2)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(g.emoji, style: const TextStyle(fontSize: 30)),
          const SizedBox(height: 4),
          Text(g.name, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
          Text('🪙 ${g.price}', style: const TextStyle(color: Brand.gold, fontSize: 10)),
        ]),
      ),
    );
  }
}
