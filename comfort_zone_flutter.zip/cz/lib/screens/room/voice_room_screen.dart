import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/theme.dart';
import '../../data/voice_repository.dart';
import '../../models/room.dart';
import '../../models/voice.dart';
import '../../services/agora_service.dart';
import 'gift_sheet.dart';
import 'seat_grid.dart';

class VoiceRoomScreen extends StatefulWidget {
  final Room room;
  const VoiceRoomScreen({super.key, required this.room});
  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> {
  final _repo = VoiceRepository();
  final _agora = AgoraService();
  MyProfile? _me;
  List<Seat> _seats = [];
  bool _muted = false;
  String? _banner, _error;
  Timer? _bannerTimer;
  RealtimeChannel? _channel;

  Room get _room => widget.room;
  Seat? get _mySeat => _seats.where((s) => s.userId == _me?.id).firstOrNull;

  @override
  void initState() {
    super.initState();
    _enter();
  }

  Future<void> _enter() async {
    try {
      _me = await _repo.me();
      await _repo.joinRoom(_room.id);
      if (AppConfig.voiceEnabled) {
        await _agora.init(AppConfig.agoraAppId);
        final token = await _repo.agoraToken(_room.agoraChannel, _me!.agoraUid, publisher: false);
        await _agora.join(token: token, channel: _room.agoraChannel, uid: _me!.agoraUid);
      }
      _channel = _repo.watch(_room.id, onSeats: _refresh, onGift: _showGift);
      await _refresh();
    } catch (e) {
      if (mounted) setState(() => _error = _msg(e));
    }
  }

  Future<void> _refresh() async {
    final s = await _repo.seats(_room.id);
    if (mounted) setState(() => _seats = s);
  }

  String _msg(Object e) => e is PostgrestException ? e.message : '$e';
  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  void _showGift(GiftEvent g) {
    _bannerTimer?.cancel();
    setState(() => _banner = '${g.senderName} sent ${g.qty > 1 ? '${g.qty}× ' : ''}${g.emoji} to ${g.receiverName}');
    _bannerTimer = Timer(const Duration(seconds: 3), () { if (mounted) setState(() => _banner = null); });
  }

  Future<void> _takeSeat(int no) async {
    try {
      await _repo.takeSeat(_room.id, no);
      if (AppConfig.voiceEnabled) {
        // Server confirms the seat before issuing a token that allows publishing.
        final t = await _repo.agoraToken(_room.agoraChannel, _me!.agoraUid, publisher: true);
        await _agora.renewToken(t);
        await _agora.setSpeaker(true);
      }
      _muted = false;
      await _refresh();
    } catch (e) { _toast(_msg(e)); await _refresh(); }
  }

  Future<void> _leaveSeat() async {
    try {
      await _repo.leaveSeat(_room.id);
      if (AppConfig.voiceEnabled) await _agora.setSpeaker(false);
      await _refresh();
    } catch (e) { _toast(_msg(e)); }
  }

  Future<void> _toggleMute() async {
    setState(() => _muted = !_muted);
    if (AppConfig.voiceEnabled) await _agora.mute(_muted);
  }

  void _onSeatTap(int no, Seat? s) {
    if (s == null) { _takeSeat(no); return; }
    if (s.userId == _me?.id) { _leaveSeat(); return; }   // tap yourself to step down
    _openGifts(to: s);
  }

  Future<void> _openGifts({Seat? to}) async {
    final gifts = await _repo.gifts();
    final me = await _repo.me();
    if (!mounted) return;
    final receivers = _seats.where((s) => s.userId != me.id).toList();
    await showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => GiftSheet(
        gifts: gifts, receivers: receivers, initial: to, coins: me.coins,
        onSend: (g, seat, qty) => _repo.sendGift(_room.id, seat.userId, g, qty),
      ),
    );
  }

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _repo.unwatch(_channel);
    _repo.leaveRoom(_room.id);          // frees seat + decrements listener count
    if (AppConfig.voiceEnabled) _agora.leave();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF1A1230),
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Color(0xFF3A2380), Color(0xFF1A1230)])),
          child: SafeArea(
            child: _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(24),
                    child: Text(_error!, style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center)))
                : _me == null
                    ? const Center(child: CircularProgressIndicator())
                    : Column(children: [_header(), _giftBanner(), _grid(), const Spacer(), _controls()]),
          ),
        ),
      );

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 16, 8),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 30),
              tooltip: 'Leave room', onPressed: () => Navigator.pop(context)),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_room.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
            Text('${_room.flag} ${_room.listenerCount} listening',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
          if (!AppConfig.voiceEnabled)
            const Tooltip(message: 'Demo mode: voice is off', child: Icon(Icons.volume_off, color: Colors.white38, size: 20)),
        ]),
      );

  Widget _giftBanner() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: _banner == null
            ? const SizedBox(height: 36, key: ValueKey('none'))
            : Container(
                key: ValueKey(_banner), height: 36, margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.symmetric(horizontal: 14), alignment: Alignment.center,
                decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(99)),
                child: Text(_banner!, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))),
      );

  Widget _grid() => Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
        child: SeatGrid(
            seats: _seats, speaking: _agora.speaking, hostId: _room.ownerId, myId: _me!.id,
            myMuted: _muted, onTap: _onSeatTap),
      );

  Widget _controls() {
    final seated = _mySeat != null;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 0, 14, 14), padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        _round(seated ? (_muted ? Icons.mic_off : Icons.mic) : Icons.mic_none,
            seated ? (_muted ? 'Unmute' : 'Mute') : 'Take a seat to speak',
            seated ? _toggleMute : null, active: seated && !_muted),
        const Expanded(child: Padding(padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('Tap an empty seat to speak. Tap someone to send a gift.',
                style: TextStyle(color: Colors.white54, fontSize: 12)))),
        _round(Icons.card_giftcard, 'Send gift', () => _openGifts(), gradient: true),
        const SizedBox(width: 8),
        _round(Icons.call_end, 'Leave room', () => Navigator.pop(context), danger: true),
      ]),
    );
  }

  Widget _round(IconData i, String tip, VoidCallback? onTap,
      {bool active = false, bool gradient = false, bool danger = false}) => Tooltip(
        message: tip,
        child: GestureDetector(
          onTap: onTap,
          child: Opacity(
            opacity: onTap == null ? .4 : 1,
            child: Container(
              width: 46, height: 46,
              decoration: BoxDecoration(shape: BoxShape.circle,
                  gradient: gradient ? Brand.gradient : null,
                  color: gradient ? null : danger ? const Color(0xFFE5484D) : active ? Brand.violet : Colors.white12),
              child: Icon(i, color: Colors.white, size: 22)),
          ),
        ),
      );
}
