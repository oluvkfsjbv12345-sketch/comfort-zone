import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../data/message_repository.dart';
import '../services/notification_service.dart';
import '../services/unread_service.dart';
import 'discover/discover_screen.dart';
import 'gaming/gaming_screen.dart';
import 'me/me_screen.dart';
import 'message/message_screen.dart';
import 'room/room_screen.dart';

/// Hosts the 5 tabs. IndexedStack keeps each tab's state alive when switching
/// (scroll position, filters), which keeps tab changes instant.
class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final _messages = MessageRepository();
  RealtimeChannel? _inbox;
  int _index = 0;

  static const _tabs = <Widget>[RoomScreen(), GamingScreen(), DiscoverScreen(), MessageScreen(), MeScreen()];

  @override
  void initState() {
    super.initState();
    UnreadService.refresh();
    NotificationService.instance.start();   // recharge alerts + coins-landed alerts
    _inbox = _messages.watchIncoming((_) => UnreadService.refresh());   // live badge updates
  }

  @override
  void dispose() { _messages.unwatch(_inbox); NotificationService.instance.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(bottom: false, child: IndexedStack(index: _index, children: _tabs)),
        bottomNavigationBar: ValueListenableBuilder<int>(
          valueListenable: UnreadService.count,
          builder: (_, count, __) => NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: (i) => setState(() => _index = i),
            destinations: [
              const NavigationDestination(icon: Icon(Icons.celebration_outlined), selectedIcon: Icon(Icons.celebration), label: 'Room'),
              const NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Gaming'),
              const NavigationDestination(icon: Icon(Icons.public_outlined), selectedIcon: Icon(Icons.public), label: 'Discover'),
              NavigationDestination(
                icon: Badge(isLabelVisible: count > 0, label: Text('$count'), child: const Icon(Icons.chat_bubble_outline)),
                selectedIcon: Badge(isLabelVisible: count > 0, label: Text('$count'), child: const Icon(Icons.chat_bubble)),
                label: 'Message'),
              const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Me'),
            ],
          ),
        ),
      );
}
