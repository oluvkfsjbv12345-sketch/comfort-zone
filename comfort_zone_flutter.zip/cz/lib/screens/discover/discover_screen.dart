import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';
import '../../data/family_repository.dart';
import '../../models/game.dart';
import 'create_family_sheet.dart';
import 'family_perks_card.dart';
import 'family_tile.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final _repo = FamilyRepository();
  static const _tabs = ['Following', 'Trending', 'Family'];
  int _tab = 2;
  List<Family> _families = [];
  Family? _mine;
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = _families.isEmpty; _error = null; });
    try {
      final r = await Future.wait([_repo.recommended(), _repo.mine()]);
      if (mounted) setState(() { _families = r[0] as List<Family>; _mine = r[1] as Family?; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = friendly(e); _loading = false; });
    }
  }

  void _toast(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _run(Future<void> Function() action, String done) async {
    try { await action(); _toast(done); await _load(); } catch (e) { _toast(friendly(e)); }
  }

  Future<void> _create() async {
    await showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => CreateFamilySheet(onCreate: _repo.create));
    await _load();
  }

  Future<void> _confirmLeave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Leave ${_mine!.name}?'),
        content: const Text('You can join another family afterwards.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Stay')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Leave family')),
        ]));
    if (ok == true) _run(_repo.leave, 'You left the family');
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: _load,
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: _header()),
          if (_tab != 2)
            SliverFillRemaining(hasScrollBody: false, child: _empty(_tab == 0
                ? 'You are not following anyone yet. Follow hosts from a voice room to see them here.'
                : 'Trending moments will show up here soon.'))
          else ..._familySlivers(),
        ]),
      );

  List<Widget> _familySlivers() {
    final others = _families.where((f) => f.id != _mine?.id).toList();
    return [
      const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.fromLTRB(14, 4, 14, 0), child: FamilyPerksCard())),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
          child: _mine == null
              ? GestureDetector(
                  onTap: _create,
                  child: Container(height: 50, alignment: Alignment.center,
                      decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(16)),
                      child: const Text('+ Create Family', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15))))
              : FamilyTile(family: _mine!, label: 'Leave', outlined: true, onTap: _confirmLeave, badge: 'Your family'),
        ),
      ),
      const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Text('Recommended families', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))),
      if (_loading)
        const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator()))
      else if (_error != null)
        SliverFillRemaining(hasScrollBody: false, child: _empty('Could not load families. Pull down to try again.'))
      else if (others.isEmpty)
        SliverFillRemaining(hasScrollBody: false, child: _empty('No families to show yet. Create the first one.'))
      else
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
          sliver: SliverList.separated(
            itemCount: others.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final f = others[i];
              return FamilyTile(family: f, label: f.isFull ? 'Full' : 'Join',
                  onTap: f.isFull ? null : () => _run(() => _repo.join(f), 'Joined ${f.name}'));
            }),
        ),
    ];
  }

  Widget _empty(String t) => Center(child: Padding(padding: const EdgeInsets.all(32),
      child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Brand.mute))));

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
        child: Row(children: [
          for (var i = 0; i < _tabs.length; i++)
            Padding(
              padding: const EdgeInsets.only(right: 20),
              child: GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: Column(children: [
                  Text(_tabs[i], style: TextStyle(fontSize: i == _tab ? 18 : 15,
                      fontWeight: i == _tab ? FontWeight.w800 : FontWeight.w600, color: i == _tab ? Brand.ink : Brand.mute)),
                  const SizedBox(height: 4),
                  AnimatedContainer(duration: const Duration(milliseconds: 200), height: 3, width: i == _tab ? 22 : 0,
                      decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(2))),
                ]),
              ),
            ),
        ]),
      );
}
