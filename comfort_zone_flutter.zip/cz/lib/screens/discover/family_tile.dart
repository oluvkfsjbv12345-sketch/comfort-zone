import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../models/game.dart';

/// One family row: logo, name, ID, members and an action button.
class FamilyTile extends StatelessWidget {
  final Family family;
  final String label;
  final String? badge;
  final bool outlined;
  final VoidCallback? onTap;   // null = disabled (e.g. family full)
  const FamilyTile({super.key, required this.family, required this.label, required this.onTap,
      this.badge, this.outlined = false});

  /// Stable gradient per family so logos look distinct without uploads.
  Gradient get _logoGradient {
    final h = family.code.codeUnits.fold<int>(0, (a, b) => a * 31 + b) % 360;
    return LinearGradient(colors: [HSLColor.fromAHSL(1, h.toDouble(), .7, .55).toColor(),
        HSLColor.fromAHSL(1, (h + 40) % 360, .75, .6).toColor()]);
  }

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Brand.violet.withOpacity(.08), blurRadius: 16, offset: const Offset(0, 4))]),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: SizedBox(width: 56, height: 56,
              child: family.logoUrl != null
                  ? Image.network(family.logoUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _initial())
                  : _initial()),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (badge != null)
              Text(badge!, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Brand.violet)),
            Text(family.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 4),
            Text('ID ${family.code}', style: const TextStyle(fontSize: 12, color: Brand.mute)),
            Text('${family.memberCount}/${family.capacity} members', style: const TextStyle(fontSize: 12, color: Brand.mute)),
          ])),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: onTap,
            child: Opacity(
              opacity: onTap == null ? .45 : 1,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
                decoration: BoxDecoration(
                  gradient: outlined || onTap == null ? null : Brand.gradient,
                  color: onTap == null ? Colors.black12 : null,
                  border: outlined ? Border.all(color: Brand.violet, width: 1.5) : null,
                  borderRadius: BorderRadius.circular(99)),
                child: Text(label, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13,
                    color: outlined ? Brand.violet : onTap == null ? Brand.mute : Colors.white)),
              ),
            ),
          ),
        ]),
      );

  Widget _initial() => Container(
      decoration: BoxDecoration(gradient: _logoGradient), alignment: Alignment.center,
      child: Text(family.name[0].toUpperCase(),
          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)));
}
