import 'package:flutter/material.dart';
import '../../core/errors.dart';
import '../../core/theme.dart';

class CreateFamilySheet extends StatefulWidget {
  final Future<void> Function(String name) onCreate;
  const CreateFamilySheet({super.key, required this.onCreate});
  @override
  State<CreateFamilySheet> createState() => _CreateFamilySheetState();
}

class _CreateFamilySheetState extends State<CreateFamilySheet> {
  final _name = TextEditingController();
  bool _busy = false;
  String? _err;

  @override
  void dispose() { _name.dispose(); super.dispose(); }

  Future<void> _submit() async {
    final n = _name.text.trim();
    if (n.length < 2) { setState(() => _err = 'Family name needs at least 2 characters.'); return; }
    setState(() { _busy = true; _err = null; });
    try {
      await widget.onCreate(n);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) setState(() { _err = friendly(e); _busy = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Create your family', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('You become the owner. Up to 300 members can join.', style: TextStyle(color: Brand.mute)),
            const SizedBox(height: 16),
            TextField(
              controller: _name, maxLength: 24, autofocus: true, textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(labelText: 'Family name', filled: true, fillColor: Brand.bg,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
              onSubmitted: (_) => _submit()),
            if (_err != null) Text(_err!, style: const TextStyle(color: Color(0xFFD62F4B), fontSize: 13)),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: _busy ? null : _submit,
              child: Container(height: 50, alignment: Alignment.center,
                  decoration: BoxDecoration(gradient: Brand.gradient, borderRadius: BorderRadius.circular(16)),
                  child: _busy
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Text('Create family', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
            ),
          ]),
        ),
      );
}
