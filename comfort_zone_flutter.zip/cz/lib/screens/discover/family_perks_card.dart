import 'package:flutter/material.dart';

class FamilyPerksCard extends StatelessWidget {
  const FamilyPerksCard({super.key});
  static const _perks = [('💎', 'Double Crystals'), ('🎁', 'Gift Rewards'), ('🛠', 'Exclusive Tools'), ('✅', 'Family Tasks')];

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF231A3A), Color(0xFF4A2D9C)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Join the Family to unlock privileges',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 3.6,
            children: [
              for (final p in _perks)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12), alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(12)),
                  child: Text('${p.$1}  ${p.$2}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
            ],
          ),
        ]),
      );
}
