import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/app_keys.dart';
import 'core/theme.dart';
import 'screens/auth/auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (!AppConfig.useMock) {
    await Supabase.initialize(url: AppConfig.supabaseUrl, anonKey: AppConfig.supabaseAnonKey);
  }
  runApp(const ComfortZoneApp());
}

class ComfortZoneApp extends StatelessWidget {
  const ComfortZoneApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Comfort Zone',
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: rootMessengerKey,
        theme: Brand.light(),
        home: const AuthGate(),
      );
}
