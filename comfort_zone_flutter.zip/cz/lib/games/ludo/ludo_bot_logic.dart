import 'dart:math';
import 'ludo_engine.dart';

enum LudoDifficulty { easy, medium, hard }

extension LudoDifficultyLabel on LudoDifficulty {
  String get label => switch (this) {
        LudoDifficulty.easy => 'Easy',
        LudoDifficulty.medium => 'Medium',
        LudoDifficulty.hard => 'Hard',
      };
}

class LudoBot {
  LudoBot(this.level, {Random? rng}) : _rng = rng ?? Random();

  final LudoDifficulty level;
  final Random _rng;

  int chooseMove(LudoGame g, List<int> options) {
    if (options.length == 1) return options.first;
    return switch (level) {
      LudoDifficulty.easy => _easy(g, options),
      LudoDifficulty.medium => _best(g, options, _greedyScore, 2.0),
      LudoDifficulty.hard => _best(g, options, _smartScore, 1.5),
    };
  }

  int _easy(LudoGame g, List<int> options) {
    final captures = [for (final t in options) if (_captureValue(g, _landing(g, t)) > 0) t];
    if (captures.isNotEmpty && _rng.nextDouble() < .35) return captures[_rng.nextInt(captures.length)];
    return options[_rng.nextInt(options.length)];
  }

  int _best(LudoGame g, List<int> options, double Function(LudoGame, int) score, double noise) {
    var best = options.first;
    var bestScore = double.negativeInfinity;
    for (final t in options) {
      final s = score(g, t) + _rng.nextDouble() * noise;
      if (s > bestScore) {
        bestScore = s;
        best = t;
      }
    }
    return best;
  }

  double _greedyScore(LudoGame g, int t) {
    final p = g.tokens[g.current]![t], n = g.target(t)!;
    var s = n.toDouble();
    if (p == -1) s += 30;
    if (n == 56) {
      s += 90;
    } else if (n > 50) {
      s += 25;
    }
    final cell = LudoGame.absCell(g.current, n);
    if (cell != null) {
      if (kSafe.contains(cell)) {
        s += 15;
      } else if (_captureValue(g, cell) > 0) {
        s += 100;
      }
    }
    return s;
  }

  double _smartScore(LudoGame g, int t) {
    final me = g.current;
    final p = g.tokens[me]![t], n = g.target(t)!;
    final cell = LudoGame.absCell(me, n);
    var s = 0.0;

    if (p == -1) {
      s += 40;
    } else {
      s += (n - p) + n * .3;
    }
    if (n == 56) {
      s += 110;
    } else if (n > 50 && p <= 50) {
      s += 35;
    }

    if (cell != null) {
      final cap = _captureValue(g, cell);
      if (cap > 0) {
        s += 60 + cap * 1.4;
      } else if (kSafe.contains(cell)) {
        s += 18;
      }
      final risk = _hitRolls(g, cell).length / 6;
      s -= risk * (n + 12) * 1.6;
    }

    if (p >= 0 && p <= 50) {
      final here = LudoGame.absCell(me, p)!;
      final riskNow = _hitRolls(g, here).length / 6;
      s += riskNow * (p + 12) * 1.6;
    }
    return s;
  }

  int? _landing(LudoGame g, int t) => LudoGame.absCell(g.current, g.target(t)!);

  int _captureValue(LudoGame g, int? cell) {
    if (cell == null || kSafe.contains(cell)) return 0;
    var v = 0;
    for (final s in g.seats) {
      if (s == g.current) continue;
      for (final q in g.tokens[s]!) {
        if (LudoGame.absCell(s, q) == cell) v += q + 1;
      }
    }
    return v;
  }

  Set<int> _hitRolls(LudoGame g, int cell) {
    if (kSafe.contains(cell)) return const <int>{};
    final rolls = <int>{};
    for (final s in g.seats) {
      if (s == g.current) continue;
      for (final q in g.tokens[s]!) {
        if (q < 0 || q > 50) continue;
        final oppCell = (kStart[s] + q) % 52;
        final d = (cell - oppCell + 52) % 52;
        if (d >= 1 && d <= 6 && q + d <= 50) rolls.add(d);
      }
    }
    return rolls;
  }
}
