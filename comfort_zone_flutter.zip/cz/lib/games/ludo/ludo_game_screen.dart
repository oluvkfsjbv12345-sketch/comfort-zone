import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/errors.dart';
import '../../data/ludo_repository.dart';
import 'ludo_board.dart';
import 'ludo_bot_logic.dart';
import 'ludo_engine.dart';

const _names = ['Red', 'Green', 'Yellow', 'Blue'];
const _bg = Color(0xFF1A1230);
const _rules = [
  'Roll a 6 to bring a token out of your yard onto your start square.',
  'Tokens travel clockwise. A 6 gives you another roll; three 6s in a row lose the turn.',
  'Land on an opponent token to send it back to its yard, unless it stands on a ★ or a start square. A capture gives another roll.',
  'Each token needs an exact roll to reach the centre. Reaching it gives another roll.',
  'The first player to bring all four tokens home wins.',
];

enum _Fx { roll, step, home, capture, win }

/// Playable Ludo: pass-the-phone (all humans) or vs computer (you are Red).
class LudoGameScreen extends StatefulWidget {
  final int playerCount;
  final bool vsComputer;
  final LudoDifficulty difficulty;

  /// game_modes.id this game was started from (stored with the result).
  final String? modeId;
  const LudoGameScreen({
    super.key,
    required this.playerCount,
    required this.vsComputer,
    this.difficulty = LudoDifficulty.medium,
    this.modeId,
  });
  @override
  State<LudoGameScreen> createState() => _LudoGameScreenState();
}

class _LudoGameScreenState extends State<LudoGameScreen> {
  final _rng = Random();
  final _repo = LudoRepository();
  late LudoGame g;
  late Set<int> bots;
  late Map<int, int> _captures;
  late LudoDifficulty _level = widget.difficulty;
  int _gen = 0;
  bool busy = false;
  bool _sound = true;
  bool _recorded = false;
  int face = 1;
  double _turns = 0;
  List<int> movable = const [];
  String msg = '';

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    _gen++;
    final n = widget.playerCount.clamp(2, 4);
    final seats = n == 2 ? [0, 2] : (n == 3 ? [0, 1, 2] : [0, 1, 2, 3]);
    g = LudoGame(seats, rng: _rng);
    bots = widget.vsComputer ? seats.skip(1).toSet() : <int>{};
    _captures = {for (final s in seats) s: 0};
    _recorded = false;
    busy = false;
    face = 1;
    movable = const [];
    msg = _turnMsg();
    _afterTurnChange();
  }

  String _label(int s) => widget.vsComputer ? (s == 0 ? 'You' : '${_names[s]} (bot)') : _names[s];
  String _panelName(int s) => widget.vsComputer && s != 0 ? '${_names[s]} 🤖' : (widget.vsComputer ? 'You' : _names[s]);
  String _turnMsg() =>
      bots.contains(g.current) ? '${_label(g.current)} is thinking…' : '${_label(g.current)}: roll the dice';
  int _home(int s) => g.tokens[s]!.where((p) => p == 56).length;

  bool get _canRoll => !busy && g.dice == null && g.winner == null && !bots.contains(g.current);
  bool _stale(int gen) => !mounted || gen != _gen;
  Future<void> _wait(int ms) => Future.delayed(Duration(milliseconds: ms));

  List<int> _distinct(List<int> opts) {
    final seen = <int>{};
    return [
      for (final t in opts)
        if (seen.add(g.tokens[g.current]![t])) t
    ];
  }

  void _fx(_Fx kind) {
    if (!_sound) return;
    switch (kind) {
      case _Fx.roll:
        HapticFeedback.lightImpact();
        SystemSound.play(SystemSoundType.click);
      case _Fx.step:
        HapticFeedback.selectionClick();
      case _Fx.home:
        HapticFeedback.mediumImpact();
      case _Fx.capture:
        HapticFeedback.heavyImpact();
      case _Fx.win:
        HapticFeedback.vibrate();
    }
  }

  void _afterTurnChange() {
    if (g.winner != null || !bots.contains(g.current)) return;
    final gen = _gen;
    _wait(700).then((_) {
      if (!_stale(gen)) _roll();
    });
  }

  Future<void> _roll() async {
    if (busy || g.dice != null || g.winner != null) return;
    final gen = _gen;
    setState(() {
      busy = true;
      msg = '${_label(g.current)} rolling…';
    });
    _fx(_Fx.roll);
    for (var i = 0; i < 8; i++) {
      await _wait(65);
      if (_stale(gen)) return;
      setState(() {
        face = 1 + _rng.nextInt(6);
        _turns += .25;
      });
    }
    final who = _label(g.current), d = g.roll();
    setState(() {
      face = d;
      _turns = _turns.ceilToDouble();
    });
    if (g.sixesInRow >= 3) {
      setState(() => msg = '$who rolled three 6s in a row: turn lost');
      return _pass(gen);
    }
    final opts = g.movable();
    if (opts.isEmpty) {
      setState(() => msg = '$who rolled $d: no move');
      return _pass(gen);
    }
    setState(() {
      movable = opts;
      msg = '$who rolled $d';
    });
    if (bots.contains(g.current)) {
      await _wait(650);
      if (!_stale(gen)) await _move(LudoBot(_level, rng: _rng).chooseMove(g, opts), gen);
    } else if (_distinct(opts).length == 1) {
      await _wait(350);
      if (!_stale(gen)) await _move(opts.first, gen);
    } else {
      setState(() {
        msg = '$who rolled $d: tap a glowing token';
        busy = false;
      });
    }
  }

  Future<void> _pass(int gen) async {
    await _wait(1000);
    if (_stale(gen)) return;
    g.endTurn(extra: false);
    setState(() {
      movable = const [];
      busy = false;
      msg = _turnMsg();
    });
    _afterTurnChange();
  }

  Future<void> _move(int t, int gen) async {
    setState(() {
      busy = true;
      movable = const [];
    });
    final mover = g.current, who = _label(mover), target = g.target(t)!;
    final list = g.tokens[mover]!, from = list[t];
    if (from == -1) {
      setState(() => list[t] = 0);
      _fx(_Fx.step);
      await _wait(250);
    } else {
      for (var p = from + 1; p <= target; p++) {
        setState(() => list[t] = p);
        _fx(_Fx.step);
        await _wait(125);
        if (_stale(gen)) return;
      }
    }
    if (_stale(gen)) return;

    final r = g.finishMove(t, target);
    if (r.captured) {
      _captures.update(mover, (v) => v + 1);
      _fx(_Fx.capture);
    } else if (r.reachedHome) {
      _fx(_Fx.home);
    }
    if (r.won) {
      setState(() {
        busy = false;
        msg = '$who won!';
      });
      _fx(_Fx.win);
      _record();
      _showWin();
      return;
    }
    final extra = g.current == mover;
    final again = extra ? (bots.contains(mover) ? ' Rolling again…' : ' Roll again.') : '';
    setState(() {
      busy = false;
      msg = r.captured
          ? '$who captured a token!$again'
          : r.reachedHome
              ? '$who got a token home!$again'
              : (extra ? '$who rolled a 6.$again' : _turnMsg());
    });
    _afterTurnChange();
  }

  /// Saves the result of a game against the computer (once). A failure must never block the win dialog.
  Future<void> _record() async {
    if (!widget.vsComputer || _recorded || g.winner == null) return;
    _recorded = true;
    try {
      await _repo.recordMatch(
        modeId: widget.modeId,
        players: g.seats.length,
        difficulty: _level.name,
        won: g.winner == 0,
        captures: _captures[0] ?? 0,
        tokensHome: _home(0),
      );
    } catch (e) {
      debugPrint('Ludo result not saved: ${friendly(e)}');
    }
  }

  void _tapToken(int t) {
    if (!busy && movable.contains(t)) _move(t, _gen);
  }

  Future<bool> _confirm(String title, String body, String yes, String no) async =>
      await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(no)),
            TextButton(onPressed: () => Navigator.pop(c, true), child: Text(yes)),
          ],
        ),
      ) ??
      false;

  Future<void> _confirmExit() async {
    if (g.winner != null) {
      Navigator.pop(context);
      return;
    }
    final leave = await _confirm('Leave the game?', 'Your progress will be lost.', 'Leave', 'Keep playing');
    if (leave && mounted) Navigator.pop(context);
  }

  Future<void> _restart() async {
    if (g.winner == null && !await _confirm('Restart the game?', 'This game will be abandoned.', 'Restart', 'Keep playing')) {
      return;
    }
    if (mounted) setState(_start);
  }

  void _menu(String v) {
    if (v == 'restart') {
      _restart();
    } else {
      setState(() => _level = LudoDifficulty.values.byName(v));
    }
  }

  void _showRules() => showModalBottomSheet<void>(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (_) => Container(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(context).viewPadding.bottom),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('How to play', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              for (final r in _rules)
                Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('•  $r', style: const TextStyle(height: 1.3))),
            ],
          ),
        ),
      );

  Future<void> _showWin() {
    final w = g.winner!;
    final title = widget.vsComputer ? (w == 0 ? '🎉 You won!' : '🤖 ${_names[w]} bot won') : '🎉 ${_names[w]} won!';
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (c) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final s in g.seats)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    CircleAvatar(radius: 6, backgroundColor: kLudoColors[s]),
                    const SizedBox(width: 8),
                    Expanded(child: Text('${_label(s)}: ${_home(s)}/4 home · ${_captures[s]} captures')),
                  ]),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(c);
                Navigator.pop(context);
              },
              child: const Text('Exit'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(c);
                setState(_start);
              },
              child: const Text('Play again'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: g.winner != null,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _confirmExit();
        },
        child: Scaffold(
          backgroundColor: _bg,
          body: SafeArea(
            child: Column(children: [
              _topBar(),
              _players(),
              Expanded(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: LudoBoard(game: g, movable: movable, onTokenTap: _tapToken),
                  ),
                ),
              ),
              _controls(),
            ]),
          ),
        ),
      );

  Widget _topBar() => Row(children: [
        IconButton(icon: const Icon(Icons.close, color: Colors.white), tooltip: 'Leave game', onPressed: _confirmExit),
        const Expanded(
          child: Text('Ludo', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
        ),
        IconButton(
          icon: Icon(_sound ? Icons.volume_up : Icons.volume_off, color: Colors.white),
          tooltip: 'Sound and vibration',
          onPressed: () => setState(() => _sound = !_sound),
        ),
        IconButton(icon: const Icon(Icons.help_outline, color: Colors.white), tooltip: 'How to play', onPressed: _showRules),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: Colors.white),
          tooltip: 'Menu',
          onSelected: _menu,
          itemBuilder: (_) => [
            const PopupMenuItem<String>(value: 'restart', child: Text('Restart game')),
            if (widget.vsComputer) ...[
              const PopupMenuDivider(),
              for (final l in LudoDifficulty.values)
                CheckedPopupMenuItem<String>(value: l.name, checked: _level == l, child: Text('Bot level: ${l.label}')),
            ],
          ],
        ),
      ]);

  Widget _players() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          for (final s in g.seats)
            Expanded(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                decoration: BoxDecoration(
                  color: ludoTint(kLudoColors[s], s == g.current ? .4 : .14),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: s == g.current ? Colors.white : Colors.transparent, width: 2),
                ),
                child: Column(children: [
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(_panelName(s), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
                  ),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      '${_home(s)}/4 home${_captures[s]! > 0 ? ' · ⚔ ${_captures[s]}' : ''}',
                      style: const TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ),
                ]),
              ),
            ),
        ]),
      );

  Widget _controls() {
    final color = kLudoColors[g.current];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 18),
      child: Row(children: [
        Semantics(
          button: true,
          enabled: _canRoll,
          label: 'Roll dice',
          child: GestureDetector(
            onTap: _canRoll ? _roll : null,
            child: AnimatedRotation(
              turns: _turns,
              duration: const Duration(milliseconds: 65),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [if (_canRoll) BoxShadow(color: ludoTint(color, .7), blurRadius: 18, spreadRadius: 2)],
                ),
                child: CustomPaint(painter: _DicePainter(face)),
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

class _DicePainter extends CustomPainter {
  final int face;
  _DicePainter(this.face);
  static const _pips = {
    1: [
      [.5, .5]
    ],
    2: [
      [.28, .28],
      [.72, .72]
    ],
    3: [
      [.28, .28],
      [.5, .5],
      [.72, .72]
    ],
    4: [
      [.28, .28],
      [.72, .28],
      [.28, .72],
      [.72, .72]
    ],
    5: [
      [.28, .28],
      [.72, .28],
      [.5, .5],
      [.28, .72],
      [.72, .72]
    ],
    6: [
      [.28, .25],
      [.72, .25],
      [.28, .5],
      [.72, .5],
      [.28, .75],
      [.72, .75]
    ],
  };
  @override
  void paint(Canvas canvas, Size s) {
    for (final p in _pips[face]!) {
      canvas.drawCircle(Offset(p[0] * s.width, p[1] * s.height), s.width * .075, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant _DicePainter old) => old.face != face;
}
