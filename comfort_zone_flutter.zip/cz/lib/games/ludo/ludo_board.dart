import 'dart:math';
import 'package:flutter/material.dart';
import 'ludo_engine.dart';

Color ludoTint(Color c, double opacity) => c.withAlpha((opacity.clamp(0.0, 1.0) * 255).round());

class LudoBoard extends StatefulWidget {
  final LudoGame game;
  final List<int> movable;
  final void Function(int token) onTokenTap;
  const LudoBoard({super.key, required this.game, required this.movable, required this.onTokenTap});
  @override
  State<LudoBoard> createState() => _LudoBoardState();
}

class _LudoBoardState extends State<LudoBoard> with TickerProviderStateMixin {
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
  late final AnimationController _glide =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 120));

  final Map<int, Offset> _from = {}, _to = {};
  final Map<int, bool> _inYard = {};

  @override
  void initState() {
    super.initState();
    _sync(animate: false);
  }

  @override
  void didUpdateWidget(covariant LudoBoard old) {
    super.didUpdateWidget(old);
    _sync(animate: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    _glide.dispose();
    super.dispose();
  }

  Offset _shown(int key) {
    final a = _from[key], b = _to[key];
    if (a == null || b == null) return Offset.zero;
    return Offset.lerp(a, b, Curves.easeInOut.transform(_glide.value))!;
  }

  void _sync({required bool animate}) {
    final g = widget.game;
    final shown = {for (final k in _to.keys) k: _shown(k)};
    for (final s in g.seats) {
      for (var t = 0; t < 4; t++) {
        final k = s * 4 + t, target = g.pos(s, t), yard = g.tokens[s]![t] == -1;
        final old = _to[k];
        if (old == null) {
          _from[k] = target;
          _to[k] = target;
          _inYard[k] = yard;
          continue;
        }
        if (old != target) {
          final smooth = animate && ((old - target).distance < 1.7 || _inYard[k] != yard);
          _from[k] = smooth ? shown[k]! : target;
          _to[k] = target;
        } else {
          _from[k] = shown[k]!;
        }
        _inYard[k] = yard;
      }
    }
    if (_from.entries.any((e) => e.value != _to[e.key])) _glide.forward(from: 0);
  }

  void _tap(Offset local, double side) {
    final g = widget.game, pt = local / (side / 15);
    int? best;
    var bestD = .9;
    for (final t in widget.movable) {
      final d = (g.pos(g.current, t) - pt).distance;
      if (d < bestD) {
        bestD = d;
        best = t;
      }
    }
    if (best != null) widget.onTokenTap(best);
  }

  @override
  Widget build(BuildContext context) => Semantics(
        label: 'Ludo board',
        child: AspectRatio(
          aspectRatio: 1,
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 18, offset: Offset(0, 6))],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: LayoutBuilder(
                builder: (_, c) => GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTapUp: (d) => _tap(d.localPosition, c.maxWidth),
                  child: CustomPaint(
                    size: c.biggest,
                    painter: _BoardPainter(widget.game, widget.movable, _pulse, _glide, _shown),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

class _BoardPainter extends CustomPainter {
  final LudoGame game;
  final List<int> movable;
  final Animation<double> pulse, glide;
  final Offset Function(int key) shown;
  _BoardPainter(this.game, this.movable, this.pulse, this.glide, this.shown)
      : super(repaint: Listenable.merge([pulse, glide]));

  static const _origins = [Offset(0, 0), Offset(9, 0), Offset(9, 9), Offset(0, 9)];
  static const _grey = Color(0xFFD5D0E2);
  static const _gridLine = Color(0xFFB9B2CC);
  static const _arrowAngle = [0.0, pi / 2, pi, -pi / 2];

  Paint _fill(Color c) => Paint()..color = c;

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.width / 15;
    Rect cellRect((int, int) rc) => Rect.fromLTWH(rc.$2 * u, rc.$1 * u, u, u);
    Color col(int p) => game.seats.contains(p) ? kLudoColors[p] : _grey;
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..color = _gridLine
      ..strokeWidth = .6;

    canvas.drawRect(Offset.zero & size, _fill(Colors.white));

    for (var p = 0; p < 4; p++) {
      final o = _origins[p], active = game.seats.contains(p);
      canvas.drawRect(Rect.fromLTWH(o.dx * u, o.dy * u, 6 * u, 6 * u), _fill(col(p)));
      canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH((o.dx + 1) * u, (o.dy + 1) * u, 4 * u, 4 * u), Radius.circular(u * .6)),
          _fill(Colors.white));
      if (!active) continue;
      for (var t = 0; t < 4; t++) {
        final slot = Offset((o.dx + (t % 2 == 0 ? 2.0 : 4.0)) * u, (o.dy + (t < 2 ? 2.0 : 4.0)) * u);
        canvas.drawCircle(slot, u * .55, _fill(ludoTint(kLudoColors[p], .18)));
        canvas.drawCircle(
            slot,
            u * .55,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = u * .06
              ..color = ludoTint(kLudoColors[p], .5));
      }
    }

    for (final rc in kTrack) {
      canvas.drawRect(cellRect(rc), _fill(Colors.white));
      canvas.drawRect(cellRect(rc), grid);
    }
    for (var p = 0; p < 4; p++) {
      final start = cellRect(kTrack[kStart[p]]);
      canvas.drawRect(start, _fill(col(p)));
      canvas.drawRect(start, grid);
      for (final rc in kHome[p]) {
        canvas.drawRect(cellRect(rc), _fill(col(p)));
        canvas.drawRect(cellRect(rc), grid);
      }
      if (game.seats.contains(p)) _arrow(canvas, start.center, u, _arrowAngle[p]);
    }

    final mid = Offset(7.5 * u, 7.5 * u);
    void tri(Offset a, Offset b, Color color) {
      final path = Path()
        ..moveTo(a.dx, a.dy)
        ..lineTo(b.dx, b.dy)
        ..lineTo(mid.dx, mid.dy)
        ..close();
      canvas.drawPath(path, _fill(color));
      canvas.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = u * .05
            ..color = Colors.white);
    }

    tri(Offset(6 * u, 6 * u), Offset(6 * u, 9 * u), col(0));
    tri(Offset(6 * u, 6 * u), Offset(9 * u, 6 * u), col(1));
    tri(Offset(9 * u, 6 * u), Offset(9 * u, 9 * u), col(2));
    tri(Offset(6 * u, 9 * u), Offset(9 * u, 9 * u), col(3));

    for (final i in kSafe) {
      if (kStart.contains(i)) continue;
      final tp = TextPainter(
        text: TextSpan(text: '★', style: TextStyle(fontSize: u * .75, color: const Color(0xFF9C94B5))),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, cellRect(kTrack[i]).center - Offset(tp.width / 2, tp.height / 2));
    }

    if (game.winner == null) {
      final o = _origins[game.current];
      canvas.drawRect(
          Rect.fromLTWH(o.dx * u, o.dy * u, 6 * u, 6 * u).deflate(u * .09),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = u * .16
            ..color = ludoTint(Colors.white, .5 + .4 * pulse.value));
    }

    final groups = <String, List<(int, int)>>{};
    for (final s in game.seats) {
      for (var t = 0; t < 4; t++) {
        final o = game.pos(s, t);
        groups.putIfAbsent('${o.dx.toStringAsFixed(2)},${o.dy.toStringAsFixed(2)}', () => []).add((s, t));
      }
    }
    final entries = <(int, int, int, int)>[];
    for (final stack in groups.values) {
      for (var i = 0; i < stack.length; i++) {
        entries.add((stack[i].$1, stack[i].$2, i, stack.length));
      }
    }
    entries.sort((a, b) => (a.$1 == game.current ? 1 : 0).compareTo(b.$1 == game.current ? 1 : 0));

    const spread = [Offset(-.2, -.2), Offset(.2, -.2), Offset(-.2, .2), Offset(.2, .2)];
    for (final (s, t, i, n) in entries) {
      final glow = s == game.current && movable.contains(t);
      var centre = (shown(s * 4 + t) + (n > 1 ? spread[i % 4] : Offset.zero)) * u;
      final r = u * (n > 1 ? .28 : .38), color = kLudoColors[s];

      canvas.drawCircle(centre + Offset(0, u * .06), r, _fill(const Color(0x44000000)));
      if (glow) centre -= Offset(0, u * .12 * pulse.value);
      canvas.drawCircle(
          centre,
          r,
          Paint()
            ..shader = RadialGradient(
              center: const Alignment(-.35, -.4),
              colors: [Color.lerp(color, Colors.white, .45)!, color],
            ).createShader(Rect.fromCircle(center: centre, radius: r)));
      canvas.drawCircle(
          centre,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = u * .07
            ..color = Colors.white);
      canvas.drawCircle(
          centre,
          r * .38,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = u * .05
            ..color = ludoTint(Colors.white, .55));
      if (glow) {
        canvas.drawCircle(
            centre,
            r + u * (.12 + .1 * pulse.value),
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = u * .1
              ..color = ludoTint(const Color(0xFF231A3A), .85));
      }
    }
  }

  void _arrow(Canvas canvas, Offset at, double u, double angle) {
    canvas.save();
    canvas.translate(at.dx, at.dy);
    canvas.rotate(angle);
    final path = Path()
      ..moveTo(u * .28, 0)
      ..lineTo(-u * .18, -u * .24)
      ..lineTo(-u * .18, u * .24)
      ..close();
    canvas.drawPath(path, _fill(ludoTint(Colors.white, .9)));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BoardPainter old) => true;
}
