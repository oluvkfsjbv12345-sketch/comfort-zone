import 'dart:math';
import 'package:flutter/material.dart';

/// বোর্ডের কালার প্যালেট (0: Red, 1: Green, 2: Yellow, 3: Blue)
const List<Color> kLudoColors = [
  Color(0xFFE53935), // Red
  Color(0xFF4CAF50), // Green
  Color(0xFFFFB300), // Yellow
  Color(0xFF1E88E5), // Blue
];

/// সাধারণ ট্র্যাকের ৫২টি সেলের কোঅর্ডিনেট (Row, Column)
const List<(int, int)> kTrack = [
  (6, 1), (6, 2), (6, 3), (6, 4), (6, 5), (5, 6), (4, 6), (3, 6), (2, 6), (1, 6), (0, 6),
  (0, 7), (0, 8),
  (1, 8), (2, 8), (3, 8), (4, 8), (5, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13), (6, 14),
  (7, 14), (8, 14),
  (8, 13), (8, 12), (8, 11), (8, 10), (8, 9), (9, 8), (10, 8), (11, 8), (12, 8), (13, 8), (14, 8),
  (14, 7), (14, 6),
  (13, 6), (12, 6), (11, 6), (10, 6), (9, 6), (8, 5), (8, 4), (8, 3), (8, 2), (8, 1), (8, 0),
  (7, 0), (6, 0),
];

/// প্রতিটি প্লেয়ারের স্টার্টিং ইনডেক্স (kTrack অনুযায়ী)
const List<int> kStart = [0, 13, 26, 39];

/// সেফ স্টার (Safe Stars) এবং স্টার্টিং সেল
const Set<int> kSafe = {0, 8, 13, 21, 26, 34, 39, 47};

/// প্রতিটি প্লেয়ারের জন্য হোম কলামের সেলসমূহ
const List<List<(int, int)>> kHome = [
  [(7, 1), (7, 2), (7, 3), (7, 4), (7, 5)], // Red
  [(1, 7), (2, 7), (3, 7), (4, 7), (5, 7)], // Green
  [(7, 13), (7, 12), (7, 11), (7, 10), (7, 9)], // Yellow
  [(13, 7), (12, 7), (11, 7), (10, 7), (9, 7)], // Blue
];

class MoveResult {
  final bool captured;
  final bool reachedHome;
  final bool won;
  const MoveResult({this.captured = false, this.reachedHome = false, this.won = false});
}

class LudoGame {
  final List<int> seats;
  final Random rng;

  int turnIndex = 0;
  int? dice;
  int sixesInRow = 0;
  int? winner;

  late Map<int, List<int>> tokens;

  LudoGame(this.seats, {Random? rng}) : rng = rng ?? Random() {
    tokens = {for (final s in seats) s: [-1, -1, -1, -1]};
  }

  int get current => seats[turnIndex];

  static int? absCell(int seat, int pos) {
    if (pos < 0 || pos > 50) return null;
    return (kStart[seat] + pos) % 52;
  }

  Offset pos(int seat, int token) {
    final p = tokens[seat]![token];
    if (p == -1) {
      final origins = [const Offset(0, 0), const Offset(9, 0), const Offset(9, 9), const Offset(0, 9)];
      final o = origins[seat];
      final dx = o.dx + (token % 2 == 0 ? 2.0 : 4.0);
      final dy = o.dy + (token < 2 ? 2.0 : 4.0);
      return Offset(dx, dy);
    }
    if (p <= 50) {
      final cell = absCell(seat, p)!;
      final rc = kTrack[cell];
      return Offset(rc.$2 + 0.5, rc.$1 + 0.5);
    }
    if (p <= 55) {
      final rc = kHome[seat][p - 51];
      return Offset(rc.$2 + 0.5, rc.$1 + 0.5);
    }
    return const Offset(7.5, 7.5);
  }

  int roll() {
    final d = 1 + rng.nextInt(6);
    dice = d;
    if (d == 6) {
      sixesInRow++;
    } else {
      sixesInRow = 0;
    }
    return d;
  }

  int? target(int token) {
    if (dice == null) return null;
    final p = tokens[current]![token];
    final d = dice!;
    if (p == -1) return d == 6 ? 0 : null;
    if (p + d > 56) return null;
    return p + d;
  }

  List<int> movable() {
    if (dice == null) return [];
    final opts = <int>[];
    for (var t = 0; t < 4; t++) {
      if (target(t) != null) opts.add(t);
    }
    return opts;
  }

  MoveResult finishMove(int token, int targetPos) {
    tokens[current]![token] = targetPos;
    bool captured = false;

    final cell = absCell(current, targetPos);
    if (cell != null && !kSafe.contains(cell)) {
      for (final opponent in seats) {
        if (opponent == current) continue;
        for (var i = 0; i < 4; i++) {
          if (absCell(opponent, tokens[opponent]![i]) == cell) {
            tokens[opponent]![i] = -1;
            captured = true;
          }
        }
      }
    }

    final reachedHome = targetPos == 56;
    final won = tokens[current]!.every((p) => p == 56);

    if (won) {
      winner = current;
    } else {
      final extraTurn = (dice == 6 && sixesInRow < 3) || captured || reachedHome;
      endTurn(extra: extraTurn);
    }

    return MoveResult(captured: captured, reachedHome: reachedHome, won: won);
  }

  void endTurn({required bool extra}) {
    dice = null;
    if (!extra) {
      sixesInRow = 0;
      turnIndex = (turnIndex + 1) % seats.length;
    }
  }
}
