import 'package:flutter/material.dart';

/// Lets services show in-app banners from anywhere.
final GlobalKey<ScaffoldMessengerState> rootMessengerKey = GlobalKey<ScaffoldMessengerState>();
