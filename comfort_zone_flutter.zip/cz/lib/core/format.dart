/// Short chat-list timestamp: now, 5m, 3h, Yesterday, 12/9.
String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'now';
  if (d.inHours < 1) return '${d.inMinutes}m';
  if (d.inDays < 1) return '${d.inHours}h';
  if (d.inDays < 2) return 'Yesterday';
  return '${t.day}/${t.month}';
}
