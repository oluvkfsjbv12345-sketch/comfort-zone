import 'package:supabase_flutter/supabase_flutter.dart';

/// Turns any error into a short sentence safe to show in a SnackBar.
String friendly(Object e) => e is PostgrestException ? e.message : e.toString().replaceFirst('Exception: ', '');
