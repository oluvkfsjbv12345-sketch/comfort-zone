import 'package:flutter/material.dart';

/// Central design tokens. Change here to re-skin the whole app.
class Brand {
  static const violet = Color(0xFF7B4DFF);
  static const coral = Color(0xFFFF5E8A);
  static const gold = Color(0xFFF5B942);
  static const bg = Color(0xFFF6F3FB);
  static const ink = Color(0xFF231A3A);
  static const mute = Color(0xFF7D7595);

  static const gradient = LinearGradient(
      colors: [violet, coral], begin: Alignment.topLeft, end: Alignment.bottomRight);

  static ThemeData light() => ThemeData(
        useMaterial3: true,
        colorSchemeSeed: violet,
        scaffoldBackgroundColor: bg,
        textTheme: ThemeData.light().textTheme.apply(bodyColor: ink, displayColor: ink),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: violet.withOpacity(.12),
          labelTextStyle: WidgetStateProperty.all(
              const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
        ),
      );
}

/// Backend config. Run with:
/// flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
/// Leave empty to run on built-in demo data.
class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static const agoraAppId = String.fromEnvironment('AGORA_APP_ID');
  static bool get useMock => supabaseUrl.isEmpty;
  /// Voice needs a live backend (token function) and an Agora app id.
  static bool get voiceEnabled => !useMock && agoraAppId.isNotEmpty;
}
