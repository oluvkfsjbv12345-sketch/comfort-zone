import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/app_keys.dart';
import '../core/theme.dart';
import '../data/notification_repository.dart';
import '../models/notification.dart';

/// Listens for new notifications while the app is running.
/// Foreground: floating in-app banner. Background: system notification.
/// (When the app is fully closed you need FCM push; see the note in the README of this step.)
class NotificationService with WidgetsBindingObserver {
  NotificationService._();
  static final instance = NotificationService._();

  final ValueNotifier<int> unread = ValueNotifier(0);
  /// Bumped when coins land so the Me and Gaming tabs refresh their balance.
  final ValueNotifier<int> walletVersion = ValueNotifier(0);

  final _plugin = FlutterLocalNotificationsPlugin();
  final _repo = NotificationRepository();
  RealtimeChannel? _channel;
  bool _foreground = true, _ready = false;

  Future<void> start() async {
    if (AppConfig.useMock) return;
    WidgetsBinding.instance.addObserver(this);
    await _initLocal();
    await refresh();
    _channel ??= _repo.watch(_onNew);
  }

  Future<void> stop() async {
    WidgetsBinding.instance.removeObserver(this);
    await _repo.unwatch(_channel);
    _channel = null;
  }

  Future<void> _initLocal() async {
    if (_ready) return;
    await _plugin.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings()));
    await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    await _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
    _ready = true;
  }

  Future<void> refresh() async {
    try { unread.value = await _repo.unreadCount(); } catch (_) {}
  }

  void _onNew(AppNotification n) {
    unread.value += 1;
    if (n.type == 'recharge_approved') walletVersion.value += 1;
    if (_foreground) {
      rootMessengerKey.currentState
        ?..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
          behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 5),
          content: Text('${n.title}\n${n.body}')));
    } else {
      _plugin.show(n.id, n.title, n.body, const NotificationDetails(
          android: AndroidNotificationDetails('cz_alerts', 'Comfort Zone alerts', importance: Importance.high, priority: Priority.high),
          iOS: DarwinNotificationDetails()));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (_foreground) refresh();   // catch anything missed while the socket was asleep
  }
}
