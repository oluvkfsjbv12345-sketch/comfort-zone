import 'package:flutter/foundation.dart';
import '../data/message_repository.dart';

/// App-wide unread count that drives the Message tab badge.
class UnreadService {
  static final ValueNotifier<int> count = ValueNotifier(0);
  static Future<void> refresh() async {
    try { count.value = await MessageRepository().unreadTotal(); } catch (_) {}
  }
}
