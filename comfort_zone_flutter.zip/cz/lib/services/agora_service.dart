import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// Thin wrapper over Agora RTC. Everyone joins as audience; seated users switch to broadcaster.
class AgoraService {
  RtcEngine? _engine;
  int _myUid = 0;

  /// Agora uids currently talking (drives the seat ring animation).
  final ValueNotifier<Set<int>> speaking = ValueNotifier({});

  Future<void> init(String appId) async {
    await Permission.microphone.request();
    final e = createAgoraRtcEngine();
    await e.initialize(RtcEngineContext(
        appId: appId, channelProfile: ChannelProfileType.channelProfileLiveBroadcasting));
    await e.enableAudio();
    await e.enableAudioVolumeIndication(interval: 300, smooth: 3, reportVad: true);
    e.registerEventHandler(RtcEngineEventHandler(
      onAudioVolumeIndication: (conn, speakers, total, vol) {
        speaking.value = {
          for (final s in speakers)
            if ((s.volume ?? 0) > 20) ((s.uid ?? 0) == 0 ? _myUid : s.uid!)   // uid 0 = local user
        };
      },
    ));
    _engine = e;
  }

  Future<void> join({required String token, required String channel, required int uid}) async {
    _myUid = uid;
    await _engine!.joinChannel(
      token: token, channelId: channel, uid: uid,
      options: const ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleAudience,
        channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        autoSubscribeAudio: true, publishMicrophoneTrack: false));
  }

  /// true = start publishing mic (after taking a seat), false = back to listening.
  Future<void> setSpeaker(bool on) async => _engine?.updateChannelMediaOptions(ChannelMediaOptions(
      clientRoleType: on ? ClientRoleType.clientRoleBroadcaster : ClientRoleType.clientRoleAudience,
      publishMicrophoneTrack: on));

  Future<void> renewToken(String token) async { await _engine?.renewToken(token); }
  Future<void> mute(bool muted) async { await _engine?.muteLocalAudioStream(muted); }

  Future<void> leave() async {
    await _engine?.leaveChannel();
    await _engine?.release();
    _engine = null;
  }
}
