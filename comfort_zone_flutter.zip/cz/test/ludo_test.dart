import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:comfort_zone/games/ludo/ludo_bot_logic.dart';
import 'package:comfort_zone/games/ludo/ludo_engine.dart';

/// Always rolls the same number.
class _Fixed implements Random {
  final int face; // 1..6
  _Fixed(this.face);
  @override
  int nextInt(int max) => face - 1;
  @override
  double nextDouble() => 0;
  @override
  bool nextBool() => false;
}

void main() {
  test('track has 52 cells and every start square is safe', () {
    expect(kTrack.length, 52);
    for (final s in kStart) {
      expect(kSafe.contains(s), isTrue);
    }
  });

  test('a token needs a 6 to leave the yard', () {
    final g = LudoGame([0, 2]);
    g.dice = 3;
    expect(g.movable(), isEmpty);
    g.dice = 6;
    expect(g.movable(), [0, 1, 2, 3]);
    expect(g.target(0), 0);
  });

  test('exact roll is required to reach the centre', () {
    final g = LudoGame([0, 2]);
    g.tokens[0]![0] = 54;
    g.dice = 3;
    expect(g.target(0), isNull);
    g.dice = 2;
    expect(g.target(0), 56);
  });

  test('landing on an opponent captures it and gives another roll', () {
    final g = LudoGame([0, 2]);
    g.tokens[0]![0] = 4;
    g.tokens[2]![0] = 31; // yard offset 26 + 31 = cell 5
    g.dice = 1;
    final r = g.finishMove(0, 5);
    expect(r.captured, isTrue);
    expect(g.tokens[2]![0], -1);
    expect(g.current, 0);
  });

  test('a token on a safe star cannot be captured', () {
    final g = LudoGame([0, 2]);
    g.tokens[0]![0] = 7;
    g.tokens[2]![0] = 34; // cell 8 is a star
    g.dice = 1;
    final r = g.finishMove(0, 8);
    expect(r.captured, isFalse);
    expect(g.tokens[2]![0], 34);
    expect(g.current, 2); // turn passes
  });

  test('bringing the last token home wins the game', () {
    final g = LudoGame([0, 2]);
    g.tokens[0]!.setAll(0, [56, 56, 56, 55]);
    g.dice = 1;
    final r = g.finishMove(3, 56);
    expect(r.won, isTrue);
    expect(g.winner, 0);
  });

  test('three sixes in a row are counted', () {
    final g = LudoGame([0, 2], rng: _Fixed(6));
    g.roll();
    g.roll();
    g.roll();
    expect(g.sixesInRow, 3);
    g.endTurn(extra: false);
    expect(g.sixesInRow, 0);
    expect(g.current, 2);
  });

  for (final level in LudoDifficulty.values) {
    for (final seats in [
      [0, 2],
      [0, 1, 2, 3]
    ]) {
      test('bots finish a ${seats.length}-player game (${level.name})', () {
        final rng = Random(7);
        final g = LudoGame(seats, rng: rng);
        final bot = LudoBot(level, rng: rng);
        var steps = 0;
        while (g.winner == null && steps++ < 20000) {
          g.roll();
          if (g.sixesInRow >= 3) {
            g.endTurn(extra: false);
            continue;
          }
          final opts = g.movable();
          if (opts.isEmpty) {
            g.endTurn(extra: false);
            continue;
          }
          final t = bot.chooseMove(g, opts);
          expect(opts, contains(t));
          g.finishMove(t, g.target(t)!);
        }
        expect(g.winner, isNotNull);
      });
    }
  }
}
